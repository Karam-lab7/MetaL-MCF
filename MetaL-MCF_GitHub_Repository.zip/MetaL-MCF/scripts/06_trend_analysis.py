"""Calculate pixel-wise Hamed-Rao Mann-Kendall tests and Theil-Sen slopes."""
from config import PREDICTIONS_DIR, TARGET

#Here is the complete code to calculate Modified Mann-Kendall (Hamed-Rao) trend test
#and Sen's slope for each pixel across 2000–2020, then save the results as NetCDF files.
# ==========================================================
import os
import glob
import xarray as xr
import numpy as np
from scipy.stats import theilslopes

# Modified Mann-Kendall test
try:
    import pymannkendall as mk
    HAS_MK = True
except ImportError:
    HAS_MK = False
    raise ImportError("Install pymannkendall:  pip install pymannkendall")

INPUT_DIR = str(PREDICTIONS_DIR)
OUTPUT_DIR = INPUT_DIR

# ── 1. Find annual files for years 2000–2020 ──────────────────────────
files = sorted(glob.glob(os.path.join(INPUT_DIR, f"{TARGET}_[0-9][0-9][0-9][0-9]_annual.nc")))

file_dict = {}
for f in files:
    year = int(os.path.basename(f).split("_")[1])
    if 2000 <= year <= 2020:
        file_dict[year] = f

print(f"Found {len(file_dict)} annual files (2000–2020)")

if len(file_dict) < 3:
    raise ValueError("Need at least 3 years for trend analysis.")

# ── 2. Concatenate into a single 3D DataArray (time, lat, lon) ──────
ds_list = []
for year in sorted(file_dict.keys()):
    ds = xr.open_dataset(file_dict[year])
    ds = ds.assign_coords(time=year)
    ds = ds.expand_dims("time")
    ds_list.append(ds)

ds_all = xr.concat(ds_list, dim="time")
var_name = list(ds_all.data_vars)[0]
da = ds_all[var_name]

print(f"Data loaded: {da.dims} = {da.shape}")
print(f"Variable: {var_name}")

# ── 3. Define pixel-wise functions ────────────────────────────────────

def modified_mk(series):
    """
    Hamed-Rao Modified Mann-Kendall test.
    Returns (Z statistic, p-value).
    """
    series = np.asarray(series, dtype=np.float64)
    valid = series[~np.isnan(series)]
    
    if len(valid) < 3:
        return np.nan, np.nan
    
    try:
        result = mk.hamed_rao_modification_test(valid)
        return result.z, result.p
    except Exception:
        return np.nan, np.nan


def sen_slope(series):
    """
    Theil-Sen slope estimator (Sen's slope).
    """
    series = np.asarray(series, dtype=np.float64)
    valid = series[~np.isnan(series)]
    
    if len(valid) < 2:
        return np.nan
    
    try:
        res = theilslopes(valid)
        return res.slope
    except Exception:
        return np.nan


# ── 4. Apply analysis per pixel ───────────────────────────────────────
print("\nRunning Modified Mann-Kendall test (this may take a few minutes)...")

# Compute Z and p in one pass
mk_z, mk_p = xr.apply_ufunc(
    modified_mk,
    da,
    input_core_dims=[['time']],
    output_core_dims=[[], []],
    vectorize=True,
    dask='parallelized',
    output_dtypes=[np.float64, np.float64]
)

print("Running Sen's slope...")
sen = xr.apply_ufunc(
    sen_slope,
    da,
    input_core_dims=[['time']],
    output_core_dims=[[]],
    vectorize=True,
    dask='parallelized',
    output_dtypes=[np.float64]
)

# ── 5. Create significance mask (α = 0.05) ─────────────────────────────
alpha = 0.05
mk_significant = xr.where(mk_p < alpha, 1, 0).astype(np.int8)

# Significant slope: keep slope only where p < 0.05, else NaN
sen_significant = sen.where(mk_p < alpha)

# ── 6. Save outputs ───────────────────────────────────────────────────
coords = {"lat": da["lat"], "lon": da["lon"]}

# 1. Sen's Slope (all pixels)
xr.Dataset({"Sen_Slope": sen}, coords=coords).to_netcdf(
    os.path.join(OUTPUT_DIR, f"{TARGET}_Sen_Slope.nc"),
    encoding={"Sen_Slope": {"zlib": True, "complevel": 4, "dtype": "float32"}}
)
print(f"Saved: {TARGET}_Sen_Slope.nc")

# 2. Sen's Slope (significant pixels only)
xr.Dataset({"Sen_Slope_Sig": sen_significant}, coords=coords).to_netcdf(
    os.path.join(OUTPUT_DIR, f"{TARGET}_Sen_Slope_Significant.nc"),
    encoding={"Sen_Slope_Sig": {"zlib": True, "complevel": 4, "dtype": "float32"}}
)
print(f"Saved: {TARGET}_Sen_Slope_Significant.nc")

# 3. MK Z statistic
xr.Dataset({"MK_Z": mk_z}, coords=coords).to_netcdf(
    os.path.join(OUTPUT_DIR, f"{TARGET}_MK_Z.nc"),
    encoding={"MK_Z": {"zlib": True, "complevel": 4, "dtype": "float32"}}
)
print(f"Saved: {TARGET}_MK_Z.nc")

# 4. MK p-value
xr.Dataset({"MK_pvalue": mk_p}, coords=coords).to_netcdf(
    os.path.join(OUTPUT_DIR, f"{TARGET}_MK_pvalue.nc"),
    encoding={"MK_pvalue": {"zlib": True, "complevel": 4, "dtype": "float32"}}
)
print(f"Saved: {TARGET}_MK_pvalue.nc")

# 5. MK Significance mask (1 = significant, 0 = not significant)
xr.Dataset({"MK_Significance": mk_significant}, coords=coords).to_netcdf(
    os.path.join(OUTPUT_DIR, f"{TARGET}_MK_Significance.nc"),
    encoding={"MK_Significance": {"zlib": True, "complevel": 4, "dtype": "int8"}}
)
print(f"Saved: {TARGET}_MK_Significance.nc")

print("\n✅ All trend analysis files saved successfully!")
