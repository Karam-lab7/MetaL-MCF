"""
Publication-quality carbon-flux trend analysis figure
Layout: 2x3 maps, each with longitude profile above and latitude profile to the right.
Profiles share the same colormap as their parent map.
"""

from config import PREDICTIONS_DIR, TARGET

import os
import glob
import xarray as xr
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
import matplotlib.gridspec as gridspec
import cartopy.crs as ccrs
import cartopy.feature as cfeature
from matplotlib import rcParams
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle

# ============================================================
# NATURE-STYLE PUBLICATION SETTINGS
# ============================================================
rcParams['font.family'] = 'sans-serif'
rcParams['font.sans-serif'] = ['Arial', 'Helvetica', 'DejaVu Sans']
rcParams['font.size'] = 9
rcParams['axes.labelsize'] = 9
rcParams['axes.titlesize'] = 10
rcParams['xtick.labelsize'] = 8
rcParams['ytick.labelsize'] = 8
rcParams['figure.dpi'] = 300


# ============================================================
# HELPER: COLOR-MAPPED PROFILE LINE
# ============================================================
def plot_colored_line(ax, x, y, vals, cmap, norm, linewidth=2):
    """
    Plot a line colored by its values using LineCollection segments.
    x, y: coordinate arrays
    vals: values to color by
    """
    from matplotlib.collections import LineCollection
    points = np.array([x, y]).T.reshape(-1, 1, 2)
    segments = np.concatenate([points[:-1], points[1:]], axis=1)
    lc = LineCollection(segments, cmap=cmap, norm=norm, linewidth=linewidth)
    lc.set_array(vals)
    ax.add_collection(lc)
    return lc


def get_profile_color(data, cmap, norm):
    """Get a representative color for the profile line from the data range."""
    valid = data[~np.isnan(data)]
    if len(valid) == 0:
        return 'black'
    mid_val = np.nanmean(valid)
    return cmap(norm(mid_val))


# ============================================================
# DATA LOADING (UNCHANGED LOGIC)
# ============================================================
INPUT_DIR = str(PREDICTIONS_DIR)
OUTPUT_DIR = INPUT_DIR

# --- Find annual files ---
annual_files = sorted(glob.glob(os.path.join(INPUT_DIR, f"{TARGET}_[0-9][0-9][0-9][0-9]_annual.nc")))
print(f"Found {len(annual_files)} annual files")
if len(annual_files) < 3:
    raise ValueError("Need at least 3 annual files.")

# --- Trend files ---
trend_files = {
    "slope":     os.path.join(INPUT_DIR, f"{TARGET}_Sen_Slope.nc"),
    "slope_sig": os.path.join(INPUT_DIR, f"{TARGET}_Sen_Slope_Significant.nc"),
    "mk_z":      os.path.join(INPUT_DIR, f"{TARGET}_MK_Z.nc"),
    "mk_p":      os.path.join(INPUT_DIR, f"{TARGET}_MK_pvalue.nc"),
    "mk_sig":    os.path.join(INPUT_DIR, f"{TARGET}_MK_Significance.nc"),
}

# --- Multi-year mean Reco ---
ds_list = []
for f in annual_files:
    ds = xr.open_dataset(f)
    ds_list.append(ds)

ds_concat = xr.concat(ds_list, dim="time")
var_name = list(ds_concat.data_vars)[0]
reco_mean = ds_concat[var_name].mean(dim="time", skipna=True)
if 'lat' in reco_mean.dims and 'lon' in reco_mean.dims:
    reco_mean = reco_mean.transpose('lat', 'lon')
for ds in ds_list:
    ds.close()

# --- Load trend datasets ---
ds_slope     = xr.open_dataset(trend_files["slope"])
ds_slope_sig = xr.open_dataset(trend_files["slope_sig"])
ds_mkz       = xr.open_dataset(trend_files["mk_z"])
ds_mkp       = xr.open_dataset(trend_files["mk_p"])
ds_mksig     = xr.open_dataset(trend_files["mk_sig"])

slope     = ds_slope[list(ds_slope.data_vars)[0]]
slope_sig = ds_slope_sig[list(ds_slope_sig.data_vars)[0]]
mk_z      = ds_mkz[list(ds_mkz.data_vars)[0]]
mk_p      = ds_mkp[list(ds_mkp.data_vars)[0]]
mk_sig    = ds_mksig[list(ds_mksig.data_vars)[0]]

for arr in [slope, slope_sig, mk_z, mk_p, mk_sig]:
    if 'lat' in arr.dims and 'lon' in arr.dims:
        arr = arr.transpose('lat', 'lon')

lon = reco_mean["lon"].values
lat = reco_mean["lat"].values

# --- Shift 0-360 to -180~180 ---
if lon.max() > 180:
    lon = np.where(lon > 180, lon - 360, lon)
    sort_idx = np.argsort(lon)
    lon = lon[sort_idx]
    reco_mean = reco_mean.isel(lon=sort_idx)
    slope = slope.isel(lon=sort_idx)
    slope_sig = slope_sig.isel(lon=sort_idx)
    mk_z = mk_z.isel(lon=sort_idx)
    mk_p = mk_p.isel(lon=sort_idx)
    mk_sig = mk_sig.isel(lon=sort_idx)

# --- Numpy arrays ---
reco_mean_v = reco_mean.values
slope_v = slope.values
slope_sig_v = slope_sig.values
mk_z_v = mk_z.values
mk_p_v = mk_p.values
mk_sig_v = mk_sig.values

def ensure_lat_lon_orientation(data, lat_len, lon_len):
    if data.shape == (lon_len, lat_len):
        return data.T
    elif data.shape == (lat_len, lon_len):
        return data
    else:
        if data.size == lat_len * lon_len:
            return data.reshape(lat_len, lon_len)
        raise ValueError(f"Cannot reshape array of size {data.size}")

reco_mean_v = ensure_lat_lon_orientation(reco_mean_v, len(lat), len(lon))
slope_v    = ensure_lat_lon_orientation(slope_v,    len(lat), len(lon))
slope_sig_v= ensure_lat_lon_orientation(slope_sig_v,len(lat), len(lon))
mk_z_v     = ensure_lat_lon_orientation(mk_z_v,     len(lat), len(lon))
mk_p_v     = ensure_lat_lon_orientation(mk_p_v,     len(lat), len(lon))
mk_sig_v   = ensure_lat_lon_orientation(mk_sig_v,   len(lat), len(lon))

# ============================================================
# BUILD EDGE-CENTERED 2D COORDINATES FOR PCOLORMESH
# ============================================================
def build_edges(coord):
    d = np.diff(coord)
    if len(d) == 0:
        return np.array([coord[0] - 0.5, coord[0] + 0.5])
    edges = np.concatenate([
        [coord[0] - d[0] / 2],
        coord[:-1] + d / 2,
        [coord[-1] + d[-1] / 2]
    ])
    return edges

lon_edges = build_edges(lon)
lat_edges = build_edges(lat)
lon2d, lat2d = np.meshgrid(lon_edges, lat_edges)

# ============================================================
# COLOR MAPS & NORMALIZATION
# ============================================================
# (a) Mean Reco: sequential greens
cmap_mean = plt.cm.YlGn
valid_data = reco_mean_v[~np.isnan(reco_mean_v)]
if len(valid_data) > 0:
    vmin_mean = np.nanpercentile(valid_data, 1)
    vmax_mean = np.nanpercentile(valid_data, 99)
    vmin_mean = max(vmin_mean, 0)
else:
    vmin_mean, vmax_mean = 0, 1
norm_mean = mcolors.Normalize(vmin=vmin_mean, vmax=vmax_mean)

# (b,c) Sen's Slope: diverging RdYlGn
slope_abs = np.abs(slope_v[~np.isnan(slope_v)])
if len(slope_abs) > 0:
    vmax_slope = np.nanpercentile(slope_abs, 98)
    vmax_slope = max(vmax_slope, 0.01)
else:
    vmax_slope = 0.01
cmap_slope = plt.cm.RdYlGn
norm_slope = mcolors.TwoSlopeNorm(vmin=-vmax_slope, vcenter=0, vmax=vmax_slope)

# (d) MK Z: diverging RdBu_r
z_abs = np.abs(mk_z_v[~np.isnan(mk_z_v)])
if len(z_abs) > 0:
    vmax_z = np.nanpercentile(z_abs, 98)
    vmax_z = max(vmax_z, 0.01)
else:
    vmax_z = 0.01
cmap_z = plt.cm.RdBu_r
norm_z = mcolors.TwoSlopeNorm(vmin=-vmax_z, vcenter=0, vmax=vmax_z)

# (e) p-value: grayscale reversed
cmap_p = plt.cm.Greys_r
norm_p = mcolors.Normalize(vmin=0, vmax=0.1)


# ============================================================
# FIGURE LAYOUT: 2 x 3 nested gridspecs
# Each cell: [ lon_profile on top | map + lat_profile on bottom ]
# ============================================================
fig = plt.figure(figsize=(18, 12))
fig.patch.set_facecolor('white')

# Main outer gridspec: 2 rows, 3 columns of map units
outer_gs = gridspec.GridSpec(
    nrows=2, ncols=3,
    left=0.04, right=0.98,
    top=0.92, bottom=0.06,
    hspace=0.35, wspace=0.30,
    height_ratios=[1, 1],
    width_ratios=[1, 1, 1],
)

panel_labels = ['a', 'b', 'c', 'd', 'e', 'f']

# Config for each panel
configs = [
    {
        'data': reco_mean_v, 'cmap': cmap_mean, 'norm': norm_mean,
        'title': f'Mean {TARGET} (2000\u20132020)',
        'cbar_label': f'{TARGET} (g C m$^{-2}$ yr$^{-1}$)',
        'profile_xlabel': 'g C m$^{-2}$ yr$^{-1}$',
        'stipple': False,
    },
    {
        'data': slope_v, 'cmap': cmap_slope, 'norm': norm_slope,
        'title': "Sen's Slope (Trend Magnitude)",
        'cbar_label': 'Trend (g C m$^{-2}$ yr$^{-1}$)',
        'profile_xlabel': 'g C m$^{-2}$ yr$^{-1}$',
        'stipple': False,
    },
    {
        'data': slope_sig_v, 'cmap': cmap_slope, 'norm': norm_slope,
        'title': "Sen's Slope (p < 0.05)",
        'cbar_label': 'Significant Trend (g C m$^{-2}$ yr$^{-1}$)',
        'profile_xlabel': 'g C m$^{-2}$ yr$^{-1}$',
        'stipple': False,
    },
    {
        'data': mk_z_v, 'cmap': cmap_z, 'norm': norm_z,
        'title': 'Mann-Kendall Z Statistic',
        'cbar_label': 'Z Score',
        'profile_xlabel': 'Z Score',
        'stipple': False,
    },
    {
        'data': mk_p_v, 'cmap': cmap_p, 'norm': norm_p,
        'title': 'Mann-Kendall p-value',
        'cbar_label': 'p-value',
        'profile_xlabel': 'p-value',
        'stipple': False,
    },
    {
        'data': reco_mean_v, 'cmap': cmap_mean, 'norm': norm_mean,
        'title': f'Mean {TARGET} with Significant Trends',
        'cbar_label': f'{TARGET} (g C m$^{-2}$ yr$^{-1}$)',
        'profile_xlabel': 'g C m$^{-2}$ yr$^{-1}$',
        'stipple': True,
    },
]


def draw_map_with_profiles(fig, outer_gs, row, col, config, label_idx):
    """
    Create a nested gridspec for one map cell containing:
      - longitude profile (top, spanning map width)
      - main Robinson map (bottom-left, large area)
      - latitude profile (bottom-right, spanning map height)
      - colorbar (below map, spanning full width)
    """
    # Nested gridspec for this map unit: 3 rows x 2 cols
    # Row 0: lon profile (col 0) + empty (col 1)
    # Row 1: map (col 0) + lat profile (col 1)
    # Row 2: colorbar (spanning both cols)
    inner = outer_gs[row, col].subgridspec(
        nrows=3, ncols=2,
        height_ratios=[0.22, 1.0, 0.12],
        width_ratios=[1.0, 0.18],
        hspace=0.05, wspace=0.05,
    )

    data = config['data']
    cmap = config['cmap']
    norm = config['norm']

    # --------------------------------------------------------
    # 1) LONGITUDE PROFILE (top-left of nested grid)
    # --------------------------------------------------------
    ax_lon_prof = fig.add_subplot(inner[0, 0])

    # Meridional mean (mean over latitude for each longitude)
    mean_lon = np.nanmean(data, axis=0)
    upper_lon = np.nanpercentile(data, 75, axis=0)
    lower_lon = np.nanpercentile(data, 25, axis=0)

    # Only show longitudes where mangroves exist (mask extreme values)
    valid_mask = ~np.isnan(mean_lon) & (lon >= -180) & (lon <= 180)
    lon_plot = lon[valid_mask]
    mean_lon_plot = mean_lon[valid_mask]
    upper_lon_plot = upper_lon[valid_mask]
    lower_lon_plot = lower_lon[valid_mask]

    if len(lon_plot) > 1:
        # Gray shading for IQR
        ax_lon_prof.fill_between(
            lon_plot, lower_lon_plot, upper_lon_plot,
            color='#bbbbbb', alpha=0.45, linewidth=0
        )
        # Colored mean line using segments
        plot_colored_line(
            ax_lon_prof, lon_plot, mean_lon_plot, mean_lon_plot,
            cmap, norm, linewidth=2
        )

    ax_lon_prof.set_xlim(-180, 180)
    ax_lon_prof.set_ylim(norm.vmin, norm.vmax)
    ax_lon_prof.set_xticks([])          # no x-ticks (shared with map below)
    ax_lon_prof.set_xticklabels([])
    ax_lon_prof.set_yticks([])          # no y-ticks (compact)
    ax_lon_prof.set_yticklabels([])
    ax_lon_prof.set_ylabel('Lon.\nprof.', fontsize=6, rotation=0, ha='right', va='center')
    ax_lon_prof.spines['top'].set_visible(False)
    ax_lon_prof.spines['right'].set_visible(False)
    ax_lon_prof.spines['bottom'].set_visible(False)
    ax_lon_prof.tick_params(labelsize=6)
    ax_lon_prof.grid(True, linestyle='--', alpha=0.3)

    # --------------------------------------------------------
    # 2) MAIN MAP (bottom-left of nested grid)
    # --------------------------------------------------------
    ax_map = fig.add_subplot(inner[1, 0], projection=ccrs.Robinson())
    ax_map.set_global()

    # Background
    ax_map.add_feature(cfeature.LAND, facecolor='#d9d9d9', zorder=0)
    ax_map.add_feature(cfeature.OCEAN, facecolor='white', zorder=0)
    ax_map.coastlines(linewidth=0.4, color='#444444', zorder=2)

    # Main pcolormesh
    im = ax_map.pcolormesh(
        lon2d, lat2d, data,
        cmap=cmap, norm=norm,
        transform=ccrs.PlateCarree(),
        zorder=1, shading='flat'
    )

    # Stippling for significant trends (panel f)
    if config.get('stipple', False):
        sig_mask = ~np.isnan(mk_sig_v) & (mk_sig_v == 1)
        if np.any(sig_mask):
            lon_c, lat_c = np.meshgrid(lon, lat)
            ax_map.scatter(
                lon_c[sig_mask], lat_c[sig_mask],
                s=0.4, c='black', marker='.',
                alpha=0.5, transform=ccrs.PlateCarree(), zorder=3
            )
        legend_elements = [
            Line2D([0], [0], marker='.', color='w',
                   markerfacecolor='black', markersize=6,
                   label='Significant (p < 0.05)')
        ]
        ax_map.legend(
            handles=legend_elements, loc='lower left',
            fontsize=6, frameon=True, fancybox=False,
            edgecolor='gray', facecolor='white',
            borderpad=0.4, handletextpad=0.3
        )

    # Panel label
    if label_idx < len(panel_labels):
        ax_map.text(
            0.01, 0.98, f"({panel_labels[label_idx]})",
            transform=ax_map.transAxes,
            fontsize=11, fontweight='bold',
            va='top', ha='left',
            bbox=dict(boxstyle='round,pad=0.15', facecolor='white',
                      edgecolor='none', alpha=0.85)
        )

    ax_map.set_title(config['title'], fontsize=9, pad=6, fontweight='bold')

    # --------------------------------------------------------
    # 3) LATITUDE PROFILE (bottom-right of nested grid, aligned with map)
    # --------------------------------------------------------
    ax_lat_prof = fig.add_subplot(inner[1, 1])

    # Zonal mean (mean over longitude for each latitude)
    mean_lat = np.nanmean(data, axis=1)
    upper_lat = np.nanpercentile(data, 75, axis=1)
    lower_lat = np.nanpercentile(data, 25, axis=1)

    valid_mask_lat = ~np.isnan(mean_lat) & (lat >= -60) & (lat <= 60)
    lat_plot = lat[valid_mask_lat]
    mean_lat_plot = mean_lat[valid_mask_lat]
    upper_lat_plot = upper_lat[valid_mask_lat]
    lower_lat_plot = lower_lat[valid_mask_lat]

    if len(lat_plot) > 1:
        # Gray IQR shading
        ax_lat_prof.fill_betweenx(
            lat_plot, lower_lat_plot, upper_lat_plot,
            color='#bbbbbb', alpha=0.45, linewidth=0
        )
        # Colored mean line using segments
        plot_colored_line(
            ax_lat_prof, mean_lat_plot, lat_plot, mean_lat_plot,
            cmap, norm, linewidth=2
        )

    ax_lat_prof.set_ylim(-60, 60)
    ax_lat_prof.set_xlim(norm.vmin, norm.vmax)
    ax_lat_prof.set_yticks(np.arange(-60, 61, 30))
    ax_lat_prof.set_yticklabels([f'{i}\u00b0' for i in np.arange(-60, 61, 30)], fontsize=7)
    ax_lat_prof.set_xticks([])
    ax_lat_prof.set_xticklabels([])
    ax_lat_prof.set_ylabel('')  # y-label on map axis instead
    ax_lat_prof.set_xlabel('')  # x-label handled by colorbar
    ax_lat_prof.spines['top'].set_visible(False)
    ax_lat_prof.spines['bottom'].set_visible(False)
    ax_lat_prof.spines['right'].set_visible(False)
    ax_lat_prof.tick_params(labelsize=7)
    ax_lat_prof.grid(True, linestyle='--', alpha=0.3)

    # --------------------------------------------------------
    # 4) COLORBAR (bottom row, spanning full width)
    # --------------------------------------------------------
    ax_cbar = fig.add_subplot(inner[2, :])
    ax_cbar.set_visible(False)  # invisible axis just for colorbar
    cbar = fig.colorbar(
        im, ax=ax_cbar, orientation='horizontal',
        pad=0.0, fraction=0.9, shrink=0.95, aspect=30,
        extend='both' if isinstance(norm, mcolors.TwoSlopeNorm) else 'neither'
    )
    cbar.set_label(config['cbar_label'], fontsize=8)
    cbar.ax.tick_params(labelsize=7)

    return ax_map


# ============================================================
# DRAW ALL 6 PANELS
# ============================================================
for idx, cfg in enumerate(configs):
    row = idx // 3
    col = idx % 3
    draw_map_with_profiles(fig, outer_gs, row, col, cfg, idx)

# ============================================================
# FIGURE TITLE
# ============================================================
fig.suptitle(
    f'Global Mangrove {TARGET} Trends (2000\u20132020)\n'
    'Modified Mann-Kendall Test and Theil\u2013Sen Slope Estimator',
    fontsize=12, fontweight='bold', y=0.98
)

# ============================================================
# SAVE
# ============================================================
out_path = os.path.join(OUTPUT_DIR, f'{TARGET}_Trend_Analysis_Nature_Profiles.jpg')
plt.savefig(out_path, dpi=600, bbox_inches='tight',
            facecolor='white', edgecolor='none')
print(f'Saved: {out_path}')

# Also save a vector version
out_pdf = os.path.join(OUTPUT_DIR, f'{TARGET}_Trend_Analysis_Nature_Profiles.pdf')
plt.savefig(out_pdf, dpi=300, bbox_inches='tight',
            facecolor='white', edgecolor='none')
print(f'Saved: {out_pdf}')

plt.show()

# --- Close datasets ---
ds_concat.close()
ds_slope.close()
ds_slope_sig.close()
ds_mkz.close()
ds_mkp.close()
ds_mksig.close()
