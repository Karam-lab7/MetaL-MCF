"""Compare observed and predicted values for all trained models."""
from config import MODEL_OUTPUT_DIR, TARGET

#CREATE FIGURES

# ============================================================
import pandas as pd
import matplotlib.pyplot as plt
import os
import numpy as np

from sklearn.metrics import (
    r2_score,
    mean_absolute_error,
    mean_squared_error
)

# ============================================================
# 📂 FOLDER PATH
# ============================================================

data_folder = str(MODEL_OUTPUT_DIR)

# ============================================================
# 📂 MODEL FILES (UPDATED FOR YOUR NEW FRAMEWORK)
# ============================================================

model_files = {
    "RF": "RF_Predictions.csv",
    "ETR": "ETR_Predictions.csv",
    "XGB": "XGB_Predictions.csv",
    "LGBM": "LGBM_Predictions.csv",
    "CAT": "CAT_Predictions.csv",
    "STACK": "STACK_Predictions.csv"
}

# ============================================================
# 📂 OUTPUT FIGURE
# ============================================================

output_figure = os.path.join(
    data_folder,
    "All_Models_Comparison.png"
)

# ============================================================
# 📊 CREATE FIGURE
# ============================================================

n_models = len(model_files)

fig, axes = plt.subplots(
    1,
    n_models,
    figsize=(6 * n_models, 6),
    squeeze=False
)

axes = axes[0]

# ============================================================
# 🌈 GLOBAL ERROR RANGE
# ============================================================

all_errors = []

for model_name, file_name in model_files.items():
    file_path = os.path.join(data_folder, file_name)
    
    if os.path.exists(file_path):
        df = pd.read_csv(file_path).dropna()
        error = np.abs(df[f"Observed_{TARGET}"] - df[f"Predicted_{TARGET}"])
        all_errors.extend(error)

# Safety fallback (in case something missing)
if len(all_errors) == 0:
    all_errors = [0]

vmin = np.min(all_errors)
vmax = np.max(all_errors)

# ============================================================
# 🔄 LOOP THROUGH MODELS
# ============================================================

for idx, (model_name, file_name) in enumerate(model_files.items()):
    ax = axes[idx]
    file_path = os.path.join(data_folder, file_name)
    
    # --------------------------------------------------------
    # 📥 LOAD FILE
    # --------------------------------------------------------
    
    if not os.path.exists(file_path):
        print(f"❌ File not found: {file_name}")
        ax.set_title(f"{model_name}\n(Missing File)")
        ax.axis("off")
        continue
    
    df = pd.read_csv(file_path)
    
    # --------------------------------------------------------
    # 🧹 CLEAN DATA
    # --------------------------------------------------------
    
    df = df.replace([np.inf, -np.inf], np.nan).dropna()
    
    # Check if required columns exist
    if f"Observed_{TARGET}" not in df.columns or f"Predicted_{TARGET}" not in df.columns:
        print(f"❌ Required columns missing in {file_name}")
        ax.set_title(f"{model_name}\n(Invalid Format)")
        ax.axis("off")
        continue
    
    x = df[f"Observed_{TARGET}"].values
    y = df[f"Predicted_{TARGET}"].values
    
    # --------------------------------------------------------
    # 📊 METRICS
    # --------------------------------------------------------
    
    r2 = r2_score(x, y)
    rmse = np.sqrt(mean_squared_error(x, y))
    mae = mean_absolute_error(x, y)
    
    abs_error = np.abs(x - y)
    
    # --------------------------------------------------------
    # 📈 SCATTER
    # --------------------------------------------------------
    
    scatter = ax.scatter(
        x,
        y,
        c=abs_error,
        cmap="coolwarm",
        s=40,
        alpha=0.85,
        edgecolor="black",
        linewidth=0.3,
        vmin=vmin,
        vmax=vmax
    )
    
    # --------------------------------------------------------
    # 📏 1:1 LINE
    # --------------------------------------------------------
    
    min_val = min(np.min(x), np.min(y))
    max_val = max(np.max(x), np.max(y))
    
    ax.plot([min_val, max_val], [min_val, max_val], "k--", linewidth=1.5, label="1:1 Line")
    
    # --------------------------------------------------------
    # 🏷 LABELS
    # --------------------------------------------------------
    
    ax.set_title(model_name, fontsize=18, fontweight="bold")
    ax.set_xlabel(f"Observed {TARGET}", fontsize=14)
    ax.set_ylabel(f"Predicted {TARGET}", fontsize=14)
    
    ax.grid(True, linestyle="--", alpha=0.4)
    ax.tick_params(axis="both", labelsize=12)
    
    # Set equal aspect ratio
    ax.set_aspect('equal', adjustable='box')
    
    # --------------------------------------------------------
    # 📌 METRICS TEXT
    # --------------------------------------------------------
    
    metrics_text = (
        f"$R^2$ = {r2:.3f}\n"
        f"RMSE = {rmse:.3f}\n"
        f"MAE = {mae:.3f}"
    )
    
    ax.text(
        0.05, 0.95,
        metrics_text,
        transform=ax.transAxes,
        fontsize=12,
        verticalalignment="top",
        bbox=dict(
            facecolor="white",
            edgecolor="black",
            boxstyle="round,pad=0.4"
        )
    )

# ============================================================
# 🌈 COLORBAR
# ============================================================

fig.subplots_adjust(right=0.88)

cbar_ax = fig.add_axes([0.90, 0.15, 0.02, 0.7])

sm = plt.cm.ScalarMappable(
    cmap="coolwarm",
    norm=plt.Normalize(vmin=vmin, vmax=vmax)
)

sm.set_array([])

cbar = fig.colorbar(sm, cax=cbar_ax)

cbar.set_label("|Observed - Predicted|", fontsize=14)
cbar.ax.tick_params(labelsize=12)

# ============================================================
# 🏷 TITLE
# ============================================================
 
plt.suptitle(
    "MetaL-MCF: Model Performance Comparison",
    fontsize=22,
    fontweight="bold"
)

# ============================================================
# 💾 SAVE
# ============================================================

plt.tight_layout(rect=[0, 0, 0.88, 0.94])

plt.savefig(
    output_figure,
    dpi=600,
    bbox_inches="tight"
)

print("\n✅ Figure saved successfully:")
print(f"   {output_figure}")

# Display summary statistics
print("\n📊 Summary Statistics:")
print("-" * 50)
for model_name, file_name in model_files.items():
    file_path = os.path.join(data_folder, file_name)
    if os.path.exists(file_path):
        df = pd.read_csv(file_path).dropna()
        if f"Observed_{TARGET}" in df.columns and f"Predicted_{TARGET}" in df.columns:
            x = df[f"Observed_{TARGET}"].values
            y = df[f"Predicted_{TARGET}"].values
            r2 = r2_score(x, y)
            rmse = np.sqrt(mean_squared_error(x, y))
            mae = mean_absolute_error(x, y)
            print(f"{model_name:6s}: R²={r2:.4f}, RMSE={rmse:.4f}, MAE={mae:.4f}")

plt.show()
