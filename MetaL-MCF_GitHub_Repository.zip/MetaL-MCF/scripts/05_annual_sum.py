"""Aggregate time-dependent NetCDF predictions to annual sums."""
from config import PREDICTIONS_DIR, TARGET

import os
import glob
import xarray as xr
import numpy as np

INPUT_DIR = str(PREDICTIONS_DIR)
OUTPUT_DIR = INPUT_DIR

# Use a strict <TARGET>_YYYY.nc pattern to exclude annual output files
files = sorted(glob.glob(os.path.join(INPUT_DIR, f"{TARGET}_[0-9][0-9][0-9][0-9].nc")))

print(f"Found {len(files)} files")

for f in files:
    print(f"Processing {os.path.basename(f)}")
    
    ds = xr.open_dataset(f)
    
    # Find data variable automatically
    var_name = list(ds.data_vars)[0]
    data = ds[var_name]
    
    # Safety check: only sum if 'time' dimension exists
    if "time" not in data.dims:
        print(f"  ⚠️ Skipping (no 'time' dimension): {os.path.basename(f)}")
        ds.close()
        continue
    
    # Replace zeros with NaN before summing (remove zero background)
    data = data.where(data != 0)
    
    # Annual sum (NaN values are skipped)
    annual = data.sum(dim="time", skipna=True)
    
    # Mask out any pixels that summed to exactly 0
    annual = annual.where(annual != 0)
    
    # Build output dataset
    out_ds = xr.Dataset(
        {var_name: annual},
        coords={
            "lat": ds["lat"],
            "lon": ds["lon"]
        },
        attrs=ds.attrs
    )
    
    # Extract the four-digit year from <TARGET>_YYYY.nc
    year = os.path.basename(f).split("_")[1].split(".")[0]
    
    out_file = os.path.join(OUTPUT_DIR, f"{TARGET}_{year}_annual.nc")
    
    # Set encoding with proper fill value for NaN masking
    fill_value = np.float32(np.nan)
    encoding = {
        var_name: {
            "zlib": True,
            "complevel": 4,
            "dtype": "float32",
            "_FillValue": fill_value
        }
    }
    
    out_ds.to_netcdf(out_file, format="NETCDF4", encoding=encoding)
    ds.close()
    
    print(f"  ✅ Saved: {out_file}")

print("Finished.")
