"""Generate publication-style time-series, spatial-trend, and summary figures."""
from config import PREDICTIONS_DIR, TARGET

# ============================================================
# ============================================================
# 🎨 NATURE PUBLICATION STYLE
# ============================================================
# ============================================================
import os
import glob
import xarray as xr
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
import cartopy.crs as ccrs
import cartopy.feature as cfeature
from matplotlib import rcParams
from matplotlib.lines import Line2D
from scipy import stats
from sklearn.linear_model import LinearRegression
import warnings
warnings.filterwarnings('ignore')

# ============================================================
# 🎨 NATURE PUBLICATION STYLE
# ============================================================
rcParams['font.family'] = 'sans-serif'
rcParams['font.sans-serif'] = ['Arial', 'Helvetica', 'DejaVu Sans']
rcParams['font.size'] = 9
rcParams['axes.labelsize'] = 9
rcParams['axes.titlesize'] = 10
rcParams['xtick.labelsize'] = 8
rcParams['ytick.labelsize'] = 8
rcParams['figure.dpi'] = 300

# ============================================================
# 📂 PATHS
# ============================================================
INPUT_DIR = str(PREDICTIONS_DIR)
OUTPUT_DIR = INPUT_DIR

# Load annual files
annual_files = sorted(glob.glob(os.path.join(INPUT_DIR, f"{TARGET}_[0-9][0-9][0-9][0-9]_annual.nc")))
print(f"Found {len(annual_files)} annual files (2000-2020)")
if not annual_files:
    raise FileNotFoundError(f"No annual {TARGET} NetCDF files found in {INPUT_DIR}")

# ============================================================
# 📥 LOAD DATA WITH DIMENSION CHECKING
# ============================================================
ds_list = []
years = []
for f in annual_files:
    ds = xr.open_dataset(f)
    ds_list.append(ds)
    year = int(os.path.basename(f).split('_')[1])
    years.append(year)

ds_concat = xr.concat(ds_list, dim="time")
ds_concat = ds_concat.assign_coords(time=years)
var_name = list(ds_concat.data_vars)[0]

# Get the data and check dimensions
reco_data = ds_concat[var_name]
print(f"Original data dimensions: {reco_data.dims}")
print(f"Data shape: {reco_data.shape}")

# Ensure data is in (time, lat, lon) order
if 'lat' in reco_data.dims and 'lon' in reco_data.dims:
    # Check if lat/lon are the last dimensions
    if reco_data.dims[-2] != 'lat' or reco_data.dims[-1] != 'lon':
        reco_data = reco_data.transpose('time', 'lat', 'lon')
        print(f"Transposed data to (time, lat, lon)")
elif 'y' in reco_data.dims and 'x' in reco_data.dims:
    # Rename dimensions if needed
    reco_data = reco_data.rename({'y': 'lat', 'x': 'lon'})
    reco_data = reco_data.transpose('time', 'lat', 'lon')

# Get coordinates
lat = reco_data.lat.values
lon = reco_data.lon.values

# Handle longitude
if lon.max() > 180:
    lon_shifted = np.where(lon > 180, lon - 360, lon)
    sort_idx = np.argsort(lon_shifted)
    lon = lon_shifted[sort_idx]
    reco_data = reco_data.isel(lon=sort_idx)

print(f"Final data shape: {reco_data.shape}")
print(f"Dimensions: {reco_data.dims}")
print(f"Latitude range: {lat.min():.2f} to {lat.max():.2f} (n={len(lat)})")
print(f"Longitude range: {lon.min():.2f} to {lon.max():.2f} (n={len(lon)})")

# ============================================================
# 📊 STATISTICAL ANALYSES
# ============================================================

# 1. Global mean time series
global_mean = reco_data.mean(dim=['lat', 'lon'], skipna=True)
global_std = reco_data.std(dim=['lat', 'lon'], skipna=True)
global_min = reco_data.min(dim=['lat', 'lon'], skipna=True)
global_max = reco_data.max(dim=['lat', 'lon'], skipna=True)

# 2. Linear trend analysis (global)
x = np.arange(len(years)).reshape(-1, 1)
y = global_mean.values.reshape(-1, 1)
reg = LinearRegression().fit(x, y)
trend_slope = reg.coef_[0][0]
trend_intercept = reg.intercept_[0]
r2 = reg.score(x, y)

# 3. Mann-Kendall trend test (global)
from scipy.stats import kendalltau
tau, p_value = kendalltau(years, global_mean)

# 4. Decadal analysis
decade1_mean = global_mean.sel(time=slice(2000, 2010)).mean()
decade2_mean = global_mean.sel(time=slice(2011, 2020)).mean()
decade_change = ((decade2_mean - decade1_mean) / decade1_mean) * 100

# 5. Spatial statistics - FIXED with proper dimension handling
nlat, nlon = len(lat), len(lon)
spatial_trend = np.full((nlat, nlon), np.nan)
spatial_pvalue = np.full((nlat, nlon), np.nan)
spatial_r2 = np.full((nlat, nlon), np.nan)

print(f"\nCalculating spatial trends for {nlat} x {nlon} pixels...")

# Convert to numpy array for faster access
reco_array = reco_data.values  # Shape: (time, lat, lon)

for i in range(nlat):
    for j in range(nlon):
        # Extract pixel time series - shape: (time,)
        pixel_data = reco_array[:, i, j]
        
        if ~np.isnan(pixel_data).any():
            x_pixel = np.arange(len(years)).reshape(-1, 1)
            y_pixel = pixel_data.reshape(-1, 1)
            
            try:
                reg_pixel = LinearRegression().fit(x_pixel, y_pixel)
                spatial_trend[i, j] = reg_pixel.coef_[0][0]
                
                # Calculate R² and p-value
                y_pred = reg_pixel.predict(x_pixel)
                ss_res = np.sum((y_pixel - y_pred) ** 2)
                ss_tot = np.sum((y_pixel - np.mean(y_pixel)) ** 2)
                
                if ss_tot > 0:
                    r2_pixel = 1 - (ss_res / ss_tot)
                    spatial_r2[i, j] = r2_pixel
                    
                    # F-statistic for p-value
                    n = len(years)
                    if n > 2 and r2_pixel < 1 and r2_pixel > 0:
                        f_stat = (r2_pixel / 1) / ((1 - r2_pixel) / (n - 2))
                        spatial_pvalue[i, j] = 1 - stats.f.cdf(f_stat, 1, n - 2)
            except Exception as e:
                continue

print(f"Spatial trend calculation complete.")
print(f"  Valid trend pixels: {np.sum(~np.isnan(spatial_trend))}")
print(f"  Significant pixels (p<0.05): {np.sum((spatial_pvalue < 0.05) & (~np.isnan(spatial_pvalue)))}")

# 6. Regional statistics (by latitude bands)
lat_bands = [-90, -60, -30, 0, 30, 60, 90]
lat_labels = ['60-90S', '30-60S', '0-30S', '0-30N', '30-60N', '60-90N']
regional_data = {}
regional_trends = []
correlations = []

for k in range(len(lat_bands)-1):
    mask = (lat >= lat_bands[k]) & (lat < lat_bands[k+1])
    if mask.any():
        # Calculate regional mean
        regional_mean = reco_data.isel(lat=mask).mean(dim=['lat', 'lon'], skipna=True)
        regional_data[lat_labels[k]] = regional_mean.values
        
        # Regional trend
        if len(regional_mean) > 2:
            x_reg = np.arange(len(regional_mean)).reshape(-1, 1)
            y_reg = regional_mean.values.reshape(-1, 1)
            if ~np.isnan(y_reg).any():
                reg_reg = LinearRegression().fit(x_reg, y_reg)
                regional_trends.append(reg_reg.coef_[0][0])
            else:
                regional_trends.append(np.nan)
        else:
            regional_trends.append(np.nan)
        
        # Correlation
        if len(regional_mean) > 2:
            corr, p_val = stats.pearsonr(years, regional_mean)
            correlations.append(corr)
        else:
            correlations.append(np.nan)
    else:
        regional_data[lat_labels[k]] = np.array([])
        regional_trends.append(np.nan)
        correlations.append(np.nan)

# 7. Anomaly analysis
climatology = global_mean.mean(dim='time')
anomalies = global_mean - climatology

# 8. Trend significance mask (p < 0.05)
sig_mask = (spatial_pvalue < 0.05) & (~np.isnan(spatial_pvalue))

# ============================================================
# 📈 PUBLICATION PLOTS
# ============================================================

fig_dir = os.path.join(OUTPUT_DIR, 'Publication_Figures')
os.makedirs(fig_dir, exist_ok=True)

# ------------------------------------------------------------------
# FIGURE 1: Time Series with Trend
# ------------------------------------------------------------------
fig1, axes = plt.subplots(2, 2, figsize=(12, 10))
fig1.suptitle(f'Global Mangrove {TARGET} Time Series Analysis (2000-2020)', 
              fontsize=14, fontweight='bold')

ax1 = axes[0, 0]
ax1.plot(years, global_mean, 'b-', linewidth=2, label=f'Mean {TARGET}')
ax1.fill_between(years, global_mean - global_std, global_mean + global_std, 
                  alpha=0.3, color='blue', label='+/-1 STD')
ax1.plot(years, reg.predict(x), 'r--', linewidth=2, label=f'Trend: {trend_slope:.3f} gC/m2/yr')
ax1.set_xlabel('Year')
ax1.set_ylabel(f'{TARGET} (g C m-2 yr-1)')
ax1.set_title(f'Global Mean {TARGET}')
ax1.legend(loc='best')
ax1.grid(True, alpha=0.3)
ax1.text(0.02, 0.98, f'R2 = {r2:.3f}', transform=ax1.transAxes, 
         verticalalignment='top', fontsize=9, bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))

ax2 = axes[0, 1]
ax2.bar(years, anomalies, color=['red' if a < 0 else 'blue' for a in anomalies])
ax2.axhline(y=0, color='black', linestyle='-', linewidth=0.5)
ax2.set_xlabel('Year')
ax2.set_ylabel(f'{TARGET} Anomaly (g C m-2 yr-1)')
ax2.set_title(f'Annual {TARGET} Anomalies')
ax2.grid(True, alpha=0.3)

ax3 = axes[1, 0]
ax3.hist(global_mean.values, bins=15, edgecolor='black', alpha=0.7)
ax3.axvline(global_mean.mean(), color='red', linestyle='--', 
            label=f'Mean: {global_mean.mean():.2f}')
ax3.set_xlabel(f'{TARGET} (g C m-2 yr-1)')
ax3.set_ylabel('Frequency')
ax3.set_title(f'Distribution of Annual {TARGET}')
ax3.legend()
ax3.grid(True, alpha=0.3)

ax4 = axes[1, 1]
data_by_year = []
for y in years:
    year_data = reco_data.sel(time=y).values.flatten()
    year_data = year_data[~np.isnan(year_data)]
    data_by_year.append(year_data)
bp = ax4.boxplot(data_by_year, positions=years, widths=0.6, 
                 patch_artist=True, showfliers=False)
for box in bp['boxes']:
    box.set_facecolor('lightblue')
    box.set_alpha(0.7)
ax4.set_xlabel('Year')
ax4.set_ylabel(f'{TARGET} (g C m-2 yr-1)')
ax4.set_title(f'Annual {TARGET} Distribution')
ax4.grid(True, alpha=0.3)

plt.tight_layout()
plt.savefig(os.path.join(fig_dir, 'Figure1_TimeSeries_Analysis.jpg'), dpi=600, bbox_inches='tight')
plt.close()

# ------------------------------------------------------------------
# FIGURE 2: Spatial Trends Map
# ------------------------------------------------------------------
fig2 = plt.figure(figsize=(14, 8))
gs = fig2.add_gridspec(2, 3, hspace=0.2, wspace=0.15)

# Create Robinson projection
def plot_spatial_map(ax, data, title, cmap, norm, cbar_label, add_stippling=False, stipple_mask=None):
    ax.set_global()
    ax.add_feature(cfeature.LAND, facecolor='#e0e0e0', zorder=0)
    ax.add_feature(cfeature.OCEAN, facecolor='white', zorder=0)
    ax.coastlines(linewidth=0.4, color='#333333', zorder=2)
    
    # Build edges
    dlon = np.diff(lon)
    dlat = np.diff(lat)
    lon_edges = np.concatenate([[lon[0] - dlon[0]/2], lon[:-1] + dlon/2, [lon[-1] + dlon[-1]/2]])
    lat_edges = np.concatenate([[lat[0] - dlat[0]/2], lat[:-1] + dlat/2, [lat[-1] + dlat[-1]/2]])
    lon2d, lat2d = np.meshgrid(lon_edges, lat_edges)
    
    im = ax.pcolormesh(lon2d, lat2d, data, cmap=cmap, norm=norm, 
                       transform=ccrs.PlateCarree(), zorder=1, shading='flat')
    
    if add_stippling and stipple_mask is not None and np.any(stipple_mask):
        lon_c, lat_c = np.meshgrid(lon, lat)
        ax.scatter(lon_c[stipple_mask], lat_c[stipple_mask], 
                   s=0.5, c='black', marker='.', alpha=0.6, 
                   transform=ccrs.PlateCarree(), zorder=3)
    
    ax.set_title(title, fontsize=10, pad=8, fontweight='bold')
    cbar = plt.colorbar(im, ax=ax, orientation='horizontal', 
                        pad=0.05, fraction=0.04, shrink=0.8)
    cbar.set_label(cbar_label, fontsize=8)
    return im

# Map a: Mean Reco
ax_a = fig2.add_subplot(gs[0, 0], projection=ccrs.Robinson())
mean_reco = reco_data.mean(dim='time').values
valid_mean = mean_reco[~np.isnan(mean_reco)]
vmin_mean = np.nanpercentile(valid_mean, 2) if len(valid_mean) > 0 else 0
vmax_mean = np.nanpercentile(valid_mean, 98) if len(valid_mean) > 0 else 1
plot_spatial_map(ax_a, mean_reco, f'Mean {TARGET} (2000-2020)', 
                 plt.cm.YlGn, mcolors.Normalize(vmin_mean, vmax_mean),
                 f'{TARGET} (g C m-2 yr-1)')
ax_a.text(-0.04, 1.04, '(a)', transform=ax_a.transAxes, fontsize=12, fontweight='bold')

# Map b: Trend
ax_b = fig2.add_subplot(gs[0, 1], projection=ccrs.Robinson())
valid_trend = spatial_trend[~np.isnan(spatial_trend)]
if len(valid_trend) > 0:
    vmax_trend = np.nanpercentile(np.abs(valid_trend), 95)
else:
    vmax_trend = 0.01
plot_spatial_map(ax_b, spatial_trend, 'Linear Trend (2000-2020)',
                 plt.cm.RdYlGn, mcolors.TwoSlopeNorm(vmin=-vmax_trend, vcenter=0, vmax=vmax_trend),
                 'Trend (g C m-2 yr-1)')
ax_b.text(-0.04, 1.04, '(b)', transform=ax_b.transAxes, fontsize=12, fontweight='bold')

# Map c: R2
ax_c = fig2.add_subplot(gs[0, 2], projection=ccrs.Robinson())
plot_spatial_map(ax_c, spatial_r2, 'Goodness of Fit (R2)',
                 plt.cm.Blues, mcolors.Normalize(0, 0.6),
                 'R2')
ax_c.text(-0.04, 1.04, '(c)', transform=ax_c.transAxes, fontsize=12, fontweight='bold')

# Map d: Significance (p-value)
ax_d = fig2.add_subplot(gs[1, 0], projection=ccrs.Robinson())
pvalue_log = -np.log10(spatial_pvalue + 1e-10)
plot_spatial_map(ax_d, pvalue_log, 'Significance (-log10(p-value))',
                 plt.cm.Reds, mcolors.Normalize(0, 3),
                 '-log10(p-value)')
ax_d.text(-0.04, 1.04, '(d)', transform=ax_d.transAxes, fontsize=12, fontweight='bold')

# Map e: Trend (significant only)
ax_e = fig2.add_subplot(gs[1, 1], projection=ccrs.Robinson())
trend_sig = np.where(sig_mask, spatial_trend, np.nan)
plot_spatial_map(ax_e, trend_sig, 'Significant Trends (p < 0.05)',
                 plt.cm.RdYlGn, mcolors.TwoSlopeNorm(vmin=-vmax_trend, vcenter=0, vmax=vmax_trend),
                 'Trend (g C m-2 yr-1)')
ax_e.text(-0.04, 1.04, '(e)', transform=ax_e.transAxes, fontsize=12, fontweight='bold')

# Map f: Mean with significant trends stippled
ax_f = fig2.add_subplot(gs[1, 2], projection=ccrs.Robinson())
plot_spatial_map(ax_f, mean_reco, f'Mean {TARGET} with Significant Trends',
                 plt.cm.YlGn, mcolors.Normalize(vmin_mean, vmax_mean),
                 f'{TARGET} (g C m-2 yr-1)', add_stippling=True, stipple_mask=sig_mask)
ax_f.text(-0.04, 1.04, '(f)', transform=ax_f.transAxes, fontsize=12, fontweight='bold')

# Add legend for stippling
legend_elements = [Line2D([0], [0], marker='.', color='w', 
                           markerfacecolor='black', markersize=5, 
                           label='Significant trend (p < 0.05)')]
ax_f.legend(handles=legend_elements, loc='lower left', 
            fontsize=7, frameon=True, fancybox=False, 
            edgecolor='black', facecolor='white')

plt.suptitle(f'Spatial Patterns of Mangrove {TARGET} and Trends (2000-2020)', 
             fontsize=14, fontweight='bold', y=0.98)
plt.savefig(os.path.join(fig_dir, 'Figure2_Spatial_Trends.jpg'), dpi=600, bbox_inches='tight')
plt.close()

# ------------------------------------------------------------------
# FIGURE 3: Regional Analysis
# ------------------------------------------------------------------
fig3, axes = plt.subplots(2, 2, figsize=(12, 10))
fig3.suptitle(f'Regional Mangrove {TARGET} Analysis', fontsize=14, fontweight='bold')

# Regional time series
ax1 = axes[0, 0]
for label, data in regional_data.items():
    if len(data) > 0:
        ax1.plot(years[:len(data)], data, label=label, linewidth=2)
ax1.set_xlabel('Year')
ax1.set_ylabel(f'{TARGET} (g C m-2 yr-1)')
ax1.set_title(f'Regional {TARGET} Time Series')
ax1.legend(loc='best')
ax1.grid(True, alpha=0.3)

# Regional means comparison
ax2 = axes[0, 1]
regional_means = [np.nanmean(data) for data in regional_data.values() if len(data) > 0]
valid_labels = [label for label, data in regional_data.items() if len(data) > 0]
bars = ax2.barh(valid_labels, regional_means)
ax2.set_xlabel(f'Mean {TARGET} (g C m-2 yr-1)')
ax2.set_title(f'Mean {TARGET} by Latitude Band')
for i, bar in enumerate(bars):
    ax2.text(bar.get_width(), bar.get_y() + bar.get_height()/2, 
             f'{regional_means[i]:.1f}', va='center', ha='left', fontsize=8)
ax2.grid(True, alpha=0.3, axis='x')

# Regional trends
ax3 = axes[1, 0]
valid_trends = [t for t in regional_trends if not np.isnan(t)]
valid_labels_trend = [label for label, t in zip(lat_labels, regional_trends) if not np.isnan(t)]
if len(valid_trends) > 0:
    colors = ['green' if t > 0 else 'red' for t in valid_trends]
    ax3.barh(valid_labels_trend, valid_trends, color=colors)
    ax3.axvline(x=0, color='black', linestyle='-', linewidth=0.5)
    ax3.set_xlabel('Trend (g C m-2 yr-1)')
    ax3.set_title(f'{TARGET} Trend by Latitude Band')
    ax3.grid(True, alpha=0.3, axis='x')

# Correlation with year
ax4 = axes[1, 1]
valid_corr = [c for c in correlations if not np.isnan(c)]
valid_labels_corr = [label for label, c in zip(lat_labels, correlations) if not np.isnan(c)]
if len(valid_corr) > 0:
    ax4.barh(valid_labels_corr, valid_corr)
    ax4.axvline(x=0, color='black', linestyle='-', linewidth=0.5)
    ax4.set_xlabel('Correlation with Year')
    ax4.set_title(f'Correlation of {TARGET} with Year')
    ax4.grid(True, alpha=0.3, axis='x')

plt.tight_layout()
plt.savefig(os.path.join(fig_dir, 'Figure3_Regional_Analysis.jpg'), dpi=600, bbox_inches='tight')
plt.close()

# ------------------------------------------------------------------
# FIGURE 4: Statistical Summary
# ------------------------------------------------------------------
fig4, axes = plt.subplots(1, 2, figsize=(12, 5))
fig4.suptitle(f'Statistical Summary of Global Mangrove {TARGET}', fontsize=14, fontweight='bold')

# Summary statistics table
stats_data = {
    'Statistic': [f'Mean {TARGET}', 'Std Dev', 'Min', 'Max', 'Range', 'CV (%)', 
                  'Trend (per year)', 'R2', "Kendall's tau", 'p-value', 
                  'Decadal Change (%)'],
    'Value': [f'{float(global_mean.mean()):.2f}',
              f'{float(global_mean.std()):.2f}',
              f'{float(global_min.min()):.2f}',
              f'{float(global_max.max()):.2f}',
              f'{float(global_max.max() - global_min.min()):.2f}',
              f'{float(global_mean.std()/global_mean.mean()*100):.1f}',
              f'{trend_slope:.3f}',
              f'{r2:.3f}',
              f'{tau:.3f}',
              f'{p_value:.4f}',
              f'{float(decade_change):.1f}']
}

ax1 = axes[0]
ax1.axis('tight')
ax1.axis('off')
table = ax1.table(cellText=[stats_data['Statistic'], stats_data['Value']],
                   rowLabels=['Parameter', 'Value'],
                   cellLoc='center', loc='center')
table.auto_set_font_size(False)
table.set_fontsize(10)
table.scale(1, 2)

# Q-Q plot for normality check
ax2 = axes[1]
stats.probplot(global_mean.values, dist="norm", plot=ax2)
ax2.set_title(f'Q-Q Plot of Annual {TARGET} (Normality Check)')
ax2.grid(True, alpha=0.3)

plt.tight_layout()
plt.savefig(os.path.join(fig_dir, 'Figure4_Statistical_Summary.jpg'), dpi=600, bbox_inches='tight')
plt.close()

# ------------------------------------------------------------------
# FIGURE 5: Trend Decomposition
# ------------------------------------------------------------------
fig5, axes = plt.subplots(2, 1, figsize=(10, 8))
fig5.suptitle(f'Trend Decomposition of Global {TARGET}', fontsize=14, fontweight='bold')

# Moving averages
window = min(5, len(years))
ma = np.convolve(global_mean, np.ones(window)/window, mode='valid')

ax1 = axes[0]
ax1.plot(years, global_mean, 'b-', alpha=0.5, label='Original')
ax1.plot(years[window-1:], ma, 'r-', linewidth=2, label=f'{window}-year Moving Average')
ax1.set_xlabel('Year')
ax1.set_ylabel(f'{TARGET} (g C m-2 yr-1)')
ax1.set_title('Moving Average Smoothing')
ax1.legend()
ax1.grid(True, alpha=0.3)

# Cumulative change
ax2 = axes[1]
cumulative_change = (global_mean / global_mean[0] - 1) * 100
ax2.fill_between(years, 0, cumulative_change, 
                  color='green' if cumulative_change[-1] > 0 else 'red', alpha=0.3)
ax2.plot(years, cumulative_change, 'k-', linewidth=2)
ax2.axhline(y=0, color='black', linestyle='-', linewidth=0.5)
ax2.set_xlabel('Year')
ax2.set_ylabel('Cumulative Change (%)')
ax2.set_title('Cumulative Change Relative to 2000')
ax2.text(years[-1], cumulative_change[-1], f'{cumulative_change[-1]:.1f}%', 
         verticalalignment='bottom', horizontalalignment='right', fontsize=10, fontweight='bold')
ax2.grid(True, alpha=0.3)

plt.tight_layout()
plt.savefig(os.path.join(fig_dir, 'Figure5_Trend_Decomposition.jpg'), dpi=600, bbox_inches='tight')
plt.close()

# ============================================================
# 📊 EXPORT STATISTICAL RESULTS
# ============================================================

with open(os.path.join(fig_dir, 'Statistical_Summary.txt'), 'w', encoding='utf-8') as f:
    f.write('='*80 + '\n')
    f.write(f'MANGROVE {TARGET} STATISTICAL ANALYSIS (2000-2020)\n')
    f.write('='*80 + '\n\n')
    
    f.write('1. GLOBAL STATISTICS\n')
    f.write('-'*40 + '\n')
    f.write(f'Years: {years[0]} - {years[-1]} (n={len(years)})\n')
    f.write(f'Mean {TARGET}: {float(global_mean.mean()):.2f} +/- {float(global_mean.std()):.2f} g C m-2 yr-1\n')
    f.write(f'Range: {float(global_min.min()):.2f} - {float(global_max.max()):.2f} g C m-2 yr-1\n')
    f.write(f'Coefficient of Variation: {float(global_mean.std()/global_mean.mean()*100):.1f}%\n\n')
    
    f.write('2. TREND ANALYSIS\n')
    f.write('-'*40 + '\n')
    f.write(f'Linear Trend: {trend_slope:.4f} g C m-2 yr-1\n')
    f.write(f'R2: {r2:.4f}\n')
    f.write(f"Mann-Kendall tau: {tau:.4f}\n")
    f.write(f'p-value: {p_value:.6f}\n')
    f.write(f'Significant: {"Yes" if p_value < 0.05 else "No"}\n\n')
    
    f.write('3. DECADAL ANALYSIS\n')
    f.write('-'*40 + '\n')
    f.write(f'2000-2010 Mean: {float(decade1_mean):.2f} g C m-2 yr-1\n')
    f.write(f'2011-2020 Mean: {float(decade2_mean):.2f} g C m-2 yr-1\n')
    f.write(f'Decadal Change: {float(decade_change):.1f}%\n\n')
    
    f.write('4. SPATIAL STATISTICS\n')
    f.write('-'*40 + '\n')
    n_sig = int(np.sum(sig_mask))
    n_total = sig_mask.size
    f.write(f'Significant pixels (p<0.05): {n_sig} ({n_sig/n_total*100:.1f}%)\n')
    f.write(f'Increasing trends: {int(np.sum(spatial_trend > 0))} pixels\n')
    f.write(f'Decreasing trends: {int(np.sum(spatial_trend < 0))} pixels\n\n')
    
    f.write('5. REGIONAL STATISTICS\n')
    f.write('-'*40 + '\n')
    for i, (label, data) in enumerate(regional_data.items()):
        if len(data) > 0:
            f.write(f'{label}:\n')
            f.write(f'  Mean: {float(np.nanmean(data)):.2f} g C m-2 yr-1\n')
            if i < len(regional_trends) and not np.isnan(regional_trends[i]):
                f.write(f'  Trend: {regional_trends[i]:.4f} g C m-2 yr-1\n')
            if i < len(correlations) and not np.isnan(correlations[i]):
                f.write(f'  Correlation: {correlations[i]:.4f}\n')
            f.write('\n')

print(f"\nAll figures saved to: {fig_dir}")
print(f"Statistical summary saved to: {os.path.join(fig_dir, 'Statistical_Summary.txt')}")

# ============================================================
# 🧹 CLEANUP
# ============================================================
for ds in ds_list:
    ds.close()
ds_concat.close()

print("\nAnalysis complete!")
