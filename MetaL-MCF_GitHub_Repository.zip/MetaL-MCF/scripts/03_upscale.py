"""Upscale the trained stacking model using yearly predictor CSV files."""
from config import (
    UPSCALING_DIR, STACK_MODEL_PATH, PREDICTIONS_DIR, TARGET,
    CHUNK_SIZE, PREDICT_BATCH_SIZE,
)

# ==========================================================
import os
import pandas as pd
import numpy as np
import joblib
from tqdm import tqdm

# ==========================================================
# PATHS
# ==========================================================
BASE_UPSCALING_DIR = str(UPSCALING_DIR)   # yearly folders containing external predictor datasets
MODEL_PATH = str(STACK_MODEL_PATH)
OUTPUT_DIR = str(PREDICTIONS_DIR)

os.makedirs(OUTPUT_DIR, exist_ok=True)

# ==========================================================
# SETTINGS
# ==========================================================
# Chunk sizes are imported from config.py

# MUST MATCH TRAINING FEATURES OF STACK_Model.pkl
FEATURES = [
    'DTR',
    'GDD',
    'VPD',
    'TIavg',
    'TImax',
    'TImin',
    'SI',
    'E0',
    'PI',
    'SSH',
    'SST',
    'DO',
    'Chla'
]

# TARGET is imported from config.py

# ==========================================================
# INPUT FILES
# ==========================================================
def get_feature_files(year):
    return {
        'DTR': f'DTR_{year}.csv',
        'GDD': f'GDD_{year}.csv',
        'VPD': f'VPD_{year}.csv',
        'TIavg': f'TIavg_{year}.csv',
        'TImax': f'TImax_{year}.csv',
        'TImin': f'TImin_{year}.csv',
        'SI': f'SI_{year}.csv',
        'E0': f'E0_{year}.csv',
        'PI': f'PI_{year}.csv',
        'SSH': f'SSH_{year}.csv',
        'SST': f'SST_{year}.csv',
        'DO': f'DO_{year}.csv',
        'Chla': f'chla_{year}.csv'
    }

# ==========================================================
# LOAD CHUNK
# ==========================================================
def load_chunk(year_dir, feature_files, start_row, nrows):

    merged_df = None
    common_cols = ['X', 'Y']

    for feature, filename in feature_files.items():

        file_path = os.path.join(year_dir, filename)

        if not os.path.exists(file_path):
            print(f"Missing file: {file_path}")
            return None

        try:
            df = pd.read_csv(
                file_path,
                skiprows=range(1, start_row + 1) if start_row > 0 else None,
                nrows=nrows
            )
        except Exception as e:
            print(f"Error reading {file_path}: {e}")
            return None

        # standardize coordinates
        rename_dict = {}

        if 'lon' in df.columns:
            rename_dict['lon'] = 'X'

        if 'lat' in df.columns:
            rename_dict['lat'] = 'Y'

        if rename_dict:
            df = df.rename(columns=rename_dict)

        if ('X' not in df.columns) or ('Y' not in df.columns):
            print(f"X/Y columns not found in {file_path}")
            return None

        date_cols = [c for c in df.columns if c not in common_cols]

        df_long = df.melt(
            id_vars=common_cols,
            value_vars=date_cols,
            var_name='Date',
            value_name=feature
        )

        if merged_df is None:
            merged_df = df_long
        else:
            merged_df = pd.merge(
                merged_df,
                df_long,
                on=['X', 'Y', 'Date'],
                how='inner'
            )

    return merged_df

# ==========================================================
# UPSCALING
# ==========================================================
def upscale_year(year):

    print(f"\n{'='*70}")
    print(f"Upscaling {TARGET} for Year: {year}")
    print(f"{'='*70}")

    year_dir = os.path.join(BASE_UPSCALING_DIR, year)

    feature_files = get_feature_files(year)

    sample_file = os.path.join(year_dir, feature_files['VPD'])

    if not os.path.exists(sample_file):
        print(f"Sample file not found: {sample_file}")
        return

    print("Loading STACK model...")
    model = joblib.load(MODEL_PATH)

    with open(sample_file, "r", encoding="utf-8") as f:
        total_rows = sum(1 for _ in f) - 1

    print(f"Total spatial rows: {total_rows:,}")

    predictions = []

    for start_row in tqdm(
        range(0, total_rows, CHUNK_SIZE),
        desc=f"{year}"
    ):

        chunk_df = load_chunk(
            year_dir,
            feature_files,
            start_row,
            CHUNK_SIZE
        )

        if chunk_df is None:
            continue

        # keep only complete records
        chunk_df = chunk_df.dropna(subset=FEATURES)

        if chunk_df.empty:
            continue

        X_pred = chunk_df[FEATURES].astype(np.float32)

        batch_predictions = []

        for i in range(0, len(X_pred), PREDICT_BATCH_SIZE):

            batch = X_pred.iloc[i:i + PREDICT_BATCH_SIZE]

            pred = model.predict(batch)

            batch_predictions.append(pred)

        chunk_df[f"{TARGET}"] = np.concatenate(batch_predictions)

        predictions.append(
            chunk_df[
                ['X', 'Y', 'Date', f'{TARGET}']
            ]
        )

    if len(predictions) == 0:
        print(f"No predictions generated for {year}")
        return

    final_df = pd.concat(predictions, ignore_index=True)

    final_df["Date"] = final_df["Date"].astype(str)

    output_file = os.path.join(
        OUTPUT_DIR,
        f"predictions_{TARGET}_{year}.parquet"
    )

    final_df.to_parquet(
        output_file,
        index=False,
        compression="snappy"
    )

    print(f"\nSaved: {output_file}")
    print(f"Records: {len(final_df):,}")

# ==========================================================
# MAIN
# ==========================================================
if __name__ == "__main__":

    if not os.path.exists(MODEL_PATH):
        raise FileNotFoundError(
            f"Model not found:\n{MODEL_PATH}"
        )

    if not os.path.isdir(BASE_UPSCALING_DIR):
        raise FileNotFoundError(f"Upscaling directory not found:\n{BASE_UPSCALING_DIR}")

    years = sorted([
        d for d in os.listdir(BASE_UPSCALING_DIR)
        if os.path.isdir(os.path.join(BASE_UPSCALING_DIR, d))
    ])

    if len(years) == 0:
        raise ValueError(
            f"No yearly folders found in:\n{BASE_UPSCALING_DIR}"
        )

    print(f"\nFound {len(years)} years:")
    print(years)

    for year in years:
        upscale_year(year)

    print(f"\nFinished {TARGET} upscaling.")
