"""Optional raw-data extraction, predictor preparation, and driver figures.

This is the author's sequential preprocessing workflow, not a one-click requirement
for modeling. If you use the prepared supplementary modeling/upscaling files, start
with 02_train_metal_mcf.py. Review the input filenames in each section you run.
All original Windows folders have been moved to config.py / DATA_DIR.
"""
from config import DATA_DIR, COORDINATES_FILE


# =====================================Fast Exrection 
import pandas as pd
import xarray as xr
import numpy as np
from scipy.spatial import cKDTree

# =====================================
# 1. Open NetCDF
# =====================================
ds = xr.open_dataset(str(DATA_DIR / 'SST' / 'SST_2007.nc')).squeeze()

# Remove longitude > 180
ds = ds.sel(lon=ds.lon <= 180)

Temp = ds['sst']

# Ensure consistent dimension order
Temp = Temp.transpose("lat", "lon", "time")

print(ds)
print("Dataset loaded")

# =====================================
# 2. Load CSV coordinates
# =====================================
df = pd.read_csv(str(COORDINATES_FILE))
df.rename(columns={'longitude': 'lon', 'latitude': 'lat'}, inplace=True)

query_points = df[['lat', 'lon']].values

# =====================================
# 3. Build KDTree
# =====================================
Temp0 = Temp.isel(time=0).values

lon_vals = ds.lon.values
lat_vals = ds.lat.values

# Create spatial grid
lat2d, lon2d = np.meshgrid(lat_vals, lon_vals, indexing='ij')

# Valid pixels mask
valid_mask = ~np.isnan(Temp0)

ocean_points = np.column_stack((
    lat2d[valid_mask],
    lon2d[valid_mask]
))

print("Ocean pixels:", ocean_points.shape[0])

# Build KDTree
tree = cKDTree(ocean_points)

# =====================================
# 4. Query nearest ocean pixel
# =====================================
_, idx = tree.query(query_points)

nearest_lat = ocean_points[idx][:, 0]
nearest_lon = ocean_points[idx][:, 1]

# =====================================
# 5. Convert lat/lon to grid index
# =====================================
lon_index = np.searchsorted(lon_vals, nearest_lon)
lat_index = np.searchsorted(lat_vals, nearest_lat)

lon_index = np.clip(lon_index, 0, len(lon_vals)-1)
lat_index = np.clip(lat_index, 0, len(lat_vals)-1)

# =====================================
# 6. Extract full time series
# =====================================
Temp_values = Temp.values   # shape: (lat, lon, time)

extracted = Temp_values[lat_index, lon_index, :]   # (points, time)

print("Extraction complete")

# =====================================
# 7. Build final dataframe
# =====================================
time_str = pd.to_datetime(ds.time.values).strftime("%Y%m%d")

result_df = pd.DataFrame(extracted, columns=time_str)

result_df.insert(0, 'Y', df['lat'].values)
result_df.insert(0, 'X', df['lon'].values)

# =====================================
# 8. Save output
# =====================================
result_df.to_csv(
    str(DATA_DIR / 'SST' / 'SST_2007_KDTree.csv'),
    index=False
)

print(result_df.head())
print("KDTree extraction completed ✅")
## =====================================


## =====================================
# This code calculates average actual vapor pressure (ea)
# from DPTmin and DPTmax for all years (2000–2020)

import pandas as pd
import numpy as np
import os

# Folders
input_folder = str(DATA_DIR / 'DPT')
output_folder = str(DATA_DIR / 'eaT')

# Create output folder if not exists
os.makedirs(output_folder, exist_ok=True)

# Loop through years
for year in range(2000, 2021):

    print(f'\nProcessing year: {year}')

    # Define possible filename patterns
    possible_min = [
        f'DPT min_KDTee_{year}.csv',
        f'DPT_min_KDTee_{year}.csv'
    ]

    possible_max = [
        f'DPT_max_KDTee_{year}.csv',
        f'DPT max_KDTee_{year}.csv'
    ]

    # Find correct files
    file_min = None
    file_max = None

    for f in possible_min:
        path = os.path.join(input_folder, f)
        if os.path.exists(path):
            file_min = path
            break

    for f in possible_max:
        path = os.path.join(input_folder, f)
        if os.path.exists(path):
            file_max = path
            break

    # Skip if files not found
    if file_min is None or file_max is None:
        print(f'⚠️ Missing files for {year}, skipping...')
        continue

    print(f'✔ Using files:\n{file_min}\n{file_max}')

    # Load CSV files
    df_min = pd.read_csv(file_min)
    df_max = pd.read_csv(file_max)

    # Extract X, Y coordinates
    coords = df_min.iloc[:, 0:2]

    # Extract DPT values (from 3rd column onward)
    Tdmin = df_min.iloc[:, 2:].apply(pd.to_numeric, errors='coerce')
    Tdmax = df_max.iloc[:, 2:].apply(pd.to_numeric, errors='coerce')

    # Compute eaTavg (vectorized)
    eaTavg_values = (
        0.6108 * np.exp((17.27 * Tdmin.values) / (Tdmin.values + 237.3)) +
        0.6108 * np.exp((17.27 * Tdmax.values) / (Tdmax.values + 237.3))
    ) / 2

    # Convert back to DataFrame with same column names
    eaTavg_values = pd.DataFrame(eaTavg_values, columns=Tdmin.columns)

    # Combine coordinates + results
    result = pd.concat([coords, eaTavg_values], axis=1)

    # Save output
    output_file = os.path.join(output_folder, f'eaTavg_{year}.csv')
    result.to_csv(output_file, index=False)

    print(f'✅ Saved: {output_file}')

print("\n🎯 All available years processed successfully!")



## =====================================
# This code calculates average saturated vapor pressure (es)
# from Tmin and Tmax for all years (2000–2020)

import pandas as pd
import numpy as np
import os

# Folders
input_folder = str(DATA_DIR / 'Temp')
output_folder = str(DATA_DIR / 'esT')

os.makedirs(output_folder, exist_ok=True)

# Loop through years
for year in range(2000, 2021):

    print(f'\nProcessing year: {year}')

    # Possible file patterns (robust)
    possible_min = [
        f'Temp_min_KDTree_{year}.csv',
        f'Temp min_KDTree_{year}.csv'
    ]

    possible_max = [
        f'Temp_max_KDTree_{year}.csv',
        f'Temp max_KDTree_{year}.csv'
    ]

    # Detect files
    file_min = None
    file_max = None

    for f in possible_min:
        path = os.path.join(input_folder, f)
        if os.path.exists(path):
            file_min = path
            break

    for f in possible_max:
        path = os.path.join(input_folder, f)
        if os.path.exists(path):
            file_max = path
            break

    # Skip if missing
    if file_min is None or file_max is None:
        print(f'⚠️ Missing files for {year}, skipping...')
        continue

    print(f'✔ Using:\n{file_min}\n{file_max}')

    # Load data
    df_min = pd.read_csv(file_min)
    df_max = pd.read_csv(file_max)

    # ✅ Safety check (VERY IMPORTANT)
    if df_min.shape != df_max.shape:
        print(f'❌ Shape mismatch in {year}, skipping...')
        continue

    if not (df_min.columns.equals(df_max.columns)):
        print(f'❌ Column mismatch in {year}, skipping...')
        continue

    # Extract coordinates
    coords = df_min.iloc[:, 0:2]

    # Extract temperature values (from 3rd column onward)
    Tmin = df_min.iloc[:, 2:].apply(pd.to_numeric, errors='coerce')
    Tmax = df_max.iloc[:, 2:].apply(pd.to_numeric, errors='coerce')

    # Compute esTavg (FAO-56 equation)
    esTavg_values = (
        0.6108 * np.exp((17.27 * Tmin.values) / (Tmin.values + 237.3)) +
        0.6108 * np.exp((17.27 * Tmax.values) / (Tmax.values + 237.3))
    ) / 2

    # Back to DataFrame
    esTavg_values = pd.DataFrame(esTavg_values, columns=Tmin.columns)

    # Combine with coordinates
    result = pd.concat([coords, esTavg_values], axis=1)

    # Save
    output_file = os.path.join(output_folder, f'esTavg_{year}.csv')
    result.to_csv(output_file, index=False)

    print(f'✅ Saved: {output_file}')

print("\n🎯 All available years processed successfully!")

## =====================================
# This code calculates Vapor Pressure Deficit (VPD)
# using: VPD = es - ea

import pandas as pd
import numpy as np
import os

# Input folders
ea_folder = str(DATA_DIR / 'eaT')
es_folder = str(DATA_DIR / 'esT')

# Output folder
output_folder = str(DATA_DIR / 'VPD')
os.makedirs(output_folder, exist_ok=True)

# Loop over years
for year in range(2000, 2021):

    print(f'\nProcessing year: {year}')

    # File paths
    file_ea = os.path.join(ea_folder, f'eaTavg_{year}.csv')
    file_es = os.path.join(es_folder, f'esTavg_{year}.csv')

    # Check existence
    if not os.path.exists(file_ea) or not os.path.exists(file_es):
        print(f'⚠️ Missing ea/es files for {year}, skipping...')
        continue

    print(f'✔ Using:\n{file_ea}\n{file_es}')

    # Load data
    df_ea = pd.read_csv(file_ea)
    df_es = pd.read_csv(file_es)

    # Safety checks
    if df_ea.shape != df_es.shape:
        print(f'❌ Shape mismatch in {year}, skipping...')
        continue

    if not df_ea.columns.equals(df_es.columns):
        print(f'❌ Column mismatch in {year}, skipping...')
        continue

    # Extract coordinates
    coords = df_ea.iloc[:, 0:2]

    # Extract values (from 3rd column onward)
    ea = df_ea.iloc[:, 2:].apply(pd.to_numeric, errors='coerce')
    es = df_es.iloc[:, 2:].apply(pd.to_numeric, errors='coerce')

    # Compute VPD
    vpd_values = es.values - ea.values

    # Optional: avoid negative values (recommended)
    vpd_values[vpd_values < 0] = 0

    # Convert back to DataFrame
    vpd_df = pd.DataFrame(vpd_values, columns=ea.columns)

    # Combine with coordinates
    result = pd.concat([coords, vpd_df], axis=1)

    # Save output
    output_file = os.path.join(output_folder, f'VPD_{year}.csv')
    result.to_csv(output_file, index=False)

    print(f'✅ Saved: {output_file}')

print("\n🎯 VPD calculation completed for all available years!")
## =====================================
#Compute Annual Average VPD
import pandas as pd
import numpy as np
import os

# Folder containing yearly VPD files
vpd_folder = str(DATA_DIR / 'VPD')

# Output file (all years average optional)
output_folder = str(DATA_DIR / 'VPD_Annual')
os.makedirs(output_folder, exist_ok=True)

for year in range(2000, 2021):

    print(f'Processing {year}')

    file_path = os.path.join(vpd_folder, f'VPD_{year}.csv')

    if not os.path.exists(file_path):
        print(f'⚠️ Missing {year}, skipping...')
        continue

    df = pd.read_csv(file_path)

    # Coordinates
    coords = df.iloc[:, 0:2]

    # Daily VPD values
    vpd_daily = df.iloc[:, 2:].apply(pd.to_numeric, errors='coerce')

    # Annual mean
    vpd_mean = vpd_daily.mean(axis=1)

    # Combine
    result = pd.concat([coords, vpd_mean.rename('VPD_mean')], axis=1)

    # Save
    out_file = os.path.join(output_folder, f'VPD_annual_{year}.csv')
    result.to_csv(out_file, index=False)

    print(f'✅ Saved {out_file}')
## =====================================

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature
import os
from matplotlib.collections import LineCollection
import matplotlib as mpl

# =====================================
# 📂 LOAD MULTI-YEAR VPD DATA
# =====================================

folder = str(DATA_DIR / 'VPD_Annual')

all_vpd = []
coords = None

for year in range(2000, 2021):

    file_path = os.path.join(folder, f'VPD_annual_{year}.csv')

    if not os.path.exists(file_path):
        print(f'⚠️ Missing {year}, skipping...')
        continue

    df = pd.read_csv(file_path)

    if coords is None:
        coords = df.iloc[:, 0:2]

    all_vpd.append(df['VPD_mean'])

# Stack & compute multi-year mean
vpd_stack = pd.concat(all_vpd, axis=1)
vpd_mean = vpd_stack.mean(axis=1)

df_final = coords.copy()
df_final.columns = ['lon', 'lat']
df_final['VPD'] = vpd_mean

# =====================================
# 🌐 CREATE 0.25° GRID
# =====================================

res = 0.25

lon_centers = np.arange(-180 + res/2, 180, res)
lat_centers = np.arange(-90 + res/2, 90, res)

vpd_grid = np.full((len(lat_centers), len(lon_centers)), np.nan)
count_grid = np.zeros_like(vpd_grid)
sum_grid = np.zeros_like(vpd_grid)

lon_idx = ((df_final['lon'] + 180) / res).astype(int)
lat_idx = ((df_final['lat'] + 90) / res).astype(int)

lon_idx = np.clip(lon_idx, 0, len(lon_centers)-1)
lat_idx = np.clip(lat_idx, 0, len(lat_centers)-1)

for i in range(len(df_final)):
    x = lon_idx.iloc[i]
    y = lat_idx.iloc[i]
    val = df_final['VPD'].iloc[i]

    if not np.isnan(val):
        sum_grid[y, x] += val
        count_grid[y, x] += 1

vpd_grid = sum_grid / count_grid
vpd_grid[count_grid == 0] = np.nan

lon2d, lat2d = np.meshgrid(lon_centers, lat_centers)

# =====================================
# 📊 LATITUDINAL STATISTICS
# =====================================

latitudes = lat_centers

lat_mean = np.nanmean(vpd_grid, axis=1)
lat_upper = np.nanpercentile(vpd_grid, 75, axis=1)
lat_lower = np.nanpercentile(vpd_grid, 25, axis=1)

# =====================================
# 🎨 COLOR NORMALIZATION (SHARED)
# =====================================

vmin = np.nanpercentile(vpd_grid, 5)
vmax = np.nanpercentile(vpd_grid, 95)

cmap = plt.get_cmap('RdYlBu_r')
norm = mpl.colors.Normalize(vmin=vmin, vmax=vmax)

# =====================================
# 🎨 FIGURE LAYOUT
# =====================================

fig = plt.figure(figsize=(18, 8))

gs = fig.add_gridspec(
    nrows=1, ncols=2,
    width_ratios=[4, 1],
    wspace=0.05
)

# ---- MAP ----
ax_map = fig.add_subplot(gs[0], projection=ccrs.Robinson())
ax_map.set_global()

ax_map.add_feature(cfeature.LAND, facecolor='#d9d9d9')
ax_map.add_feature(cfeature.OCEAN, facecolor='white')
ax_map.coastlines(linewidth=0.6, color='gray')

ax_map.gridlines(draw_labels=False)
ax_map.set_xticks([])
ax_map.set_yticks([])

im = ax_map.pcolormesh(
    lon2d,
    lat2d,
    vpd_grid,
    cmap=cmap,
    norm=norm,
    transform=ccrs.PlateCarree(),
    shading='auto'
)

# ---- PROFILE ----
ax_prof = fig.add_subplot(gs[1])

# Create colored line segments
points = np.array([lat_mean, latitudes]).T.reshape(-1, 1, 2)
segments = np.concatenate([points[:-1], points[1:]], axis=1)

lc = LineCollection(
    segments,
    cmap=cmap,
    norm=norm,
    linewidth=2
)

lc.set_array(lat_mean)  # color by VPD values
ax_prof.add_collection(lc)

# Variability envelope (IQR)
ax_prof.fill_betweenx(
    latitudes,
    lat_lower,
    lat_upper,
    color='gray',
    alpha=0.3
)

# Axis alignment
ax_prof.set_ylim(-90, 90)
ax_prof.set_yticks(np.arange(-90, 91, 30))

ax_prof.set_xlim(vmin, vmax)

# Labels
ax_prof.set_xlabel('VPD (kPa)', fontsize=11)
ax_prof.set_ylabel('Latitude (°)', fontsize=11)

ax_prof.grid(True, linestyle='--', alpha=0.4)

# Clean spines
ax_prof.spines['top'].set_visible(False)
ax_prof.spines['right'].set_visible(False)

# ---- COLORBAR ----
cbar = fig.colorbar(
    im,
    ax=ax_map,
    orientation='horizontal',
    pad=0.08,
    fraction=0.05,
    aspect=40
)

cbar.set_label('Multi-Year Mean VPD (kPa, 2000–2020)', fontsize=11)

# ---- TITLE ----
fig.suptitle(
    'Global Mangrove VPD (2000–2020): Spatial Distribution and Latitudinal Structure',
    fontsize=16,
    y=0.98
)

# ---- SAVE ----
plt.savefig(
    str(DATA_DIR / 'VPD_final_colored_profile.png'),
    dpi=600,
    bbox_inches='tight'
)

plt.tight_layout()
plt.show()




# ===============================================
# This code calculates Diurnal Temperature Range (DTR)
# using: DTR = Temp_max - Temp_min
# ===============================================
import pandas as pd
import numpy as np
import os

# Input folder (same for min & max)
input_folder = str(DATA_DIR / 'Temp')

# Output folder
output_folder = str(DATA_DIR / 'DTR')
os.makedirs(output_folder, exist_ok=True)

# Loop over years
for year in range(2000, 2021):

    print(f'\nProcessing year: {year}')

    # Possible file patterns (robust)
    possible_max = [
        f'Temp_max_KDTree_{year}.csv',
        f'Temp max_KDTree_{year}.csv',
        f'Temp_max_{year}.csv'
    ]

    possible_min = [
        f'Temp_min_KDTree_{year}.csv',
        f'Temp min_KDTree_{year}.csv',
        f'Temp_min_{year}.csv'
    ]

    # Detect files
    file_Temp_max = None
    file_Temp_min = None

    for f in possible_max:
        path = os.path.join(input_folder, f)
        if os.path.exists(path):
            file_Temp_max = path
            break

    for f in possible_min:
        path = os.path.join(input_folder, f)
        if os.path.exists(path):
            file_Temp_min = path
            break

    # Skip if missing
    if file_Temp_max is None or file_Temp_min is None:
        print(f'⚠️ Missing Temp files for {year}, skipping...')
        continue

    print(f'✔ Using:\n{file_Temp_max}\n{file_Temp_min}')

    # Load data
    df_Temp_max = pd.read_csv(file_Temp_max)
    df_Temp_min = pd.read_csv(file_Temp_min)

    # Safety checks
    if df_Temp_max.shape != df_Temp_min.shape:
        print(f'❌ Shape mismatch in {year}, skipping...')
        continue

    if not df_Temp_max.columns.equals(df_Temp_min.columns):
        print(f'❌ Column mismatch in {year}, skipping...')
        continue

    # Extract coordinates (first 2 columns)
    coords = df_Temp_max.iloc[:, 0:2]

    # Extract temperature values (from 3rd column onward)
    Temp_max = df_Temp_max.iloc[:, 2:].apply(pd.to_numeric, errors='coerce')
    Temp_min = df_Temp_min.iloc[:, 2:].apply(pd.to_numeric, errors='coerce')

    # =====================================
    # 🔥 Compute DTR
    # =====================================

    DTR_values = Temp_max.values - Temp_min.values

    # Convert back to DataFrame
    DTR_df = pd.DataFrame(DTR_values, columns=Temp_max.columns)

    # Combine with coordinates
    result = pd.concat([coords, DTR_df], axis=1)

    # Save output
    output_file = os.path.join(output_folder, f'DTR_{year}.csv')
    result.to_csv(output_file, index=False)

    print(f'✅ Saved: {output_file}')

print("\n🎯 DTR calculation completed for all available years!")

#======================================================================
# This code calculates Annual Mean DTR
# from daily DTR files (DTR = Tmax - Tmin)

import pandas as pd
import numpy as np
import os

# Folder containing yearly DTR files
dtr_folder = str(DATA_DIR / 'DTR')

# Output folder
output_folder = str(DATA_DIR / 'DTR_Annual')
os.makedirs(output_folder, exist_ok=True)

# Loop over years
for year in range(2000, 2021):

    print(f'Processing {year}')

    file_path = os.path.join(dtr_folder, f'DTR_{year}.csv')

    if not os.path.exists(file_path):
        print(f'⚠️ Missing {year}, skipping...')
        continue

    # Load data
    df = pd.read_csv(file_path)

    # Extract coordinates (first two columns)
    coords = df.iloc[:, 0:2]

    # Extract daily DTR values (from 3rd column onward)
    dtr_daily = df.iloc[:, 2:].apply(pd.to_numeric, errors='coerce')

    # =====================================
    # 🌡️ Compute Annual Mean DTR
    # =====================================

    dtr_mean = dtr_daily.mean(axis=1)

    # Combine coordinates + result
    result = pd.concat([coords, dtr_mean.rename('DTR_mean')], axis=1)

    # Save output
    out_file = os.path.join(output_folder, f'DTR_annual_{year}.csv')
    result.to_csv(out_file, index=False)

    print(f'✅ Saved {out_file}')

print("\n🎯 Annual DTR calculation completed!")
#======================================================================
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature
import os
from matplotlib.collections import LineCollection
import matplotlib as mpl

# =====================================
# 📂 LOAD MULTI-YEAR DTR DATA
# =====================================

folder = str(DATA_DIR / 'DTR_Annual')

all_dtr = []
coords = None

for year in range(2000, 2021):

    file_path = os.path.join(folder, f'DTR_annual_{year}.csv')

    if not os.path.exists(file_path):
        print(f'⚠️ Missing {year}, skipping...')
        continue

    df = pd.read_csv(file_path)

    if coords is None:
        coords = df.iloc[:, 0:2]

    all_dtr.append(df['DTR_mean'])

# Stack & compute multi-year mean
dtr_stack = pd.concat(all_dtr, axis=1)
dtr_mean = dtr_stack.mean(axis=1)

df_final = coords.copy()
df_final.columns = ['lon', 'lat']
df_final['DTR'] = dtr_mean

# =====================================
# 🌐 CREATE 0.25° GRID
# =====================================

res = 0.25

lon_centers = np.arange(-180 + res/2, 180, res)
lat_centers = np.arange(-90 + res/2, 90, res)

dtr_grid = np.full((len(lat_centers), len(lon_centers)), np.nan)
count_grid = np.zeros_like(dtr_grid)
sum_grid = np.zeros_like(dtr_grid)

lon_idx = ((df_final['lon'] + 180) / res).astype(int)
lat_idx = ((df_final['lat'] + 90) / res).astype(int)

lon_idx = np.clip(lon_idx, 0, len(lon_centers)-1)
lat_idx = np.clip(lat_idx, 0, len(lat_centers)-1)

for i in range(len(df_final)):
    x = lon_idx.iloc[i]
    y = lat_idx.iloc[i]
    val = df_final['DTR'].iloc[i]

    if not np.isnan(val):
        sum_grid[y, x] += val
        count_grid[y, x] += 1

dtr_grid = sum_grid / count_grid
dtr_grid[count_grid == 0] = np.nan

lon2d, lat2d = np.meshgrid(lon_centers, lat_centers)

# =====================================
# 📊 LATITUDINAL STATISTICS
# =====================================

latitudes = lat_centers

lat_mean = np.nanmean(dtr_grid, axis=1)
lat_upper = np.nanpercentile(dtr_grid, 75, axis=1)
lat_lower = np.nanpercentile(dtr_grid, 25, axis=1)

# =====================================
# 🎨 COLOR NORMALIZATION
# =====================================

vmin = np.nanpercentile(dtr_grid, 5)
vmax = np.nanpercentile(dtr_grid, 95)

cmap = plt.get_cmap('RdYlBu_r')
norm = mpl.colors.Normalize(vmin=vmin, vmax=vmax)

# =====================================
# 🎨 FIGURE LAYOUT
# =====================================

fig = plt.figure(figsize=(18, 8))

gs = fig.add_gridspec(
    nrows=1, ncols=2,
    width_ratios=[4, 1],
    wspace=0.05
)

# ---- MAP ----
ax_map = fig.add_subplot(gs[0], projection=ccrs.Robinson())
ax_map.set_global()

ax_map.add_feature(cfeature.LAND, facecolor='#d9d9d9')
ax_map.add_feature(cfeature.OCEAN, facecolor='white')
ax_map.coastlines(linewidth=0.6, color='gray')

ax_map.gridlines(draw_labels=False)
ax_map.set_xticks([])
ax_map.set_yticks([])

im = ax_map.pcolormesh(
    lon2d,
    lat2d,
    dtr_grid,
    cmap=cmap,
    norm=norm,
    transform=ccrs.PlateCarree(),
    shading='auto'
)

# ---- PROFILE ----
ax_prof = fig.add_subplot(gs[1])

# Colored line (same scale as map)
points = np.array([lat_mean, latitudes]).T.reshape(-1, 1, 2)
segments = np.concatenate([points[:-1], points[1:]], axis=1)

lc = LineCollection(
    segments,
    cmap=cmap,
    norm=norm,
    linewidth=2
)

lc.set_array(lat_mean)
ax_prof.add_collection(lc)

# Variability (IQR)
ax_prof.fill_betweenx(
    latitudes,
    lat_lower,
    lat_upper,
    color='gray',
    alpha=0.3
)

# Alignment with map
ax_prof.set_ylim(-90, 90)
ax_prof.set_yticks(np.arange(-90, 91, 30))

ax_prof.set_xlim(vmin, vmax)

# Labels
ax_prof.set_xlabel('DTR (°C)', fontsize=11)
ax_prof.set_ylabel('Latitude (°)', fontsize=11)

ax_prof.grid(True, linestyle='--', alpha=0.4)

# Clean spines
ax_prof.spines['top'].set_visible(False)
ax_prof.spines['right'].set_visible(False)

# ---- COLORBAR ----
cbar = fig.colorbar(
    im,
    ax=ax_map,
    orientation='horizontal',
    pad=0.08,
    fraction=0.05,
    aspect=40
)

cbar.set_label('Multi-Year Mean DTR (°C, 2000–2020)', fontsize=11)

# ---- TITLE ----
fig.suptitle(
    'Global Mangrove DTR (2000–2020): Spatial Distribution and Latitudinal Structure',
    fontsize=16,
    y=0.98
)

# ---- SAVE ----
plt.savefig(
    str(DATA_DIR / 'DTR_final_colored_profile.png'),
    dpi=600,
    bbox_inches='tight'
)

plt.tight_layout()
plt.show()
#======================================================================
# This code calculates Canopy Quantum Yield (E0)
# from LAI using Tang et al. (2023)
#======================================================================
# + ensures E0 >= 0

import pandas as pd
import numpy as np
import os

# Input folder
input_folder = str(DATA_DIR / 'LAI')

# Output folder
output_folder = str(DATA_DIR / 'E0')
os.makedirs(output_folder, exist_ok=True)

# Coefficients (Tang et al., 2023)
q1 = -0.258
q2 = 0.9752
q3 = 0.624
q4 = -1.551

# Loop over years
for year in range(2000, 2021):

    print(f'\nProcessing year: {year}')

    file_name = f'LAI_SG_Smoothed_{year}_KDTree.csv'
    file_path = os.path.join(input_folder, file_name)

    if not os.path.exists(file_path):
        print(f'⚠️ Missing {year}, skipping...')
        continue

    print(f'✔ Using: {file_path}')

    # Load data
    df = pd.read_csv(file_path)

    # Extract coordinates
    coords = df.iloc[:, 0:2]

    # Extract LAI values (from 3rd column onward)
    LAI = df.iloc[:, 2:].apply(pd.to_numeric, errors='coerce')
    LAI_values = LAI.values

    # =====================================
    # 🌿 Compute E0 (Piecewise Function)
    # =====================================

    E0_values = np.full_like(LAI_values, np.nan, dtype=float)

    # LAI <= 2.4
    mask1 = LAI_values <= 2.4
    E0_values[mask1] = (
        q1 * (LAI_values[mask1] ** 2) +
        q2 * LAI_values[mask1]
    )

    # LAI > 2.4
    mask2 = LAI_values > 2.4
    E0_values[mask2] = (
        (q3 * (LAI_values[mask2] ** 2)) /
        (q4 + (LAI_values[mask2] ** 2))
    )

    # =====================================
    # 🔒 Enforce Physical Constraint
    # =====================================

    E0_values[E0_values < 0] = 0

    # (Optional safer version)
    # E0_values = np.clip(E0_values, 0, None)

    # Convert back to DataFrame
    E0_df = pd.DataFrame(E0_values, columns=LAI.columns)

    # Combine with coordinates
    result = pd.concat([coords, E0_df], axis=1)

    # Save output
    output_file = os.path.join(output_folder, f'E0_{year}.csv')
    result.to_csv(output_file, index=False)

    print(f'✅ Saved: {output_file}')

print("\n🎯 E0 calculation completed (non-negative enforced)!")
#======================================================================
# This code calculates:
# 1) Annual Mean E0
# 2) Annual Sum E0
# from daily E0 files (2000–2020)

import pandas as pd
import numpy as np
import os

# Input folder (daily E0 files)
input_folder = str(DATA_DIR / 'E0')

# Output folder
output_folder = str(DATA_DIR / 'E0_Annual')
os.makedirs(output_folder, exist_ok=True)

# Loop over years
for year in range(2000, 2021):

    print(f'Processing {year}')

    file_path = os.path.join(input_folder, f'E0_{year}.csv')

    if not os.path.exists(file_path):
        print(f'⚠️ Missing {year}, skipping...')
        continue

    # Load data
    df = pd.read_csv(file_path)

    # Extract coordinates
    coords = df.iloc[:, 0:2]

    # Extract daily E0 values (from 3rd column onward)
    E0_daily = df.iloc[:, 2:].apply(pd.to_numeric, errors='coerce')

    # =====================================
    # 🌿 Compute Annual Metrics
    # =====================================

    # Mean E0
    E0_mean = E0_daily.mean(axis=1)

    # Sum E0 (important for cumulative productivity)
    E0_sum = E0_daily.sum(axis=1)

    # Combine results
    result = pd.concat([
        coords,
        E0_mean.rename('E0_mean'),
        E0_sum.rename('E0_sum')
    ], axis=1)

    # Save output
    output_file = os.path.join(output_folder, f'E0_annual_{year}.csv')
    result.to_csv(output_file, index=False)

    print(f'✅ Saved: {output_file}')

print("\n🎯 Annual E0 (mean & sum) calculated successfully!")
#======================================================================

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature
import os
from matplotlib.collections import LineCollection
import matplotlib as mpl

# =====================================
# 📂 LOAD MULTI-YEAR E0 DATA
# =====================================

folder = str(DATA_DIR / 'E0_Annual')

all_mean = []
all_sum = []
coords = None

for year in range(2000, 2021):

    file_path = os.path.join(folder, f'E0_annual_{year}.csv')

    if not os.path.exists(file_path):
        print(f'⚠️ Missing {year}, skipping...')
        continue

    df = pd.read_csv(file_path)

    if coords is None:
        coords = df.iloc[:, 0:2]

    all_mean.append(df['E0_mean'])
    all_sum.append(df['E0_sum'])

# Multi-year mean
E0_mean_stack = pd.concat(all_mean, axis=1)
E0_mean_final = E0_mean_stack.mean(axis=1)

E0_sum_stack = pd.concat(all_sum, axis=1)
E0_sum_final = E0_sum_stack.mean(axis=1)

df_mean = coords.copy()
df_mean.columns = ['lon', 'lat']
df_mean['E0'] = E0_mean_final

df_sum = coords.copy()
df_sum.columns = ['lon', 'lat']
df_sum['E0'] = E0_sum_final

# =====================================
# 🌐 GRID FUNCTION
# =====================================

def create_grid(df, res=0.25):

    lon_centers = np.arange(-180 + res/2, 180, res)
    lat_centers = np.arange(-90 + res/2, 90, res)

    grid = np.full((len(lat_centers), len(lon_centers)), np.nan)
    count = np.zeros_like(grid)
    summation = np.zeros_like(grid)

    lon_idx = ((df['lon'] + 180) / res).astype(int)
    lat_idx = ((df['lat'] + 90) / res).astype(int)

    lon_idx = np.clip(lon_idx, 0, len(lon_centers)-1)
    lat_idx = np.clip(lat_idx, 0, len(lat_centers)-1)

    for i in range(len(df)):
        x = lon_idx.iloc[i]
        y = lat_idx.iloc[i]
        val = df['E0'].iloc[i]

        if not np.isnan(val):
            summation[y, x] += val
            count[y, x] += 1

    grid = summation / count
    grid[count == 0] = np.nan

    lon2d, lat2d = np.meshgrid(lon_centers, lat_centers)

    return grid, lon2d, lat2d, lat_centers

# =====================================
# 🎨 PLOTTING FUNCTION (MAP + PROFILE)
# =====================================

def plot_with_profile(grid, lon2d, lat2d, latitudes, title, cbar_label, output_file):

    # Latitudinal stats
    lat_mean = np.nanmean(grid, axis=1)
    lat_upper = np.nanpercentile(grid, 75, axis=1)
    lat_lower = np.nanpercentile(grid, 25, axis=1)

    # Color normalization
    vmin = np.nanpercentile(grid, 5)
    vmax = np.nanpercentile(grid, 95)

    cmap = plt.get_cmap('RdYlBu_r')
    norm = mpl.colors.Normalize(vmin=vmin, vmax=vmax)

    # Figure layout
    fig = plt.figure(figsize=(18, 8))

    gs = fig.add_gridspec(
        nrows=1, ncols=2,
        width_ratios=[4, 1],
        wspace=0.05
    )

    # ================= MAP =================
    ax_map = fig.add_subplot(gs[0], projection=ccrs.Robinson())
    ax_map.set_global()

    ax_map.add_feature(cfeature.LAND, facecolor='#d9d9d9')
    ax_map.add_feature(cfeature.OCEAN, facecolor='white')
    ax_map.coastlines(linewidth=0.6, color='gray')

    ax_map.gridlines(draw_labels=False)
    ax_map.set_xticks([])
    ax_map.set_yticks([])

    im = ax_map.pcolormesh(
        lon2d,
        lat2d,
        grid,
        cmap=cmap,
        norm=norm,
        transform=ccrs.PlateCarree(),
        shading='auto'
    )

    # ================= PROFILE =================
    ax_prof = fig.add_subplot(gs[1])

    points = np.array([lat_mean, latitudes]).T.reshape(-1, 1, 2)
    segments = np.concatenate([points[:-1], points[1:]], axis=1)

    lc = LineCollection(
        segments,
        cmap=cmap,
        norm=norm,
        linewidth=2
    )

    lc.set_array(lat_mean)
    ax_prof.add_collection(lc)

    # IQR shading
    ax_prof.fill_betweenx(
        latitudes,
        lat_lower,
        lat_upper,
        color='gray',
        alpha=0.3
    )

    # Alignment
    ax_prof.set_ylim(-90, 90)
    ax_prof.set_yticks(np.arange(-90, 91, 30))
    ax_prof.set_xlim(vmin, vmax)

    ax_prof.set_xlabel(cbar_label, fontsize=11)
    ax_prof.set_ylabel('Latitude (°)', fontsize=11)

    ax_prof.grid(True, linestyle='--', alpha=0.4)

    ax_prof.spines['top'].set_visible(False)
    ax_prof.spines['right'].set_visible(False)

    # ================= COLORBAR =================
    cbar = fig.colorbar(
        im,
        ax=ax_map,
        orientation='horizontal',
        pad=0.08,
        fraction=0.05,
        aspect=40
    )

    cbar.set_label(cbar_label, fontsize=11)

    # ================= TITLE =================
    fig.suptitle(title, fontsize=16, y=0.98)

    # Save
    plt.savefig(output_file, dpi=600, bbox_inches='tight')
    plt.tight_layout()
    plt.show()

# =====================================
# 🌿 CREATE GRIDS
# =====================================

grid_mean, lon2d, lat2d, latitudes = create_grid(df_mean)
grid_sum, _, _, _ = create_grid(df_sum)

# =====================================
# 🌿 MAP 1: MEAN E0
# =====================================

plot_with_profile(
    grid_mean,
    lon2d,
    lat2d,
    latitudes,
    'Global Mangrove Mean Canopy Quantum Yield E₀ (2000–2020)',
    'E₀ (gC MJ$^{-1}$)',
    str(DATA_DIR / 'E0_mean_profile.png')
)

# =====================================
# 🌿 MAP 2: SUM E0
# =====================================

plot_with_profile(
    grid_sum,
    lon2d,
    lat2d,
    latitudes,
    'Global Mangrove Annual Sum of Canopy Quantum Yield E₀ (2000–2020)',
    'E₀ (gC MJ$^{-1}$)',
    str(DATA_DIR / 'E0_sum_profile.png')
)



# ==========================================================================
# 🌿 Light-Limited Photosynthetic Rate (PI)
# PI = E0 × SSR
# Unit: gC m^-2 d^-1
# ==========================================================================
# =====================================
# 🌿 PI = E0 × SSR (ROBUST VERSION)
# Handles shape mismatch using coordinate alignment
# =====================================

import pandas as pd
import numpy as np
import os

# Input folders
e0_folder = str(DATA_DIR / 'E0')
ssr_folder = str(DATA_DIR / 'SSR')

# Output folder
output_folder = str(DATA_DIR / 'PI')
os.makedirs(output_folder, exist_ok=True)

# Loop over years
for year in range(2000, 2021):

    print(f'\nProcessing year: {year}')

    e0_file = os.path.join(e0_folder, f'E0_{year}.csv')
    ssr_file = os.path.join(ssr_folder, f'SSR_sum_KDTree_{year}.csv')

    if not os.path.exists(e0_file) or not os.path.exists(ssr_file):
        print(f'⚠️ Missing files for {year}, skipping...')
        continue

    print(f'✔ Using:\n{e0_file}\n{ssr_file}')

    # Load data
    df_e0 = pd.read_csv(e0_file)
    df_ssr = pd.read_csv(ssr_file)

    # Rename first two columns (safe)
    df_e0.columns.values[0:2] = ['lon', 'lat']
    df_ssr.columns.values[0:2] = ['lon', 'lat']

    # =====================================
    # 🔗 ALIGN BY COORDINATES
    # =====================================

    df_merged = pd.merge(
        df_e0,
        df_ssr,
        on=['lon', 'lat'],
        suffixes=('_E0', '_SSR')
    )

    if df_merged.empty:
        print(f'❌ No matching coordinates in {year}, skipping...')
        continue

    print(f'✔ Matched points: {len(df_merged)}')

    # =====================================
    # 📊 EXTRACT MATCHED DATA
    # =====================================

    coords = df_merged[['lon', 'lat']]

    # Split E0 and SSR columns
    e0_cols = [col for col in df_merged.columns if '_E0' in col]
    ssr_cols = [col for col in df_merged.columns if '_SSR' in col]

    E0 = df_merged[e0_cols].apply(pd.to_numeric, errors='coerce')
    SSR = df_merged[ssr_cols].apply(pd.to_numeric, errors='coerce')

    # Ensure same number of columns
    min_cols = min(E0.shape[1], SSR.shape[1])
    E0 = E0.iloc[:, :min_cols]
    SSR = SSR.iloc[:, :min_cols]

    # =====================================
    # 🌞 COMPUTE PI
    # =====================================

    PI_values = E0.values * SSR.values
    PI_values = np.clip(PI_values, 0, None)

    # Clean column names (remove suffix)
    new_cols = [col.replace('_E0', '') for col in e0_cols[:min_cols]]

    PI_df = pd.DataFrame(PI_values, columns=new_cols)

    # Combine
    result = pd.concat([coords, PI_df], axis=1)

    # Save
    output_file = os.path.join(output_folder, f'PI_{year}.csv')
    result.to_csv(output_file, index=False)

    print(f'✅ Saved: {output_file}')

print("\n🎯 PI calculation completed with coordinate alignment!")
#==========================================================================

# =====================================
# 🌿 Annual PI Metrics
# 1) Annual Mean PI
# 2) Annual Sum PI
# Unit: gC m^-2 d^-1 (mean), gC m^-2 yr^-1 (sum)
# =====================================

import pandas as pd
import numpy as np
import os

# Input folder (daily PI files)
input_folder = str(DATA_DIR / 'PI')

# Output folder
output_folder = str(DATA_DIR / 'PI_Annual')
os.makedirs(output_folder, exist_ok=True)

# Loop over years
for year in range(2000, 2021):

    print(f'Processing {year}')

    file_path = os.path.join(input_folder, f'PI_{year}.csv')

    if not os.path.exists(file_path):
        print(f'⚠️ Missing {year}, skipping...')
        continue

    # Load data
    df = pd.read_csv(file_path)

    # Extract coordinates
    coords = df.iloc[:, 0:2]

    # Extract daily PI values (from 3rd column onward)
    PI_daily = df.iloc[:, 2:].apply(pd.to_numeric, errors='coerce')

    # =====================================
    # 🌿 Compute Annual Metrics
    # =====================================

    # Annual Mean PI (gC m^-2 d^-1)
    PI_mean = PI_daily.mean(axis=1)

    # Annual Sum PI (gC m^-2 yr^-1)
    PI_sum = PI_daily.sum(axis=1)

    # =====================================
    # 📦 Combine results
    # =====================================

    result = pd.concat([
        coords,
        PI_mean.rename('PI_mean'),
        PI_sum.rename('PI_sum')
    ], axis=1)

    # Save output
    output_file = os.path.join(output_folder, f'PI_annual_{year}.csv')
    result.to_csv(output_file, index=False)

    print(f'✅ Saved: {output_file}')

print("\n🎯 Annual PI (mean & sum) calculated successfully!")
#==========================================================================
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature
import os
from matplotlib.collections import LineCollection
import matplotlib as mpl

# =====================================
# 📂 LOAD MULTI-YEAR PI DATA
# =====================================

folder = str(DATA_DIR / 'PI_Annual')

all_mean = []
all_sum = []
coords = None

for year in range(2000, 2021):

    file_path = os.path.join(folder, f'PI_annual_{year}.csv')

    if not os.path.exists(file_path):
        print(f'⚠️ Missing {year}, skipping...')
        continue

    df = pd.read_csv(file_path)

    if coords is None:
        coords = df.iloc[:, 0:2]

    all_mean.append(df['PI_mean'])
    all_sum.append(df['PI_sum'])

# Multi-year mean
PI_mean_stack = pd.concat(all_mean, axis=1)
PI_mean_final = PI_mean_stack.mean(axis=1)

PI_sum_stack = pd.concat(all_sum, axis=1)
PI_sum_final = PI_sum_stack.mean(axis=1)

df_mean = coords.copy()
df_mean.columns = ['lon', 'lat']
df_mean['PI'] = PI_mean_final

df_sum = coords.copy()
df_sum.columns = ['lon', 'lat']
df_sum['PI'] = PI_sum_final

# =====================================
# 🌐 GRID FUNCTION
# =====================================

def create_grid(df, res=0.25):

    lon_centers = np.arange(-180 + res/2, 180, res)
    lat_centers = np.arange(-90 + res/2, 90, res)

    grid = np.full((len(lat_centers), len(lon_centers)), np.nan)
    count = np.zeros_like(grid)
    summation = np.zeros_like(grid)

    lon_idx = ((df['lon'] + 180) / res).astype(int)
    lat_idx = ((df['lat'] + 90) / res).astype(int)

    lon_idx = np.clip(lon_idx, 0, len(lon_centers)-1)
    lat_idx = np.clip(lat_idx, 0, len(lat_centers)-1)

    for i in range(len(df)):
        x = lon_idx.iloc[i]
        y = lat_idx.iloc[i]
        val = df['PI'].iloc[i]

        if not np.isnan(val):
            summation[y, x] += val
            count[y, x] += 1

    grid = summation / count
    grid[count == 0] = np.nan

    lon2d, lat2d = np.meshgrid(lon_centers, lat_centers)

    return grid, lon2d, lat2d, lat_centers

# =====================================
# 🎨 PLOTTING FUNCTION
# =====================================

def plot_with_profile(grid, lon2d, lat2d, latitudes, title, cbar_label, output_file):

    # Latitudinal stats
    lat_mean = np.nanmean(grid, axis=1)
    lat_upper = np.nanpercentile(grid, 75, axis=1)
    lat_lower = np.nanpercentile(grid, 25, axis=1)

    # Color normalization
    vmin = np.nanpercentile(grid, 5)
    vmax = np.nanpercentile(grid, 95)

    cmap = plt.get_cmap('RdYlBu_r')
    norm = mpl.colors.Normalize(vmin=vmin, vmax=vmax)

    # Figure
    fig = plt.figure(figsize=(18, 8))

    gs = fig.add_gridspec(
        nrows=1, ncols=2,
        width_ratios=[4, 1],
        wspace=0.05
    )

    # ================= MAP =================
    ax_map = fig.add_subplot(gs[0], projection=ccrs.Robinson())
    ax_map.set_global()

    ax_map.add_feature(cfeature.LAND, facecolor='#d9d9d9')
    ax_map.add_feature(cfeature.OCEAN, facecolor='white')
    ax_map.coastlines(linewidth=0.6, color='gray')

    ax_map.gridlines(draw_labels=False)
    ax_map.set_xticks([])
    ax_map.set_yticks([])

    im = ax_map.pcolormesh(
        lon2d,
        lat2d,
        grid,
        cmap=cmap,
        norm=norm,
        transform=ccrs.PlateCarree(),
        shading='auto'
    )

    # ================= PROFILE =================
    ax_prof = fig.add_subplot(gs[1])

    points = np.array([lat_mean, latitudes]).T.reshape(-1, 1, 2)
    segments = np.concatenate([points[:-1], points[1:]], axis=1)

    lc = LineCollection(
        segments,
        cmap=cmap,
        norm=norm,
        linewidth=2
    )

    lc.set_array(lat_mean)
    ax_prof.add_collection(lc)

    # IQR shading
    ax_prof.fill_betweenx(
        latitudes,
        lat_lower,
        lat_upper,
        color='gray',
        alpha=0.3
    )

    # Axis alignment
    ax_prof.set_ylim(-90, 90)
    ax_prof.set_yticks(np.arange(-90, 91, 30))
    ax_prof.set_xlim(vmin, vmax)

    ax_prof.set_xlabel(cbar_label, fontsize=11)
    ax_prof.set_ylabel('Latitude (°)', fontsize=11)

    ax_prof.grid(True, linestyle='--', alpha=0.4)

    ax_prof.spines['top'].set_visible(False)
    ax_prof.spines['right'].set_visible(False)

    # ================= COLORBAR =================
    cbar = fig.colorbar(
        im,
        ax=ax_map,
        orientation='horizontal',
        pad=0.08,
        fraction=0.05,
        aspect=40
    )

    cbar.set_label(cbar_label, fontsize=11)

    # ================= TITLE =================
    fig.suptitle(title, fontsize=16, y=0.98)

    # Save
    plt.savefig(output_file, dpi=600, bbox_inches='tight')
    plt.tight_layout()
    plt.show()

# =====================================
# 🌿 CREATE GRIDS
# =====================================

grid_mean, lon2d, lat2d, latitudes = create_grid(df_mean)
grid_sum, _, _, _ = create_grid(df_sum)

# =====================================
# 🌿 MAP 1: MEAN PI
# =====================================

plot_with_profile(
    grid_mean,
    lon2d,
    lat2d,
    latitudes,
    'Global Mangrove Mean Light-Limited Photosynthesis PI (2000–2020)',
    'PI (gC m$^{-2}$ d$^{-1}$)',
    str(DATA_DIR / 'PI_mean_profile.png')
)

# =====================================
# 🌿 MAP 2: SUM PI
# =====================================

plot_with_profile(
    grid_sum,
    lon2d,
    lat2d,
    latitudes,
    'Global Mangrove Annual Sum of Light-Limited Photosynthesis PI (2000–2020)',
    'PI (gC m$^{-2}$ yr$^{-1}$)',
    str(DATA_DIR / 'PI_sum_profile.png')
)

#====================FINAL CODE — Calculate TI from Temperature===================

import pandas as pd
import numpy as np
import os

# =====================================
# 📂 INPUT / OUTPUT PATHS
# =====================================

input_folder = str(DATA_DIR / 'Temp')
output_folder = str(DATA_DIR / 'TI')
os.makedirs(output_folder, exist_ok=True)

# =====================================
# 🌡️ COEFFICIENTS (Tang et al., 2023)
# =====================================

a2 = 0.093
a3 = 0.04

# =====================================
# 🔁 LOOP OVER YEARS
# =====================================

for year in range(2000, 2021):

    print(f'\nProcessing year: {year}')

    file_name = f'Temp_min_KDTree_{year}.csv'
    file_path = os.path.join(input_folder, file_name)

    if not os.path.exists(file_path):
        print(f'⚠️ Missing {year}, skipping...')
        continue

    print(f'✔ Using: {file_path}')

    # =====================================
    # 📥 LOAD DATA
    # =====================================

    df = pd.read_csv(file_path)

    # Coordinates
    coords = df.iloc[:, 0:2]

    # Temperature values (daily)
    Temp = df.iloc[:, 2:].apply(pd.to_numeric, errors='coerce')
    T_values = Temp.values

    # =====================================
    # 🌡️ CALCULATE TI
    # =====================================

    TImin_values = a2 * T_values * np.exp(-a3 * T_values)

    # =====================================
    # 🔒 HANDLE EDGE CASES
    # =====================================

    # Enforce non-negative first
    TImin_values = np.clip(TImin_values, 0, None)

    # Preserve NaN from original temperature data
    TImin_values[np.isnan(T_values)] = np.nan

    # =====================================
    # 📊 SAVE OUTPUT
    # =====================================

    TI_df = pd.DataFrame(TImin_values, columns=Temp.columns)

    result = pd.concat([coords, TI_df], axis=1)

    output_file = os.path.join(output_folder, f'TImin_{year}.csv')
    result.to_csv(output_file, index=False)

    print(f'✅ Saved: {output_file}')

print("\n🎯 TI calculation completed successfully!")

# ==========================================================================

import pandas as pd
import numpy as np
import os

# =====================================
# 📂 INPUT / OUTPUT PATHS
# =====================================

# Input folder (daily TI files)
input_folder = str(DATA_DIR / 'TI')

# Output folder
output_folder = str(DATA_DIR / 'TImax_Annual')
os.makedirs(output_folder, exist_ok=True)

# =====================================
# 🔁 LOOP OVER YEARS
# =====================================

for year in range(2000, 2021):

    print(f'Processing {year}')

    file_path = os.path.join(input_folder, f'TImax_{year}.csv')

    if not os.path.exists(file_path):
        print(f'⚠️ Missing {year}, skipping...')
        continue

    # =====================================
    # 📥 LOAD DATA
    # =====================================

    df = pd.read_csv(file_path)

    # Coordinates
    coords = df.iloc[:, 0:2]

    # Daily TI values (from 3rd column onward)
    TImin_daily = df.iloc[:, 2:].apply(pd.to_numeric, errors='coerce')

    # =====================================
    # 🌿 COMPUTE ANNUAL MEAN & SUM TI
    # =====================================

    TImin_mean = TImin_daily.mean(axis=1)
    TImin_sum  = TImin_daily.sum(axis=1)

    # =====================================
    # 📦 COMBINE RESULTS
    # =====================================

    result = pd.concat([
        coords,
        TImin_mean.rename('TI_mean'),
        TImin_sum.rename('TI_sum')
    ], axis=1)

    # =====================================
    # 💾 SAVE OUTPUT
    # =====================================

    output_file = os.path.join(output_folder, f'TImax_annual_{year}.csv')
    result.to_csv(output_file, index=False)

    print(f'✅ Saved: {output_file}')

print("\n🎯 Annual Mean & Sum TI calculated successfully!")

#==========================================================================
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature
import os
from matplotlib.collections import LineCollection
import matplotlib as mpl

# =====================================
# 📂 LOAD MULTI-YEAR TI DATA
# =====================================

folder = str(DATA_DIR / 'TImax_Annual')

all_mean = []
all_sum = []
coords = None

for year in range(2000, 2021):

    file_path = os.path.join(folder, f'TImax_annual_{year}.csv')

    if not os.path.exists(file_path):
        print(f'⚠️ Missing {year}, skipping...')
        continue

    df = pd.read_csv(file_path)

    if coords is None:
        coords = df.iloc[:, 0:2]

    all_mean.append(df['TI_mean'])
    all_sum.append(df['TI_sum'])

# Multi-year mean
TI_mean_stack = pd.concat(all_mean, axis=1)
TI_mean_final = TI_mean_stack.mean(axis=1)

TI_sum_stack = pd.concat(all_sum, axis=1)
TI_sum_final = TI_sum_stack.mean(axis=1)

df_mean = coords.copy()
df_mean.columns = ['lon', 'lat']
df_mean['TI'] = TI_mean_final

df_sum = coords.copy()
df_sum.columns = ['lon', 'lat']
df_sum['TI'] = TI_sum_final

# =====================================
# 🌐 GRID FUNCTION (0.25°)
# =====================================

def create_grid(df, res=0.25):

    lon_centers = np.arange(-180 + res/2, 180, res)
    lat_centers = np.arange(-90 + res/2, 90, res)

    grid = np.full((len(lat_centers), len(lon_centers)), np.nan)
    count = np.zeros_like(grid)
    summation = np.zeros_like(grid)

    lon_idx = ((df['lon'] + 180) / res).astype(int)
    lat_idx = ((df['lat'] + 90) / res).astype(int)

    lon_idx = np.clip(lon_idx, 0, len(lon_centers)-1)
    lat_idx = np.clip(lat_idx, 0, len(lat_centers)-1)

    for i in range(len(df)):
        x = lon_idx.iloc[i]
        y = lat_idx.iloc[i]
        val = df['TI'].iloc[i]

        if not np.isnan(val):
            summation[y, x] += val
            count[y, x] += 1

    grid = summation / count
    grid[count == 0] = np.nan

    lon2d, lat2d = np.meshgrid(lon_centers, lat_centers)

    return grid, lon2d, lat2d, lat_centers

# =====================================
# 🎨 PLOT FUNCTION (MAP + PROFILE)
# =====================================

def plot_with_profile(grid, lon2d, lat2d, latitudes, title, cbar_label, output_file):

    # Latitudinal statistics
    lat_mean = np.nanmean(grid, axis=1)
    lat_upper = np.nanpercentile(grid, 75, axis=1)
    lat_lower = np.nanpercentile(grid, 25, axis=1)

    # Color normalization
    vmin = np.nanpercentile(grid, 5)
    vmax = np.nanpercentile(grid, 95)

    cmap = plt.get_cmap('RdYlBu_r')
    norm = mpl.colors.Normalize(vmin=vmin, vmax=vmax)

    # Figure layout
    fig = plt.figure(figsize=(18, 8))

    gs = fig.add_gridspec(
        nrows=1, ncols=2,
        width_ratios=[4, 1],
        wspace=0.05
    )

    # ================= MAP =================
    ax_map = fig.add_subplot(gs[0], projection=ccrs.Robinson())
    ax_map.set_global()

    ax_map.add_feature(cfeature.LAND, facecolor='#d9d9d9')
    ax_map.add_feature(cfeature.OCEAN, facecolor='white')
    ax_map.coastlines(linewidth=0.6, color='gray')

    ax_map.gridlines(draw_labels=False)
    ax_map.set_xticks([])
    ax_map.set_yticks([])

    im = ax_map.pcolormesh(
        lon2d,
        lat2d,
        grid,
        cmap=cmap,
        norm=norm,
        transform=ccrs.PlateCarree(),
        shading='auto'
    )

    # ================= PROFILE =================
    ax_prof = fig.add_subplot(gs[1])

    # Colored line
    points = np.array([lat_mean, latitudes]).T.reshape(-1, 1, 2)
    segments = np.concatenate([points[:-1], points[1:]], axis=1)

    lc = LineCollection(
        segments,
        cmap=cmap,
        norm=norm,
        linewidth=2
    )

    lc.set_array(lat_mean)
    ax_prof.add_collection(lc)

    # IQR shading
    ax_prof.fill_betweenx(
        latitudes,
        lat_lower,
        lat_upper,
        color='gray',
        alpha=0.3
    )

    # Alignment
    ax_prof.set_ylim(-90, 90)
    ax_prof.set_yticks(np.arange(-90, 91, 30))
    ax_prof.set_xlim(vmin, vmax)

    ax_prof.set_xlabel(cbar_label, fontsize=11)
    ax_prof.set_ylabel('Latitude (°)', fontsize=11)

    ax_prof.grid(True, linestyle='--', alpha=0.4)

    ax_prof.spines['top'].set_visible(False)
    ax_prof.spines['right'].set_visible(False)

    # ================= COLORBAR =================
    cbar = fig.colorbar(
        im,
        ax=ax_map,
        orientation='horizontal',
        pad=0.08,
        fraction=0.05,
        aspect=40
    )

    cbar.set_label(cbar_label, fontsize=11)

    # ================= TITLE =================
    fig.suptitle(title, fontsize=16, y=0.98)

    # Save
    plt.savefig(output_file, dpi=600, bbox_inches='tight')
    plt.tight_layout()
    plt.show()

# =====================================
# 🌿 CREATE GRIDS
# =====================================

grid_mean, lon2d, lat2d, latitudes = create_grid(df_mean)
grid_sum, _, _, _ = create_grid(df_sum)

# =====================================
# 🌿 MAP 1: MEAN TI
# =====================================

plot_with_profile(
    grid_mean,
    lon2d,
    lat2d,
    latitudes,
    'Global Mangrove Mean Temperature Index (TImax) (2000–2020)',
    'TI (unitless)',
    str(DATA_DIR / 'TImax_mean_profile.png')
)

# =====================================
# 🌿 MAP 2: SUM TI
# =====================================

plot_with_profile(
    grid_sum,
    lon2d,
    lat2d,
    latitudes,
    'Global Mangrove Annual Sum of Temperature Index (TImax) (2000–2020)',
    'TI (unitless)',
    str(DATA_DIR / 'TIm_sum_profile.png')
)

#==========================SI Calculation from Salinity================================================
import pandas as pd
import numpy as np
import os

# =====================================
# 📂 INPUT / OUTPUT PATHS
# =====================================

# Input folder (Salinity data)
input_folder = str(DATA_DIR / 'Salinty')

# Output folder
output_folder = str(DATA_DIR / 'SI')
os.makedirs(output_folder, exist_ok=True)

# =====================================
# 🌊 CONSTANT
# =====================================

st = 80.0  # salinity threshold (ppt)

# =====================================
# 🔁 LOOP OVER YEARS
# =====================================

for year in range(2000, 2021):

    print(f'\nProcessing year: {year}')

    file_name = f'sal_{year}_KDTree.csv'
    file_path = os.path.join(input_folder, file_name)

    if not os.path.exists(file_path):
        print(f'⚠️ Missing {year}, skipping...')
        continue

    print(f'✔ Using: {file_path}')

    # =====================================
    # 📥 LOAD DATA
    # =====================================

    df = pd.read_csv(file_path)

    # Coordinates
    coords = df.iloc[:, 0:2]

    # Salinity values (daily)
    Sal = df.iloc[:, 2:].apply(pd.to_numeric, errors='coerce')
    S_values = Sal.values

    # =====================================
    # 🌊 CALCULATE SI
    # =====================================

    # Compute inside sqrt safely
    inside = 1 - (S_values**2) / (st**2)

    # Avoid negative values inside sqrt (important!)
    inside[inside < 0] = 0

    SI_values = np.sqrt(inside)

    # =====================================
    # 🔒 HANDLE EDGE CASES
    # =====================================

    # Preserve NaNs
    SI_values[np.isnan(S_values)] = np.nan

    # =====================================
    # 📊 SAVE OUTPUT
    # =====================================

    SI_df = pd.DataFrame(SI_values, columns=Sal.columns)

    result = pd.concat([coords, SI_df], axis=1)

    output_file = os.path.join(output_folder, f'SI_{year}.csv')
    result.to_csv(output_file, index=False)

    print(f'✅ Saved: {output_file}')

print("\n🎯 SI calculation completed successfully!")

#==========================================================================
import pandas as pd
import numpy as np
import os

# =====================================
# 📂 INPUT / OUTPUT PATHS
# =====================================

# Input folder (daily SI files)
input_folder = str(DATA_DIR / 'SI')

# Output folder
output_folder = str(DATA_DIR / 'SI_Annual')
os.makedirs(output_folder, exist_ok=True)

# =====================================
# 🔁 LOOP OVER YEARS
# =====================================

for year in range(2000, 2021):

    print(f'Processing {year}')

    file_path = os.path.join(input_folder, f'SI_{year}.csv')

    if not os.path.exists(file_path):
        print(f'⚠️ Missing {year}, skipping...')
        continue

    # =====================================
    # 📥 LOAD DATA
    # =====================================

    df = pd.read_csv(file_path)

    # Coordinates
    coords = df.iloc[:, 0:2]

    # Daily SI values (from 3rd column onward)
    SI_daily = df.iloc[:, 2:].apply(pd.to_numeric, errors='coerce')

    # =====================================
    # 🌿 COMPUTE ANNUAL METRICS
    # =====================================

    # Mean SI (unitless)
    SI_mean = SI_daily.mean(axis=1)

    # Sum SI (unitless, cumulative index)
    SI_sum = SI_daily.sum(axis=1)

    # =====================================
    # 📦 COMBINE RESULTS
    # =====================================

    result = pd.concat([
        coords,
        SI_mean.rename('SI_mean'),
        SI_sum.rename('SI_sum')
    ], axis=1)

    # =====================================
    # 💾 SAVE OUTPUT
    # =====================================

    output_file = os.path.join(output_folder, f'SI_annual_{year}.csv')
    result.to_csv(output_file, index=False)

    print(f'✅ Saved: {output_file}')

print("\n🎯 Annual SI (mean & sum) calculated successfully!")

#==========================================================================
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature
import os
from matplotlib.collections import LineCollection
import matplotlib as mpl

# =====================================
# 📂 LOAD MULTI-YEAR SI DATA
# =====================================

folder = str(DATA_DIR / 'SI_Annual')

all_mean = []
all_sum = []
coords = None

for year in range(2000, 2021):

    file_path = os.path.join(folder, f'SI_annual_{year}.csv')

    if not os.path.exists(file_path):
        print(f'⚠️ Missing {year}, skipping...')
        continue

    df = pd.read_csv(file_path)

    if coords is None:
        coords = df.iloc[:, 0:2]

    all_mean.append(df['SI_mean'])
    all_sum.append(df['SI_sum'])

# =====================================
# 🌿 MULTI-YEAR MEAN
# =====================================

SI_mean_stack = pd.concat(all_mean, axis=1)
SI_mean_final = SI_mean_stack.mean(axis=1)

SI_sum_stack = pd.concat(all_sum, axis=1)
SI_sum_final = SI_sum_stack.mean(axis=1)

df_mean = coords.copy()
df_mean.columns = ['lon', 'lat']
df_mean['SI'] = SI_mean_final

df_sum = coords.copy()
df_sum.columns = ['lon', 'lat']
df_sum['SI'] = SI_sum_final

# =====================================
# 🌐 GRID FUNCTION (0.25°)
# =====================================

def create_grid(df, res=0.25):

    lon_centers = np.arange(-180 + res/2, 180, res)
    lat_centers = np.arange(-90 + res/2, 90, res)

    grid = np.full((len(lat_centers), len(lon_centers)), np.nan)
    count = np.zeros_like(grid)
    summation = np.zeros_like(grid)

    lon_idx = ((df['lon'] + 180) / res).astype(int)
    lat_idx = ((df['lat'] + 90) / res).astype(int)

    lon_idx = np.clip(lon_idx, 0, len(lon_centers)-1)
    lat_idx = np.clip(lat_idx, 0, len(lat_centers)-1)

    for i in range(len(df)):
        x = lon_idx.iloc[i]
        y = lat_idx.iloc[i]
        val = df['SI'].iloc[i]

        if not np.isnan(val):
            summation[y, x] += val
            count[y, x] += 1

    grid = summation / count
    grid[count == 0] = np.nan

    lon2d, lat2d = np.meshgrid(lon_centers, lat_centers)

    return grid, lon2d, lat2d, lat_centers

# =====================================
# 🎨 PLOTTING FUNCTION
# =====================================

def plot_with_profile(grid, lon2d, lat2d, latitudes, title, cbar_label, output_file):

    # Latitudinal stats
    lat_mean = np.nanmean(grid, axis=1)
    lat_upper = np.nanpercentile(grid, 75, axis=1)
    lat_lower = np.nanpercentile(grid, 25, axis=1)

    # Robust color scaling
    vmin = np.nanpercentile(grid, 5)
    vmax = np.nanpercentile(grid, 95)

    cmap = plt.get_cmap('RdYlBu_r')
    norm = mpl.colors.Normalize(vmin=vmin, vmax=vmax)

    # =====================================
    # 📐 FIGURE LAYOUT (NO OVERLAP FIXED)
    # =====================================

    fig = plt.figure(figsize=(16, 6))

    gs = fig.add_gridspec(
        nrows=1, ncols=2,
        width_ratios=[4.5, 1],
        wspace=0.15
    )

    # ================= MAP =================
    ax_map = fig.add_subplot(gs[0], projection=ccrs.Robinson())
    ax_map.set_global()

    ax_map.add_feature(cfeature.LAND, facecolor='#d9d9d9')
    ax_map.add_feature(cfeature.OCEAN, facecolor='white')
    ax_map.coastlines(linewidth=0.6, color='gray')

    im = ax_map.pcolormesh(
        lon2d,
        lat2d,
        grid,
        cmap=cmap,
        norm=norm,
        transform=ccrs.PlateCarree(),
        shading='auto'
    )

    # ================= PROFILE =================
    ax_prof = fig.add_subplot(gs[1])

    # Colored line
    points = np.array([lat_mean, latitudes]).T.reshape(-1, 1, 2)
    segments = np.concatenate([points[:-1], points[1:]], axis=1)

    lc = LineCollection(
        segments,
        cmap=cmap,
        norm=norm,
        linewidth=2
    )

    lc.set_array(lat_mean)
    ax_prof.add_collection(lc)

    # IQR shading
    ax_prof.fill_betweenx(
        latitudes,
        lat_lower,
        lat_upper,
        color='gray',
        alpha=0.3
    )

    # Alignment (FIXED overlap issue)
    ax_prof.set_ylim(-90, 90)
    ax_prof.set_xlim(vmin, vmax)

    ax_prof.set_yticks(np.arange(-90, 91, 30))
    ax_prof.set_xlabel(cbar_label, fontsize=11)
    ax_prof.set_ylabel('Latitude (°)', fontsize=11)

    ax_prof.grid(True, linestyle='--', alpha=0.4)

    ax_prof.spines['top'].set_visible(False)
    ax_prof.spines['right'].set_visible(False)

    # ================= COLORBAR =================
    cbar = fig.colorbar(
        im,
        ax=ax_map,
        orientation='horizontal',
        pad=0.08,
        fraction=0.05,
        aspect=40
    )

    cbar.set_label(cbar_label, fontsize=11)

    # ================= TITLE =================
    fig.suptitle(title, fontsize=15, y=0.97)

    # Save
    plt.savefig(output_file, dpi=600, bbox_inches='tight')
    plt.show()

# =====================================
# 🌿 CREATE GRIDS
# =====================================

grid_mean, lon2d, lat2d, latitudes = create_grid(df_mean)
grid_sum, _, _, _ = create_grid(df_sum)

# =====================================
# 🌿 MAP 1: MEAN SI
# =====================================

plot_with_profile(
    grid_mean,
    lon2d,
    lat2d,
    latitudes,
    'Global Mangrove Mean Salinity Index (SI) (2000–2020)',
    'SI (unitless)',
    str(DATA_DIR / 'SI_mean_profile.png')
)

# =====================================
# 🌿 MAP 2: SUM SI
# =====================================

plot_with_profile(
    grid_sum,
    lon2d,
    lat2d,
    latitudes,
    'Global Mangrove Annual Sum of Salinity Index (SI) (2000–2020)',
    'SI (unitless)',
    str(DATA_DIR / 'SI_sum_profile.png')
)


#==========================================================================

import pandas as pd
import numpy as np
import os

# =====================================
# 📂 INPUT / OUTPUT PATHS
# =====================================

# Input folder (daily SST files)
input_folder = str(DATA_DIR / 'SST')

# Output folder
output_folder = str(DATA_DIR / 'SST_Annual')
os.makedirs(output_folder, exist_ok=True)

# =====================================
# 🔁 LOOP OVER YEARS
# =====================================

for year in range(2000, 2021):

    print(f'Processing {year}')

    file_path = os.path.join(input_folder, f'SST_{year}_KDTree.csv')

    if not os.path.exists(file_path):
        print(f'⚠️ Missing {year}, skipping...')
        continue

    # =====================================
    # 📥 LOAD DATA
    # =====================================

    df = pd.read_csv(file_path)

    # Coordinates
    coords = df.iloc[:, 0:2]

    # Daily SST values (from 3rd column onward)
    SST_daily = df.iloc[:, 2:].apply(pd.to_numeric, errors='coerce')

    # =====================================
    # 🌊 COMPUTE ANNUAL METRICS
    # =====================================

    # Annual Mean SST (°C)
    SST_mean = SST_daily.mean(axis=1)

    # Annual Sum SST (°C·day) → mainly for cumulative thermal exposure
    SST_sum = SST_daily.sum(axis=1)

    # =====================================
    # 📦 COMBINE RESULTS
    # =====================================

    result = pd.concat([
        coords,
        SST_mean.rename('SST_mean'),
        SST_sum.rename('SST_sum')
    ], axis=1)

    # =====================================
    # 💾 SAVE OUTPUT
    # =====================================

    output_file = os.path.join(output_folder, f'SST_annual_{year}.csv')
    result.to_csv(output_file, index=False)

    print(f'✅ Saved: {output_file}')

print("\n🎯 Annual SST (mean & sum) calculated successfully!")

#==========================================================================

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature
import os
from matplotlib.collections import LineCollection
import matplotlib as mpl

# =====================================
# 📂 LOAD MULTI-YEAR SST DATA
# =====================================

folder = str(DATA_DIR / 'SST_Annual')

all_mean = []
all_sum = []
coords = None

for year in range(2000, 2021):

    file_path = os.path.join(folder, f'SST_annual_{year}.csv')

    if not os.path.exists(file_path):
        print(f'⚠️ Missing {year}, skipping...')
        continue

    df = pd.read_csv(file_path)

    if coords is None:
        coords = df.iloc[:, 0:2]

    all_mean.append(df['SST_mean'])
    all_sum.append(df['SST_sum'])

# =====================================
# 🌿 MULTI-YEAR MEAN
# =====================================

SST_mean_stack = pd.concat(all_mean, axis=1)
SST_mean_final = SST_mean_stack.mean(axis=1)

SST_sum_stack = pd.concat(all_sum, axis=1)
SST_sum_final = SST_sum_stack.mean(axis=1)

df_mean = coords.copy()
df_mean.columns = ['lon', 'lat']
df_mean['SST'] = SST_mean_final

df_sum = coords.copy()
df_sum.columns = ['lon', 'lat']
df_sum['SST'] = SST_sum_final

# =====================================
# 🌐 GRID FUNCTION (0.25°)
# =====================================

def create_grid(df, res=0.25):

    lon_centers = np.arange(-180 + res/2, 180, res)
    lat_centers = np.arange(-90 + res/2, 90, res)

    grid = np.full((len(lat_centers), len(lon_centers)), np.nan)
    count = np.zeros_like(grid)
    summation = np.zeros_like(grid)

    lon_idx = ((df['lon'] + 180) / res).astype(int)
    lat_idx = ((df['lat'] + 90) / res).astype(int)

    lon_idx = np.clip(lon_idx, 0, len(lon_centers)-1)
    lat_idx = np.clip(lat_idx, 0, len(lat_centers)-1)

    for i in range(len(df)):
        x = lon_idx.iloc[i]
        y = lat_idx.iloc[i]
        val = df['SST'].iloc[i]

        if not np.isnan(val):
            summation[y, x] += val
            count[y, x] += 1

    grid = summation / count
    grid[count == 0] = np.nan

    lon2d, lat2d = np.meshgrid(lon_centers, lat_centers)

    return grid, lon2d, lat2d, lat_centers

# =====================================
# 🎨 PLOTTING FUNCTION (FIXED LAYOUT)
# =====================================

def plot_with_profile(grid, lon2d, lat2d, latitudes, title, cbar_label, output_file):

    # Latitudinal stats
    lat_mean = np.nanmean(grid, axis=1)
    lat_upper = np.nanpercentile(grid, 75, axis=1)
    lat_lower = np.nanpercentile(grid, 25, axis=1)

    # Robust scaling
    vmin = np.nanpercentile(grid, 5)
    vmax = np.nanpercentile(grid, 95)

    cmap = plt.get_cmap('RdYlBu_r')
    norm = mpl.colors.Normalize(vmin=vmin, vmax=vmax)

    # ================= FIGURE =================
    fig = plt.figure(figsize=(16, 6))

    gs = fig.add_gridspec(
        nrows=1, ncols=2,
        width_ratios=[4.5, 1],
        wspace=0.15
    )

    # ================= MAP =================
    ax_map = fig.add_subplot(gs[0], projection=ccrs.Robinson())
    ax_map.set_global()

    ax_map.add_feature(cfeature.LAND, facecolor='#d9d9d9')
    ax_map.add_feature(cfeature.OCEAN, facecolor='white')
    ax_map.coastlines(linewidth=0.6, color='gray')

    im = ax_map.pcolormesh(
        lon2d,
        lat2d,
        grid,
        cmap=cmap,
        norm=norm,
        transform=ccrs.PlateCarree(),
        shading='auto'
    )

    # ================= PROFILE =================
    ax_prof = fig.add_subplot(gs[1])

    points = np.array([lat_mean, latitudes]).T.reshape(-1, 1, 2)
    segments = np.concatenate([points[:-1], points[1:]], axis=1)

    lc = LineCollection(
        segments,
        cmap=cmap,
        norm=norm,
        linewidth=2
    )

    lc.set_array(lat_mean)
    ax_prof.add_collection(lc)

    # IQR shading
    ax_prof.fill_betweenx(
        latitudes,
        lat_lower,
        lat_upper,
        color='gray',
        alpha=0.3
    )

    # Alignment
    ax_prof.set_ylim(-90, 90)
    ax_prof.set_xlim(vmin, vmax)

    ax_prof.set_yticks(np.arange(-90, 91, 30))
    ax_prof.set_xlabel(cbar_label, fontsize=11)
    ax_prof.set_ylabel('Latitude (°)', fontsize=11)

    ax_prof.grid(True, linestyle='--', alpha=0.4)

    ax_prof.spines['top'].set_visible(False)
    ax_prof.spines['right'].set_visible(False)

    # ================= COLORBAR =================
    cbar = fig.colorbar(
        im,
        ax=ax_map,
        orientation='horizontal',
        pad=0.08,
        fraction=0.05,
        aspect=40
    )

    cbar.set_label(cbar_label, fontsize=11)

    # ================= TITLE =================
    fig.suptitle(title, fontsize=15, y=0.97)

    # Save
    plt.savefig(output_file, dpi=600, bbox_inches='tight')
    plt.show()

# =====================================
# 🌿 CREATE GRIDS
# =====================================

grid_mean, lon2d, lat2d, latitudes = create_grid(df_mean)
grid_sum, _, _, _ = create_grid(df_sum)

# =====================================
# 🌿 MAP 1: MEAN SST
# =====================================

plot_with_profile(
    grid_mean,
    lon2d,
    lat2d,
    latitudes,
    'Global Mangrove Mean Sea Surface Temperature (2000–2020)',
    'SST (°C)',
    str(DATA_DIR / 'SST_mean_profile.png')
)

# =====================================
# 🌿 MAP 2: SUM SST
# =====================================

plot_with_profile(
    grid_sum,
    lon2d,
    lat2d,
    latitudes,
    'Global Mangrove Annual Sum of Sea Surface Temperature (2000–2020)',
    'SST (°C·yr)',
    str(DATA_DIR / 'SST_sum_profile.png')
)



# =====================================

import pandas as pd
import numpy as np
import os

# =====================================
# 📂 INPUT / OUTPUT PATHS
# =====================================

input_folder = str(DATA_DIR / 'chlorophyll')
output_folder = str(DATA_DIR / 'chlorophyll_Annual')
os.makedirs(output_folder, exist_ok=True)

# =====================================
# 🔁 LOOP OVER YEARS
# =====================================

for year in range(2000, 2021):

    print(f'Processing {year}')

    file_path = os.path.join(input_folder, f'chlorophyll_{year}_KDTree.csv')

    if not os.path.exists(file_path):
        print(f'⚠️ Missing {year}, skipping...')
        continue

    # =====================================
    # 📥 LOAD DATA
    # =====================================

    df = pd.read_csv(file_path)

    coords = df.iloc[:, 0:2]

    # Daily Chlorophyll values (mg m^-3)
    chl_daily = df.iloc[:, 2:].apply(pd.to_numeric, errors='coerce')

    # =====================================
    # 🌿 COMPUTE ANNUAL METRICS
    # =====================================

    # Mean Chlorophyll (mg m^-3)
    chl_mean = chl_daily.mean(axis=1)

    # Sum Chlorophyll (mg m^-3 · day)
    chl_sum = chl_daily.sum(axis=1)

    # =====================================
    # 📦 COMBINE RESULTS
    # =====================================

    result = pd.concat([
        coords,
        chl_mean.rename('chl_mean'),
        chl_sum.rename('chl_sum')
    ], axis=1)

    # =====================================
    # 💾 SAVE OUTPUT
    # =====================================

    output_file = os.path.join(output_folder, f'chlorophyll_annual_{year}.csv')
    result.to_csv(output_file, index=False)

    print(f'✅ Saved: {output_file}')

print("\n🎯 Chlorophyll-a annual metrics (NO scaling) completed successfully!")

# =====================================
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature
import os
from matplotlib.collections import LineCollection
import matplotlib as mpl

# =====================================
# 📂 LOAD MULTI-YEAR CHL DATA
# =====================================

folder = str(DATA_DIR / 'chlorophyll_Annual')

all_mean = []
all_sum = []
coords = None

for year in range(2000, 2021):

    file_path = os.path.join(folder, f'chlorophyll_annual_{year}.csv')

    if not os.path.exists(file_path):
        print(f'⚠️ Missing {year}, skipping...')
        continue

    df = pd.read_csv(file_path)

    if coords is None:
        coords = df.iloc[:, 0:2]

    all_mean.append(df['chl_mean'])
    all_sum.append(df['chl_sum'])

# =====================================
# 🌿 MULTI-YEAR MEAN
# =====================================

chl_mean_stack = pd.concat(all_mean, axis=1)
chl_mean_final = chl_mean_stack.mean(axis=1)

chl_sum_stack = pd.concat(all_sum, axis=1)
chl_sum_final = chl_sum_stack.mean(axis=1)

# 👉 Optional (recommended for Nature-level figure)
chl_mean_final = np.log1p(chl_mean_final)
chl_sum_final  = np.log1p(chl_sum_final)

df_mean = coords.copy()
df_mean.columns = ['lon', 'lat']
df_mean['chl'] = chl_mean_final

df_sum = coords.copy()
df_sum.columns = ['lon', 'lat']
df_sum['chl'] = chl_sum_final

# =====================================
# 🌐 GRID FUNCTION (0.25°)
# =====================================

def create_grid(df, res=0.25):

    lon_centers = np.arange(-180 + res/2, 180, res)
    lat_centers = np.arange(-90 + res/2, 90, res)

    grid = np.full((len(lat_centers), len(lon_centers)), np.nan)
    count = np.zeros_like(grid)
    summation = np.zeros_like(grid)

    lon_idx = ((df['lon'] + 180) / res).astype(int)
    lat_idx = ((df['lat'] + 90) / res).astype(int)

    lon_idx = np.clip(lon_idx, 0, len(lon_centers)-1)
    lat_idx = np.clip(lat_idx, 0, len(lat_centers)-1)

    for i in range(len(df)):
        x = lon_idx.iloc[i]
        y = lat_idx.iloc[i]
        val = df['chl'].iloc[i]

        if not np.isnan(val):
            summation[y, x] += val
            count[y, x] += 1

    grid = summation / count
    grid[count == 0] = np.nan

    lon2d, lat2d = np.meshgrid(lon_centers, lat_centers)

    return grid, lon2d, lat2d, lat_centers

# =====================================
# 🎨 PLOTTING FUNCTION
# =====================================

def plot_with_profile(grid, lon2d, lat2d, latitudes, title, cbar_label, output_file):

    lat_mean = np.nanmean(grid, axis=1)
    lat_upper = np.nanpercentile(grid, 75, axis=1)
    lat_lower = np.nanpercentile(grid, 25, axis=1)

    vmin = np.nanpercentile(grid, 5)
    vmax = np.nanpercentile(grid, 95)

    cmap = plt.get_cmap('RdYlBu_r')
    norm = mpl.colors.Normalize(vmin=vmin, vmax=vmax)

    fig = plt.figure(figsize=(16, 6))

    gs = fig.add_gridspec(
        nrows=1, ncols=2,
        width_ratios=[4.5, 1],
        wspace=0.15
    )

    # ================= MAP =================
    ax_map = fig.add_subplot(gs[0], projection=ccrs.Robinson())
    ax_map.set_global()

    ax_map.add_feature(cfeature.LAND, facecolor='#d9d9d9')
    ax_map.add_feature(cfeature.OCEAN, facecolor='white')
    ax_map.coastlines(linewidth=0.6, color='gray')

    im = ax_map.pcolormesh(
        lon2d,
        lat2d,
        grid,
        cmap=cmap,
        norm=norm,
        transform=ccrs.PlateCarree(),
        shading='auto'
    )

    # ================= PROFILE =================
    ax_prof = fig.add_subplot(gs[1])

    points = np.array([lat_mean, latitudes]).T.reshape(-1, 1, 2)
    segments = np.concatenate([points[:-1], points[1:]], axis=1)

    lc = LineCollection(
        segments,
        cmap=cmap,
        norm=norm,
        linewidth=2
    )

    lc.set_array(lat_mean)
    ax_prof.add_collection(lc)

    ax_prof.fill_betweenx(
        latitudes,
        lat_lower,
        lat_upper,
        color='gray',
        alpha=0.3
    )

    ax_prof.set_ylim(-90, 90)
    ax_prof.set_xlim(vmin, vmax)

    ax_prof.set_yticks(np.arange(-90, 91, 30))
    ax_prof.set_xlabel(cbar_label, fontsize=11)
    ax_prof.set_ylabel('Latitude (°)', fontsize=11)

    ax_prof.grid(True, linestyle='--', alpha=0.4)

    ax_prof.spines['top'].set_visible(False)
    ax_prof.spines['right'].set_visible(False)

    # ================= COLORBAR =================
    cbar = fig.colorbar(
        im,
        ax=ax_map,
        orientation='horizontal',
        pad=0.08,
        fraction=0.05,
        aspect=40
    )

    cbar.set_label(cbar_label, fontsize=11)

    fig.suptitle(title, fontsize=15, y=0.97)

    plt.savefig(output_file, dpi=600, bbox_inches='tight')
    plt.show()

# =====================================
# 🌿 CREATE GRIDS
# =====================================

grid_mean, lon2d, lat2d, latitudes = create_grid(df_mean)
grid_sum, _, _, _ = create_grid(df_sum)

# =====================================
# 🌿 MAP 1: MEAN CHL
# =====================================

plot_with_profile(
    grid_mean,
    lon2d,
    lat2d,
    latitudes,
    'Global Mangrove Mean Chlorophyll-a (2000–2020)',
    'Chl-a (log mg m$^{-3}$)',
    str(DATA_DIR / 'chl_mean_profile.png')
)

# =====================================
# 🌿 MAP 2: SUM CHL
# =====================================

plot_with_profile(
    grid_sum,
    lon2d,
    lat2d,
    latitudes,
    'Global Mangrove Annual Sum of Chlorophyll-a (2000–2020)',
    'Chl-a (log mg m$^{-3}$·day)',
    str(DATA_DIR / 'chl_sum_profile.png')
)


# =====================================
import pandas as pd
import numpy as np
import os

# =====================================
# 📂 INPUT / OUTPUT PATHS
# =====================================

input_folder = str(DATA_DIR / 'DO')
output_folder = str(DATA_DIR / 'DO_Annual')
os.makedirs(output_folder, exist_ok=True)

# =====================================
# 🔁 LOOP OVER YEARS
# =====================================

for year in range(2000, 2021):

    print(f'Processing {year}')

    file_path = os.path.join(input_folder, f'DO_{year}_KDTree.csv')

    if not os.path.exists(file_path):
        print(f'⚠️ Missing {year}, skipping...')
        continue

    # =====================================
    # 📥 LOAD DATA
    # =====================================

    df = pd.read_csv(file_path)

    coords = df.iloc[:, 0:2]

    # Daily DO values
    DO_daily = df.iloc[:, 2:].apply(pd.to_numeric, errors='coerce')

    # =====================================
    # 🌿 COMPUTE ANNUAL METRICS
    # =====================================

    # Mean DO
    DO_mean = DO_daily.mean(axis=1)

    # Sum DO (cumulative)
    DO_sum = DO_daily.sum(axis=1)

    # =====================================
    # 📦 COMBINE RESULTS
    # =====================================

    result = pd.concat([
        coords,
        DO_mean.rename('DO_mean'),
        DO_sum.rename('DO_sum')
    ], axis=1)

    # =====================================
    # 💾 SAVE OUTPUT
    # =====================================

    output_file = os.path.join(output_folder, f'DO_annual_{year}.csv')
    result.to_csv(output_file, index=False)

    print(f'✅ Saved: {output_file}')

print("\n🎯 Dissolved Oxygen annual metrics completed successfully!")

# =====================================
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature
import os
from matplotlib.collections import LineCollection
import matplotlib as mpl

# =====================================
# 📂 LOAD MULTI-YEAR DO DATA
# =====================================

folder = str(DATA_DIR / 'DO_Annual')

all_mean = []
all_sum = []
coords = None

for year in range(2000, 2021):

    file_path = os.path.join(folder, f'DO_annual_{year}.csv')

    if not os.path.exists(file_path):
        print(f'⚠️ Missing {year}, skipping...')
        continue

    df = pd.read_csv(file_path)

    if coords is None:
        coords = df.iloc[:, 0:2]

    all_mean.append(df['DO_mean'])
    all_sum.append(df['DO_sum'])

# =====================================
# 🌿 MULTI-YEAR MEAN
# =====================================

DO_mean_stack = pd.concat(all_mean, axis=1)
DO_mean_final = DO_mean_stack.mean(axis=1)

DO_sum_stack = pd.concat(all_sum, axis=1)
DO_sum_final = DO_sum_stack.mean(axis=1)

# 👉 Optional (recommended for Nature-level figure)
DO_mean_final = np.log1p(DO_mean_final)
DO_sum_final  = np.log1p(DO_sum_final)

df_mean = coords.copy()
df_mean.columns = ['lon', 'lat']
df_mean['DO'] = DO_mean_final

df_sum = coords.copy()
df_sum.columns = ['lon', 'lat']
df_sum['DO'] = DO_sum_final

# =====================================
# 🌐 GRID FUNCTION (0.25°)
# =====================================

def create_grid(df, res=0.25):

    lon_centers = np.arange(-180 + res/2, 180, res)
    lat_centers = np.arange(-90 + res/2, 90, res)

    grid = np.full((len(lat_centers), len(lon_centers)), np.nan)
    count = np.zeros_like(grid)
    summation = np.zeros_like(grid)

    lon_idx = ((df['lon'] + 180) / res).astype(int)
    lat_idx = ((df['lat'] + 90) / res).astype(int)

    lon_idx = np.clip(lon_idx, 0, len(lon_centers)-1)
    lat_idx = np.clip(lat_idx, 0, len(lat_centers)-1)

    for i in range(len(df)):
        x = lon_idx.iloc[i]
        y = lat_idx.iloc[i]
        val = df['DO'].iloc[i]

        if not np.isnan(val):
            summation[y, x] += val
            count[y, x] += 1

    grid = summation / count
    grid[count == 0] = np.nan

    lon2d, lat2d = np.meshgrid(lon_centers, lat_centers)

    return grid, lon2d, lat2d, lat_centers

# =====================================
# 🎨 PLOTTING FUNCTION
# =====================================

def plot_with_profile(grid, lon2d, lat2d, latitudes, title, cbar_label, output_file):

    lat_mean = np.nanmean(grid, axis=1)
    lat_upper = np.nanpercentile(grid, 75, axis=1)
    lat_lower = np.nanpercentile(grid, 25, axis=1)

    vmin = np.nanpercentile(grid, 5)
    vmax = np.nanpercentile(grid, 95)

    cmap = plt.get_cmap('RdYlBu_r')
    norm = mpl.colors.Normalize(vmin=vmin, vmax=vmax)

    fig = plt.figure(figsize=(16, 6))

    gs = fig.add_gridspec(
        nrows=1, ncols=2,
        width_ratios=[4.5, 1],
        wspace=0.15
    )

    # ================= MAP =================
    ax_map = fig.add_subplot(gs[0], projection=ccrs.Robinson())
    ax_map.set_global()

    ax_map.add_feature(cfeature.LAND, facecolor='#d9d9d9')
    ax_map.add_feature(cfeature.OCEAN, facecolor='white')
    ax_map.coastlines(linewidth=0.6, color='gray')

    im = ax_map.pcolormesh(
        lon2d,
        lat2d,
        grid,
        cmap=cmap,
        norm=norm,
        transform=ccrs.PlateCarree(),
        shading='auto'
    )

    # ================= PROFILE =================
    ax_prof = fig.add_subplot(gs[1])

    points = np.array([lat_mean, latitudes]).T.reshape(-1, 1, 2)
    segments = np.concatenate([points[:-1], points[1:]], axis=1)

    lc = LineCollection(
        segments,
        cmap=cmap,
        norm=norm,
        linewidth=2
    )

    lc.set_array(lat_mean)
    ax_prof.add_collection(lc)

    ax_prof.fill_betweenx(
        latitudes,
        lat_lower,
        lat_upper,
        color='gray',
        alpha=0.3
    )

    ax_prof.set_ylim(-90, 90)
    ax_prof.set_xlim(vmin, vmax)

    ax_prof.set_yticks(np.arange(-90, 91, 30))
    ax_prof.set_xlabel(cbar_label, fontsize=11)
    ax_prof.set_ylabel('Latitude (°)', fontsize=11)

    ax_prof.grid(True, linestyle='--', alpha=0.4)

    ax_prof.spines['top'].set_visible(False)
    ax_prof.spines['right'].set_visible(False)

    # ================= COLORBAR =================
    cbar = fig.colorbar(
        im,
        ax=ax_map,
        orientation='horizontal',
        pad=0.08,
        fraction=0.05,
        aspect=40
    )

    cbar.set_label(cbar_label, fontsize=11)

    fig.suptitle(title, fontsize=15, y=0.97)

    plt.savefig(output_file, dpi=600, bbox_inches='tight')
    plt.show()

# =====================================
# 🌿 CREATE GRIDS
# =====================================

grid_mean, lon2d, lat2d, latitudes = create_grid(df_mean)
grid_sum, _, _, _ = create_grid(df_sum)

# =====================================
# 🌿 MAP 1: MEAN DO
# =====================================

plot_with_profile(
    grid_mean,
    lon2d,
    lat2d,
    latitudes,
    'Global Mangrove Mean Dissolved Oxygen (2000–2020)',
    'DO (log mg L$^{-1}$)',
    str(DATA_DIR / 'DO_mean_profile.png')
)

# =====================================
# 🌿 MAP 2: SUM DO
# =====================================

plot_with_profile(
    grid_sum,
    lon2d,
    lat2d,
    latitudes,
    'Global Mangrove Annual Sum of Dissolved Oxygen (2000–2020)',
    'DO (log mg L$^{-1}$·day)',
    str(DATA_DIR / 'DO_sum_profile.png')
)

# =====================================




import pandas as pd
import numpy as np
import os

# =====================================
# 📂 INPUT / OUTPUT PATHS
# =====================================

# Input folder (daily SSH files)
input_folder = str(DATA_DIR / 'SSH')

# Output folder
output_folder = str(DATA_DIR / 'SSH_Annual')
os.makedirs(output_folder, exist_ok=True)

# =====================================
# 🔁 LOOP OVER YEARS
# =====================================

for year in range(2000, 2021):

    print(f'Processing {year}')

    file_path = os.path.join(input_folder, f'SSH_{year}_KDTree.csv')

    if not os.path.exists(file_path):
        print(f'⚠️ Missing {year}, skipping...')
        continue

    # =====================================
    # 📥 LOAD DATA
    # =====================================

    df = pd.read_csv(file_path)

    # Coordinates
    coords = df.iloc[:, 0:2]

    # Daily SSH values (meters)
    SSH_daily = df.iloc[:, 2:].apply(pd.to_numeric, errors='coerce')

    # =====================================
    # 🌊 COMPUTE ANNUAL METRICS
    # =====================================

    # Mean SSH (m)
    SSH_mean = SSH_daily.mean(axis=1)

    # Sum SSH (m·day)
    SSH_sum = SSH_daily.sum(axis=1)

    # =====================================
    # 📦 COMBINE RESULTS
    # =====================================

    result = pd.concat([
        coords,
        SSH_mean.rename('SSH_mean'),
        SSH_sum.rename('SSH_sum')
    ], axis=1)

    # =====================================
    # 💾 SAVE OUTPUT
    # =====================================

    output_file = os.path.join(output_folder, f'SSH_annual_{year}.csv')
    result.to_csv(output_file, index=False)

    print(f'✅ Saved: {output_file}')

print("\n🎯 SSH annual metrics calculated successfully!")

# =====================================
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature
import os
from matplotlib.collections import LineCollection
import matplotlib as mpl

# =====================================
# 📂 LOAD MULTI-YEAR SSH DATA
# =====================================

folder = str(DATA_DIR / 'SSH_Annual')

all_mean = []
all_sum = []
coords = None

for year in range(2000, 2021):

    file_path = os.path.join(folder, f'SSH_annual_{year}.csv')

    if not os.path.exists(file_path):
        print(f'⚠️ Missing {year}, skipping...')
        continue

    df = pd.read_csv(file_path)

    if coords is None:
        coords = df.iloc[:, 0:2]

    all_mean.append(df['SSH_mean'])
    all_sum.append(df['SSH_sum'])

# =====================================
# 🌿 MULTI-YEAR MEAN
# =====================================

SSH_mean_stack = pd.concat(all_mean, axis=1)
SSH_mean_final = SSH_mean_stack.mean(axis=1)

SSH_sum_stack = pd.concat(all_sum, axis=1)
SSH_sum_final = SSH_sum_stack.mean(axis=1)

# 👉 Optional: log scale ONLY for sum (recommended)
SSH_sum_final = np.log1p(SSH_sum_final)

df_mean = coords.copy()
df_mean.columns = ['lon', 'lat']
df_mean['SSH'] = SSH_mean_final

df_sum = coords.copy()
df_sum.columns = ['lon', 'lat']
df_sum['SSH'] = SSH_sum_final

# =====================================
# 🌐 GRID FUNCTION (0.25°)
# =====================================

def create_grid(df, res=0.25):

    lon_centers = np.arange(-180 + res/2, 180, res)
    lat_centers = np.arange(-90 + res/2, 90, res)

    grid = np.full((len(lat_centers), len(lon_centers)), np.nan)
    count = np.zeros_like(grid)
    summation = np.zeros_like(grid)

    lon_idx = ((df['lon'] + 180) / res).astype(int)
    lat_idx = ((df['lat'] + 90) / res).astype(int)

    lon_idx = np.clip(lon_idx, 0, len(lon_centers)-1)
    lat_idx = np.clip(lat_idx, 0, len(lat_centers)-1)

    for i in range(len(df)):
        x = lon_idx.iloc[i]
        y = lat_idx.iloc[i]
        val = df['SSH'].iloc[i]

        if not np.isnan(val):
            summation[y, x] += val
            count[y, x] += 1

    grid = summation / count
    grid[count == 0] = np.nan

    lon2d, lat2d = np.meshgrid(lon_centers, lat_centers)

    return grid, lon2d, lat2d, lat_centers

# =====================================
# 🎨 PLOT FUNCTION
# =====================================

def plot_with_profile(grid, lon2d, lat2d, latitudes, title, cbar_label, output_file):

    lat_mean = np.nanmean(grid, axis=1)
    lat_upper = np.nanpercentile(grid, 75, axis=1)
    lat_lower = np.nanpercentile(grid, 25, axis=1)

    vmin = np.nanpercentile(grid, 5)
    vmax = np.nanpercentile(grid, 95)

    cmap = plt.get_cmap('RdYlBu_r')
    norm = mpl.colors.Normalize(vmin=vmin, vmax=vmax)

    fig = plt.figure(figsize=(16, 6))

    gs = fig.add_gridspec(1, 2, width_ratios=[4.5, 1], wspace=0.15)

    # MAP
    ax_map = fig.add_subplot(gs[0], projection=ccrs.Robinson())
    ax_map.set_global()
    ax_map.add_feature(cfeature.LAND, facecolor='#d9d9d9')
    ax_map.add_feature(cfeature.OCEAN, facecolor='white')
    ax_map.coastlines(linewidth=0.6, color='gray')

    im = ax_map.pcolormesh(
        lon2d, lat2d, grid,
        cmap=cmap, norm=norm,
        transform=ccrs.PlateCarree(),
        shading='auto'
    )

    # PROFILE
    ax_prof = fig.add_subplot(gs[1])

    points = np.array([lat_mean, latitudes]).T.reshape(-1, 1, 2)
    segments = np.concatenate([points[:-1], points[1:]], axis=1)

    lc = LineCollection(segments, cmap=cmap, norm=norm, linewidth=2)
    lc.set_array(lat_mean)
    ax_prof.add_collection(lc)

    ax_prof.fill_betweenx(latitudes, lat_lower, lat_upper, color='gray', alpha=0.3)

    ax_prof.set_ylim(-90, 90)
    ax_prof.set_xlim(vmin, vmax)
    ax_prof.set_yticks(np.arange(-90, 91, 30))
    ax_prof.set_xlabel(cbar_label)
    ax_prof.set_ylabel('Latitude (°)')
    ax_prof.grid(True, linestyle='--', alpha=0.4)

    # COLORBAR
    cbar = fig.colorbar(im, ax=ax_map, orientation='horizontal', pad=0.08)
    cbar.set_label(cbar_label)

    fig.suptitle(title, fontsize=15)
    plt.savefig(output_file, dpi=600, bbox_inches='tight')
    plt.show()

# =====================================
# 🌿 CREATE GRIDS
# =====================================

grid_mean, lon2d, lat2d, latitudes = create_grid(df_mean)
grid_sum, _, _, _ = create_grid(df_sum)

# =====================================
# 🌿 MAPS
# =====================================

plot_with_profile(
    grid_mean,
    lon2d,
    lat2d,
    latitudes,
    'Global Mean Sea Surface Height (2000–2020)',
    'SSH (m)',
    str(DATA_DIR / 'SSH_mean_profile.png')
)

plot_with_profile(
    grid_sum,
    lon2d,
    lat2d,
    latitudes,
    'Global Annual Sum of Sea Surface Height (2000–2020)',
    'SSH (log m·day)',
    str(DATA_DIR / 'SSH_sum_profile.png')
)


# 🌿 ============================================
# ✅ Growing Degree Days (GDD) for Mangroves
# Using Temp folder:
# Temp_max_KDTree_{year}.csv
# Temp_min_KDTree_{year}.csv
# ============================================

import pandas as pd
import numpy as np
import os

# ============================================
# 📂 INPUT / OUTPUT PATHS
# ============================================

# Both Tmin and Tmax are inside Temp folder
input_folder = str(DATA_DIR / 'Temp')

# Output folder
output_folder = str(DATA_DIR / 'GDD')
os.makedirs(output_folder, exist_ok=True)

# ============================================
# 🌡️ TEMPERATURE THRESHOLDS
# ============================================

Tb = 19.0      # Lower threshold (°C)
Tu = 40.7      # Upper threshold (°C)

# ============================================
# 🔁 LOOP OVER YEARS
# ============================================

for year in range(2000, 2021):

    print(f'\nProcessing {year}')

    # ============================================
    # 📂 FILE NAMES
    # ============================================

    file_min = os.path.join(
        input_folder,
        f'Temp_min_KDTree_{year}.csv'
    )

    file_max = os.path.join(
        input_folder,
        f'Temp_max_KDTree_{year}.csv'
    )

    # ============================================
    # ⚠️ CHECK FILES
    # ============================================

    if not os.path.exists(file_min):
        print(f'⚠️ Missing Tmin file for {year}')
        continue

    if not os.path.exists(file_max):
        print(f'⚠️ Missing Tmax file for {year}')
        continue

    # ============================================
    # 📥 LOAD DATA
    # ============================================

    df_min = pd.read_csv(file_min)
    df_max = pd.read_csv(file_max)

    # Coordinates
    coords = df_min.iloc[:, 0:2]

    # Daily temperature values
    Tmin = df_min.iloc[:, 2:].apply(pd.to_numeric, errors='coerce')
    Tmax = df_max.iloc[:, 2:].apply(pd.to_numeric, errors='coerce')

    Tmin_values = Tmin.values
    Tmax_values = Tmax.values

    # ============================================
    # 🌡️ INITIALIZE GDD ARRAY
    # ============================================

    GDD = np.full_like(Tmin_values, np.nan, dtype=float)

    # ============================================
    # 🌡️ AUXILIARY VARIABLES
    # ============================================

    alpha = (Tmax_values - Tmin_values) / 2
    Tmean = (Tmax_values + Tmin_values) / 2

    # Prevent division by zero
    alpha_safe = np.where(alpha == 0, np.nan, alpha)

    # ============================================
    # 🌡️ θ1 and θ2
    # ============================================

    arg1 = (Tb - Tmean) / alpha_safe
    arg2 = (Tu - Tmean) / alpha_safe

    arg1 = np.clip(arg1, -1, 1)
    arg2 = np.clip(arg2, -1, 1)

    theta1 = np.arcsin(arg1)
    theta2 = np.arcsin(arg2)

    # ============================================
    # 🌿 CASE 1
    # Tx < Tb
    # ============================================

    mask1 = Tmax_values < Tb

    GDD[mask1] = 0

    # ============================================
    # 🌿 CASE 2
    # Tn < Tb and Tb < Tx < Tu
    # ============================================

    mask2 = (
        (Tmin_values < Tb) &
        (Tmax_values > Tb) &
        (Tmax_values < Tu)
    )

    GDD[mask2] = (
        (1 / np.pi) *
        (
            (Tmean[mask2] - Tb) *
            (np.pi / 2 - theta1[mask2]) +
            alpha[mask2] * np.cos(theta1[mask2])
        )
    )

    # ============================================
    # 🌿 CASE 3
    # Tn > Tb and Tx < Tu
    # ============================================

    mask3 = (
        (Tmin_values > Tb) &
        (Tmax_values < Tu)
    )

    GDD[mask3] = Tmean[mask3] - Tb

    # ============================================
    # 🌿 CASE 4
    # Tn > Tu and Tx > Tu
    # ============================================

    mask4 = (
        (Tmin_values > Tu) &
        (Tmax_values > Tu)
    )

    GDD[mask4] = (Tu - Tb) / 2

    # ============================================
    # 🌿 CASE 5
    # Tn < Tb and Tx > Tu
    # ============================================

    mask5 = (
        (Tmin_values < Tb) &
        (Tmax_values > Tu)
    )

    GDD[mask5] = (
        (1 / np.pi) *
        (
            (Tmean[mask5] - Tb) *
            (theta2[mask5] - theta1[mask5]) +
            alpha[mask5] *
            (
                np.cos(theta1[mask5]) -
                np.cos(theta2[mask5])
            ) +
            (Tu - Tb) *
            (np.pi / 2 - theta2[mask5])
        )
    )

    # ============================================
    # 🔒 HANDLE INVALID VALUES
    # ============================================

    invalid = (
        np.isnan(Tmin_values) |
        np.isnan(Tmax_values)
    )

    GDD[invalid] = np.nan

    # Prevent negative values
    GDD = np.clip(GDD, 0, None)

    # ============================================
    # 📦 SAVE DAILY GDD
    # ============================================

    GDD_df = pd.DataFrame(
        GDD,
        columns=Tmin.columns
    )

    result = pd.concat(
        [coords, GDD_df],
        axis=1
    )

    output_file = os.path.join(
        output_folder,
        f'GDD_{year}.csv'
    )

    result.to_csv(output_file, index=False)

    print(f'✅ Saved: {output_file}')

print("\n🎯 GDD calculation completed successfully!")



# =====================================

import pandas as pd
import numpy as np
import os

# =====================================
# 📂 INPUT / OUTPUT PATHS
# =====================================

# Input folder (daily GDD files)
input_folder = str(DATA_DIR / 'GDD')

# Output folder
output_folder = str(DATA_DIR / 'GDD_Annual')
os.makedirs(output_folder, exist_ok=True)

# =====================================
# 🔁 LOOP OVER YEARS
# =====================================

for year in range(2000, 2021):

    print(f'Processing {year}')

    # Updated filename format
    file_path = os.path.join(input_folder, f'GDD_{year}.csv')

    if not os.path.exists(file_path):
        print(f'⚠️ Missing {year}, skipping...')
        continue

    # =====================================
    # 📥 LOAD DATA
    # =====================================

    df = pd.read_csv(file_path)

    # Coordinates
    coords = df.iloc[:, 0:2]

    # Daily GDD values
    GDD_daily = df.iloc[:, 2:].apply(pd.to_numeric, errors='coerce')

    # =====================================
    # 🌱 COMPUTE ANNUAL METRICS
    # =====================================

    # Mean annual GDD
    GDD_mean = GDD_daily.mean(axis=1)

    # Total annual GDD
    GDD_sum = GDD_daily.sum(axis=1)


    # =====================================
    # 📦 COMBINE RESULTS
    # =====================================

    result = pd.concat([
        coords,
        GDD_mean.rename('GDD_mean'),
        GDD_sum.rename('GDD_sum'),
    ], axis=1)

    # =====================================
    # 💾 SAVE OUTPUT
    # =====================================

    output_file = os.path.join(output_folder, f'GDD_annual_{year}.csv')
    result.to_csv(output_file, index=False)

    print(f'✅ Saved: {output_file}')

print("\n🎯 GDD annual metrics calculated successfully!")



# =====================================
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature
import os
from matplotlib.collections import LineCollection
import matplotlib as mpl

# =====================================
# 📂 LOAD MULTI-YEAR GDD DATA
# =====================================

folder = str(DATA_DIR / 'GDD_Annual')

all_mean = []
all_sum = []
coords = None

for year in range(2000, 2021):

    file_path = os.path.join(folder, f'GDD_annual_{year}.csv')

    if not os.path.exists(file_path):
        print(f'⚠️ Missing {year}, skipping...')
        continue

    df = pd.read_csv(file_path)

    if coords is None:
        coords = df.iloc[:, 0:2]

    all_mean.append(df['GDD_mean'])
    all_sum.append(df['GDD_sum'])

# =====================================
# 🌿 MULTI-YEAR MEAN
# =====================================

GDD_mean_stack = pd.concat(all_mean, axis=1)
GDD_mean_final = GDD_mean_stack.mean(axis=1)

GDD_sum_stack = pd.concat(all_sum, axis=1)
GDD_sum_final = GDD_sum_stack.mean(axis=1)



df_mean = coords.copy()
df_mean.columns = ['lon', 'lat']
df_mean['GDD'] = GDD_mean_final

df_sum = coords.copy()
df_sum.columns = ['lon', 'lat']
df_sum['GDD'] = GDD_sum_final

# =====================================
# 🌐 GRID FUNCTION (0.25°)
# =====================================

def create_grid(df, res=0.25):

    lon_centers = np.arange(-180 + res/2, 180, res)
    lat_centers = np.arange(-90 + res/2, 90, res)

    grid = np.full((len(lat_centers), len(lon_centers)), np.nan)
    count = np.zeros_like(grid)
    summation = np.zeros_like(grid)

    lon_idx = ((df['lon'] + 180) / res).astype(int)
    lat_idx = ((df['lat'] + 90) / res).astype(int)

    lon_idx = np.clip(lon_idx, 0, len(lon_centers)-1)
    lat_idx = np.clip(lat_idx, 0, len(lat_centers)-1)

    for i in range(len(df)):
        x = lon_idx.iloc[i]
        y = lat_idx.iloc[i]
        val = df['GDD'].iloc[i]

        if not np.isnan(val):
            summation[y, x] += val
            count[y, x] += 1

    grid = summation / count
    grid[count == 0] = np.nan

    lon2d, lat2d = np.meshgrid(lon_centers, lat_centers)

    return grid, lon2d, lat2d, lat_centers

# =====================================
# 🎨 PLOT FUNCTION
# =====================================

def plot_with_profile(grid, lon2d, lat2d, latitudes,
                      title, cbar_label, output_file):

    lat_mean = np.nanmean(grid, axis=1)
    lat_upper = np.nanpercentile(grid, 75, axis=1)
    lat_lower = np.nanpercentile(grid, 25, axis=1)

    vmin = np.nanpercentile(grid, 5)
    vmax = np.nanpercentile(grid, 95)

    cmap = plt.get_cmap('RdYlBu_r')
    norm = mpl.colors.Normalize(vmin=vmin, vmax=vmax)

    fig = plt.figure(figsize=(16, 6))

    gs = fig.add_gridspec(
        1, 2,
        width_ratios=[4.5, 1],
        wspace=0.15
    )

    # =====================================
    # 🌍 MAP
    # =====================================

    ax_map = fig.add_subplot(gs[0], projection=ccrs.Robinson())

    ax_map.set_global()

    ax_map.add_feature(
        cfeature.LAND,
        facecolor='#d9d9d9'
    )

    ax_map.add_feature(
        cfeature.OCEAN,
        facecolor='white'
    )

    ax_map.coastlines(
        linewidth=0.6,
        color='gray'
    )

    im = ax_map.pcolormesh(
        lon2d,
        lat2d,
        grid,
        cmap=cmap,
        norm=norm,
        transform=ccrs.PlateCarree(),
        shading='auto'
    )

    # =====================================
    # 📈 LATITUDINAL PROFILE
    # =====================================

    ax_prof = fig.add_subplot(gs[1])

    points = np.array(
        [lat_mean, latitudes]
    ).T.reshape(-1, 1, 2)

    segments = np.concatenate(
        [points[:-1], points[1:]],
        axis=1
    )

    lc = LineCollection(
        segments,
        cmap=cmap,
        norm=norm,
        linewidth=2
    )

    lc.set_array(lat_mean)

    ax_prof.add_collection(lc)

    ax_prof.fill_betweenx(
        latitudes,
        lat_lower,
        lat_upper,
        color='gray',
        alpha=0.3
    )

    ax_prof.set_ylim(-90, 90)
    ax_prof.set_xlim(vmin, vmax)

    ax_prof.set_yticks(
        np.arange(-90, 91, 30)
    )

    ax_prof.set_xlabel(cbar_label)
    ax_prof.set_ylabel('Latitude (°)')

    ax_prof.grid(
        True,
        linestyle='--',
        alpha=0.4
    )

    # =====================================
    # 🎨 COLORBAR
    # =====================================

    cbar = fig.colorbar(
        im,
        ax=ax_map,
        orientation='horizontal',
        pad=0.08
    )

    cbar.set_label(cbar_label)

    # =====================================
    # 💾 SAVE FIGURE
    # =====================================

    fig.suptitle(title, fontsize=15)

    plt.savefig(
        output_file,
        dpi=600,
        bbox_inches='tight'
    )

    plt.show()

# =====================================
# 🌿 CREATE GRIDS
# =====================================

grid_mean, lon2d, lat2d, latitudes = create_grid(df_mean)

grid_sum, _, _, _ = create_grid(df_sum)

# =====================================
# 🌿 PLOT MAPS
# =====================================

plot_with_profile(
    grid_mean,
    lon2d,
    lat2d,
    latitudes,
    'Global Mean Growing Degree Days (2000–2020)',
    'GDD Mean',
    str(DATA_DIR / 'GDD_mean_profile.png')
)

plot_with_profile(
    grid_sum,
    lon2d,
    lat2d,
    latitudes,
    'Global Annual Sum of Growing Degree Days (2000–2020)',
    'log(GDD Sum)',
    str(DATA_DIR / 'GDD_sum_profile.png')
)












import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature
import os
import matplotlib as mpl
from matplotlib.collections import LineCollection

# =====================================
# 📂 PATHS
# =====================================

paths = {
    "GDD": str(DATA_DIR / 'GDD_Annual'),
    "TI": str(DATA_DIR / 'TI_Annual'),
    "TImax": str(DATA_DIR / 'TImax_Annual'),
    "TImin": str(DATA_DIR / 'TImin_Annual'),
    "VPD": str(DATA_DIR / 'VPD_Annual'),
    "DTR": str(DATA_DIR / 'DTR_Annual'),
    "PI": str(DATA_DIR / 'PI_Annual'),
    "E0": str(DATA_DIR / 'E0_Annual'),
    "SI": str(DATA_DIR / 'SI_Annual')
}

var_names = {
    "GDD": "GDD_mean",
    "TI": "TI_mean",
    "TImax": "TI_mean",
    "TImin": "TI_mean",
    "VPD": "VPD_mean",
    "DTR": "DTR_mean",
    "PI": "PI_mean",
    "E0": "E0_mean",
    "SI": "SI_mean"
}

units = {
    "E0": "E₀ (gC MJ$^{-1}$)",
    "PI": "PI (gC m$^{-2}$ d$^{-1}$)",
    "VPD": "VPD (kPa)",
    "DTR": "DTR (°C)",
    "GDD": "GDD (°C day)",
    "TI": "TI",
    "TImax": "TImax",
    "TImin": "TImin",
    "SI": "SI"
}

variables = list(paths.keys())

# =====================================
# 🌿 LOAD FUNCTION (SAFE)
# =====================================

def load_variable(folder, colname, var):

    all_data = []
    coords = None

    for year in range(2000, 2021):

        file = os.path.join(folder, f'{var}_annual_{year}.csv')
        if not os.path.exists(file):
            continue

        df = pd.read_csv(file)

        if coords is None:
            coords = df.iloc[:, 0:2]

        if colname not in df.columns:
            continue

        all_data.append(df[colname])

    if len(all_data) == 0:
        return None

    stack = pd.concat(all_data, axis=1)
    mean = stack.mean(axis=1)

    df_final = coords.copy()
    df_final.columns = ['lon', 'lat']
    df_final['val'] = mean

    return df_final

# =====================================
# 🌐 GRID FUNCTION (STYLE MATCHED)
# =====================================

def create_grid(df, res=0.25):

    lon_c = np.arange(-180 + res/2, 180, res)
    lat_c = np.arange(-90 + res/2, 90, res)

    grid = np.full((len(lat_c), len(lon_c)), np.nan)
    count = np.zeros_like(grid)
    summation = np.zeros_like(grid)

    lon_idx = ((df['lon'] + 180) / res).astype(int)
    lat_idx = ((df['lat'] + 90) / res).astype(int)

    lon_idx = np.clip(lon_idx, 0, len(lon_c)-1)
    lat_idx = np.clip(lat_idx, 0, len(lat_c)-1)

    for i in range(len(df)):
        x = lon_idx.iloc[i]
        y = lat_idx.iloc[i]
        v = df['val'].iloc[i]

        if not np.isnan(v):
            summation[y, x] += v
            count[y, x] += 1

    grid = np.full_like(summation, np.nan, dtype=float)
    mask = count > 0
    grid[mask] = summation[mask] / count[mask]

    lon2d, lat2d = np.meshgrid(lon_c, lat_c)

    return grid, lon2d, lat2d, lat_c

# =====================================
# 📊 LOAD ALL VARIABLES
# =====================================

grids = {}

for var in variables:
    df = load_variable(paths[var], var_names[var], var)

    if df is None:
        print(f"⚠️ Skipping {var} (no data)")
        continue

    grids[var] = create_grid(df)

# =====================================
# 🎨 NORMALIZATION (STYLE MATCHED)
# =====================================

cmap = plt.get_cmap('RdYlBu_r')
norms = {}

for var in grids:
    g = grids[var][0]
    norms[var] = mpl.colors.Normalize(
        vmin=np.nanpercentile(g, 5),
        vmax=np.nanpercentile(g, 95)
    )

# =====================================
# 📐 FIGURE (3×3 STYLE MATCHED)
# =====================================

fig = plt.figure(figsize=(24, 18))

gs = fig.add_gridspec(
    3, 6,
    width_ratios=[4, 1, 4, 1, 4, 1],
    hspace=0.28,
    wspace=0.18
)

panel_labels = [
    '(a)','(b)','(c)',
    '(d)','(e)','(f)',
    '(g)','(h)','(i)'
]

vars_list = list(grids.keys())

# =====================================
# 🌍 PLOTTING (MAP + PROFILE STYLE MATCHED)
# =====================================

for i, var in enumerate(vars_list[:9]):

    row = i // 3
    block = i % 3

    col_map = block * 2
    col_prof = col_map + 1

    grid, lon2d, lat2d, latitudes = grids[var]

    # ================= MAP =================
    ax = fig.add_subplot(gs[row, col_map], projection=ccrs.Robinson())
    ax.set_global()

    ax.add_feature(cfeature.LAND, facecolor='#d9d9d9')
    ax.add_feature(cfeature.OCEAN, facecolor='white')
    ax.coastlines(linewidth=0.5, color='gray')

    im = ax.pcolormesh(
        lon2d, lat2d, grid,
        cmap=cmap,
        norm=norms[var],
        transform=ccrs.PlateCarree(),
        shading='auto'
    )

    ax.set_title(units[var], fontsize=11, pad=12)

    ax.text(-0.08, 1.08, panel_labels[i],
            transform=ax.transAxes,
            fontsize=13, fontweight='bold')

    # ================= PROFILE =================
    axp = fig.add_subplot(gs[row, col_prof])

    lat_mean = np.nanmean(grid, axis=1)
    lat_upper = np.nanpercentile(grid, 75, axis=1)
    lat_lower = np.nanpercentile(grid, 25, axis=1)

    mask = (latitudes >= -40) & (latitudes <= 40)

    latitudes_f = latitudes[mask]
    lat_mean = lat_mean[mask]
    lat_upper = lat_upper[mask]
    lat_lower = lat_lower[mask]

    points = np.array([lat_mean, latitudes_f]).T.reshape(-1, 1, 2)
    segments = np.concatenate([points[:-1], points[1:]], axis=1)

    lc = LineCollection(segments, cmap=cmap, norm=norms[var], linewidth=2)
    lc.set_array(lat_mean)
    axp.add_collection(lc)

    axp.fill_betweenx(latitudes_f, lat_lower, lat_upper,
                      color='gray', alpha=0.3)

    axp.set_ylim(-40, 40)
    axp.set_xlim(norms[var].vmin, norms[var].vmax)

    axp.set_yticks(np.arange(-40, 41, 20))
    axp.set_xlabel(units[var], fontsize=9)

    if block == 0:
        axp.set_ylabel('Latitude (°)', fontsize=10)

    axp.grid(True, linestyle='--', alpha=0.3)

    axp.spines['top'].set_visible(False)
    axp.spines['right'].set_visible(False)

    # ================= COLORBAR =================
    cbar = fig.colorbar(
        im,
        ax=ax,
        orientation='horizontal',
        pad=0.12,
        fraction=0.05
    )
    cbar.set_label(units[var], fontsize=9)

# =====================================
# 🏁 TITLE
# =====================================

fig.suptitle(
    'Global Mangrove Eco-Physiological Drivers (2000–2020)\n'
    'Spatial Patterns and Latitudinal Profiles',
    fontsize=22,
    y=0.995
)

plt.subplots_adjust(top=0.92, bottom=0.06)

plt.savefig(
    str(DATA_DIR / 'FINAL_3x3_STYLE_MATCHED.png'),
    dpi=600,
    bbox_inches='tight'
)

plt.show()
##=====================================







import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature
import os
import matplotlib as mpl
from matplotlib.collections import LineCollection

# =====================================
# 📂 PATHS
# =====================================

paths = {
    "SST": str(DATA_DIR / 'SST_Annual'),
    "SSH": str(DATA_DIR / 'SSH_Annual'),
    "CHL": str(DATA_DIR / 'chlorophyll_Annual'),
    "DO":  str(DATA_DIR / 'DO_Annual')
}

var_names = {
    "SST": "SST_mean",
    "SSH": "SSH_mean",
    "CHL": "chl_mean",
    "DO":  "DO_mean"
}

units = {
    "SST": "SST (°C)",
    "SSH": "SSH (m)",
    "CHL": "Chl-a (mg m$^{-3}$)",
    "DO":  "DO (mmol m$^{-3}$)"
}

variables = ["SST", "SSH", "CHL", "DO"]

# =====================================
# 🌿 LOAD FUNCTION
# =====================================

def load_variable(folder, colname, var):

    all_data = []
    coords = None

    for year in range(2000, 2021):

        if var == "CHL":
            file = os.path.join(folder, f'chlorophyll_annual_{year}.csv')
        else:
            file = os.path.join(folder, f'{var}_annual_{year}.csv')

        if not os.path.exists(file):
            continue

        df = pd.read_csv(file)

        if coords is None:
            coords = df.iloc[:, 0:2]

        all_data.append(df[colname])

    stack = pd.concat(all_data, axis=1)
    mean = stack.mean(axis=1)

    df_final = coords.copy()
    df_final.columns = ['lon', 'lat']
    df_final['val'] = mean

    return df_final

# =====================================
# 🌐 GRID FUNCTION
# =====================================

def create_grid(df, res=0.25):

    lon_c = np.arange(-180 + res/2, 180, res)
    lat_c = np.arange(-90 + res/2, 90, res)

    grid = np.full((len(lat_c), len(lon_c)), np.nan)
    count = np.zeros_like(grid)
    summation = np.zeros_like(grid)

    lon_idx = ((df['lon'] + 180) / res).astype(int)
    lat_idx = ((df['lat'] + 90) / res).astype(int)

    lon_idx = np.clip(lon_idx, 0, len(lon_c)-1)
    lat_idx = np.clip(lat_idx, 0, len(lat_c)-1)

    for i in range(len(df)):
        x = lon_idx.iloc[i]
        y = lat_idx.iloc[i]
        v = df['val'].iloc[i]

        if not np.isnan(v):
            summation[y, x] += v
            count[y, x] += 1

    grid = summation / count
    grid[count == 0] = np.nan

    lon2d, lat2d = np.meshgrid(lon_c, lat_c)

    return grid, lon2d, lat2d, lat_c

# =====================================
# 📊 LOAD DATA
# =====================================

grids = {}

for var in variables:
    df = load_variable(paths[var], var_names[var], var)
    grid_data = create_grid(df)

    grid = grid_data[0]


    grids[var] = (grid, grid_data[1], grid_data[2], grid_data[3])

# =====================================
# 🎨 NORMALIZATION
# =====================================

cmap = plt.get_cmap('RdYlBu_r')
norms = {}

for var in grids:
    g = grids[var][0]
    norms[var] = mpl.colors.Normalize(
        vmin=np.nanpercentile(g, 5),
        vmax=np.nanpercentile(g, 95)
    )

# =====================================
# 📐 FIGURE (2×2 VARIABLES → 2×4 PANELS)
# =====================================

fig = plt.figure(figsize=(16, 10))

gs = fig.add_gridspec(
    nrows=2, ncols=4,
    width_ratios=[4, 1, 4, 1],
    hspace=0.35,
    wspace=0.15
)

panel_labels = ['(a)', '(b)', '(c)', '(d)']

for i, var in enumerate(variables):

    row = i // 2
    col_map = (i % 2) * 2
    col_prof = col_map + 1

    grid, lon2d, lat2d, latitudes = grids[var]

    # ================= MAP =================
    ax = fig.add_subplot(gs[row, col_map], projection=ccrs.Robinson())
    ax.set_global()

    ax.add_feature(cfeature.LAND, facecolor='#d9d9d9')
    ax.add_feature(cfeature.OCEAN, facecolor='white')
    ax.coastlines(linewidth=0.5, color='gray')

    im = ax.pcolormesh(
        lon2d, lat2d, grid,
        cmap=cmap,
        norm=norms[var],
        transform=ccrs.PlateCarree(),
        shading='auto'
    )

    ax.set_title(units[var], fontsize=11, pad=12)

    ax.text(-0.08, 1.08, panel_labels[i],
            transform=ax.transAxes,
            fontsize=13, fontweight='bold')

    # ================= PROFILE =================
    axp = fig.add_subplot(gs[row, col_prof])

    lat_mean = np.nanmean(grid, axis=1)
    lat_upper = np.nanpercentile(grid, 75, axis=1)
    lat_lower = np.nanpercentile(grid, 25, axis=1)

    mask = (latitudes >= -90) & (latitudes <= 90)

    latitudes_f = latitudes[mask]
    lat_mean = lat_mean[mask]
    lat_upper = lat_upper[mask]
    lat_lower = lat_lower[mask]

    points = np.array([lat_mean, latitudes_f]).T.reshape(-1, 1, 2)
    segments = np.concatenate([points[:-1], points[1:]], axis=1)

    lc = LineCollection(segments, cmap=cmap, norm=norms[var], linewidth=2)
    lc.set_array(lat_mean)
    axp.add_collection(lc)

    axp.fill_betweenx(latitudes_f, lat_lower, lat_upper,
                      color='gray', alpha=0.3)

    axp.set_ylim(-90, 90)
    axp.set_xlim(norms[var].vmin, norms[var].vmax)

    axp.set_yticks(np.arange(-40, 41, 20))
    axp.set_xlabel(units[var], fontsize=10)

    if col_map == 1:
        axp.set_ylabel('Latitude (°)', fontsize=10)

    axp.grid(True, linestyle='--', alpha=0.3)

    axp.spines['top'].set_visible(False)
    axp.spines['right'].set_visible(False)

    # ================= COLORBAR =================
    cbar = fig.colorbar(
        im,
        ax=ax,
        orientation='horizontal',
        pad=0.12,   # 🔥 NO OVERLAP
        fraction=0.05
    )
    cbar.set_label(units[var], fontsize=10)

# =====================================
# 🏁 TITLE
# =====================================

fig.suptitle(
    'Global Mangrove Oceanographic Drivers (2000–2020)\n'
    'SST, SSH, Chlorophyll-a, and Dissolved Oxygen',
    fontsize=16,
    y=0.98
)

plt.subplots_adjust(top=0.92, bottom=0.06)

plt.savefig(
    str(DATA_DIR / 'FINAL_2x2_OCEAN.png'),
    dpi=600,
    bbox_inches='tight'
)

plt.show()
















import xarray as xr
import numpy as np
import os

# ===============================
# File paths
# ===============================
path = str(DATA_DIR / 'LAI')

file1 = os.path.join(path, "LAI_2020.nc")
file2 = os.path.join(path, "LAI_AVHRR_2020.nc")

# ===============================
# Open datasets
# ===============================
ds1 = xr.open_dataset(file1)
ds2 = xr.open_dataset(file2)

# ===============================
# Select variables
# ===============================
lai1 = ds1["leaf_area_index_high_vegetation"]
lai2 = ds2["LAI"]

# ===============================
# STEP 1: Scale AVHRR by 0.01
# ===============================
lai2 = lai2 * 0.01

# =====================================
# 2. Align datasets (important!)
# =====================================
lai1, lai2 = xr.align(lai1, lai2, join="inner")

# =====================================
# 3. Cross-fill missing values
# =====================================
lai1_filled = lai1.fillna(lai2)
lai2_filled = lai2.fillna(lai1)

# =====================================
# 4. Compute ensemble mean (ignoring NaN)
# =====================================
lai_stack = xr.concat([lai1_filled, lai2_filled], dim="source")
lai_ensemble = lai_stack.mean(dim="source", skipna=True)

# =====================================
# 5. Fill remaining missing values temporally
# =====================================
lai_ensemble = lai_ensemble.interpolate_na(
    dim="time",
    method="linear",
    fill_value="extrapolate"
)

# Optional: forward/backward fill for safety
lai_ensemble = lai_ensemble.ffill("time").bfill("time")

# =====================================
# 6. Apply physical constraints
# > 7  → 7
# ≤ 0  → 0.001
# =====================================
lai_ensemble = xr.where(lai_ensemble > 7, 7, lai_ensemble)
lai_ensemble = xr.where(lai_ensemble <= 0, 0.001, lai_ensemble)

# =====================================
# 7. Save new dataset
# =====================================
output_ds = xr.Dataset({"LAI": lai_ensemble})

output_ds.to_netcdf(os.path.join(path, "LAI_Ensemble_2020.nc"))

print("LAI ensemble dataset created successfully ✅")






# =====================================
import xarray as xr
import numpy as np
from scipy.signal import savgol_filter
from numba import njit

# ===============================
# Load dataset
# ===============================
ds = xr.open_dataset(
    str(DATA_DIR / 'LAI' / 'LAI_Ensemble_2020.nc'),
    chunks={'lat':50,'lon':50}
).squeeze()

# Remove longitude > 180
ds = ds.sel(lon=ds.lon <= 180)

LAI = ds['LAI']

print(ds)
print("Dataset loaded")


# ===============================
# SG filter parameters
# ===============================
m = 5
window = 2*m + 1
polyorder = 4
iterations = 50


# ===============================
# Fast SG smoothing
# ===============================
def sg_filter_fast(data):
    return savgol_filter(data, window_length=window, polyorder=polyorder, mode='nearest')


# ===============================
# Numba accelerated iterative SG
# ===============================
@njit
def iterative_sg_numba(lai_series):

    lai0 = lai_series.copy()
    lai_iter = lai_series.copy()

    best_curve = lai_series.copy()
    best_loss = 1e20

    for n in range(iterations):

        # SG filtering
        lai_sg = lai_iter.copy()

        # penalty coefficient
        D = np.zeros_like(lai_series)

        for t in range(lai_series.shape[0]):

            if lai0[t] > lai_sg[t]:
                D[t] = lai0[t] - lai_sg[t]
            else:
                D[t] = 0.1*(lai0[t] - lai_sg[t])

        minD = np.min(np.abs(D))
        maxD = np.max(np.abs(D))

        P = (D - minD) / (maxD - minD + 1e-8)

        loss = np.sum(np.abs(P))

        if loss < best_loss:
            best_loss = loss
            best_curve = lai_sg.copy()

        # update curve
        for t in range(lai_series.shape[0]):
            if lai_sg[t] > lai0[t]:
                lai_iter[t] = lai_sg[t]
            else:
                lai_iter[t] = lai0[t]

    return best_curve


# ===============================
# Wrapper function
# ===============================
def process_pixel(ts):

    ts = sg_filter_fast(ts)
    ts = iterative_sg_numba(ts)

    return ts


# ===============================
# Apply over grid (parallel)
# ===============================
LAI_smoothed = xr.apply_ufunc(
    process_pixel,
    LAI,
    input_core_dims=[['time']],
    output_core_dims=[['time']],
    vectorize=True,
    dask='parallelized',
    output_dtypes=[float]
)


# ===============================
# Compute with Dask
# ===============================
LAI_smoothed = LAI_smoothed.compute()

print("Iterative SG smoothing completed")


# ===============================
# Save output
# ===============================
LAI_smoothed.to_netcdf(
    str(DATA_DIR / 'LAI' / 'LAI_SG_Smoothed_2020.nc')
)

print("Smoothed LAI saved")



#.........................................................
import pandas as pd
import xarray as xr
import numpy as np
from scipy.spatial import cKDTree

# =====================================
# 1. Open NetCDF
# =====================================
ds = xr.open_dataset(str(DATA_DIR / 'LAI' / 'LAI_SG_Smoothed_2000.nc')).squeeze()

# Remove longitude > 180
ds = ds.sel(lon=ds.lon <= 180)

LAI = ds['LAI']

# Ensure consistent dimension order
LAI = LAI.transpose("lat", "lon", "time")

print(ds)
print("Dataset loaded")

# =====================================
# 2. Load CSV coordinates
# =====================================
df = pd.read_csv(str(COORDINATES_FILE))
df.rename(columns={'longitude': 'lon', 'latitude': 'lat'}, inplace=True)

query_points = df[['lat', 'lon']].values

# =====================================
# 3. Build KDTree
# =====================================
LAI0 = LAI.isel(time=0).values

lon_vals = ds.lon.values
lat_vals = ds.lat.values

# Create spatial grid
lat2d, lon2d = np.meshgrid(lat_vals, lon_vals, indexing='ij')

# Valid pixels mask
valid_mask = ~np.isnan(LAI0)

ocean_points = np.column_stack((
    lat2d[valid_mask],
    lon2d[valid_mask]
))

print("Ocean pixels:", ocean_points.shape[0])

# Build KDTree
tree = cKDTree(ocean_points)

# =====================================
# 4. Query nearest ocean pixel
# =====================================
_, idx = tree.query(query_points)

nearest_lat = ocean_points[idx][:, 0]
nearest_lon = ocean_points[idx][:, 1]

# =====================================
# 5. Convert lat/lon to grid index
# =====================================
lon_index = np.searchsorted(lon_vals, nearest_lon)
lat_index = np.searchsorted(lat_vals, nearest_lat)

lon_index = np.clip(lon_index, 0, len(lon_vals)-1)
lat_index = np.clip(lat_index, 0, len(lat_vals)-1)

# =====================================
# 6. Extract full time series
# =====================================
LAI_values = LAI.values   # shape: (lat, lon, time)

extracted = LAI_values[lat_index, lon_index, :]   # (points, time)

print("Extraction complete")

# =====================================
# 7. Build final dataframe
# =====================================
time_str = pd.to_datetime(ds.time.values).strftime("%Y%m%d")

result_df = pd.DataFrame(extracted, columns=time_str)

result_df.insert(0, 'Y', df['lat'].values)
result_df.insert(0, 'X', df['lon'].values)

# =====================================
# 8. Save output
# =====================================
result_df.to_csv(
    str(DATA_DIR / 'LAI' / 'LAI_SG_Smoothed_2000_KDTree.csv'),
    index=False
)

print(result_df.head())
print("KDTree extraction completed ✅")
#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
