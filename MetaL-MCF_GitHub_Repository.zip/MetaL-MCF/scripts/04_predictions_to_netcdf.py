"""Convert upscaled Parquet predictions to 0.25-degree NetCDF grids."""
from config import PREDICTIONS_DIR

#conver to netcdf
# ==========================================================

import os
import argparse
import glob
import re
import numpy as np
import pandas as pd
import xarray as xr

RESULTS_DIR = str(PREDICTIONS_DIR)
GRID_RES = 0.25


def build_axis(values, res=GRID_RES):
    vmin, vmax = float(values.min()), float(values.max())
    n = int(round((vmax - vmin) / res)) + 1
    axis = vmin + np.arange(n) * res
    return axis


def parquet_to_netcdf(parquet_path, output_path, target=None):
    df = pd.read_parquet(parquet_path)

    if target is None:
        non_coord = [c for c in df.columns if c not in ("X", "Y", "Date")]
        if len(non_coord) != 1:
            raise ValueError(f"Cannot infer target column from {df.columns.tolist()}")
        target = non_coord[0]

    df["time"] = pd.to_datetime(df["Date"].astype(str), format="%Y%m%d")

    lon = build_axis(df["X"].unique())
    lat = build_axis(df["Y"].unique())
    time = np.sort(df["time"].unique())

    lon_idx = np.round((df["X"].to_numpy() - lon[0]) / GRID_RES).astype(np.int64)
    lat_idx = np.round((df["Y"].to_numpy() - lat[0]) / GRID_RES).astype(np.int64)
    time_idx = np.searchsorted(time, df["time"].to_numpy())

    arr = np.full((time.size, lon.size, lat.size), np.nan, dtype=np.float32)
    arr[time_idx, lon_idx, lat_idx] = df[target].to_numpy(dtype=np.float32)

    ds = xr.Dataset(
        data_vars={
            target.lower(): (("time", "lon", "lat"), arr, {"id": target.lower()}),
        },
        coords={
            "time": time,
            "lon": lon.astype(np.float64),
            "lat": lat.astype(np.float64),
        },
        attrs={"crs": "EPSG:4326"},
    )

    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    ds.to_netcdf(output_path)
    print(f"Wrote {output_path}  shape={arr.shape}  var={target.lower()}")


def main():
    parser = argparse.ArgumentParser(
        description="Convert prediction Parquet files to gridded NetCDF files."
    )
    parser.add_argument(
        "inputs",
        nargs="*",
        help="Parquet file(s) to convert. If omitted, all predictions_*_*.parquet in results/ are processed.",
    )
    parser.add_argument(
        "-o", "--output-dir",
        default=RESULTS_DIR,
        help=f"Output directory (default: {RESULTS_DIR}).",
    )
    args = parser.parse_args()

    if args.inputs:
        paths = args.inputs
    else:
        paths = sorted(glob.glob(os.path.join(RESULTS_DIR, "predictions_*_*.parquet")))

    if not paths:
        print("No parquet files found.")
        return

    pat = re.compile(r"predictions_(?P<target>[^_]+)_(?P<year>\d{4})\.parquet$")
    for path in paths:
        base = os.path.basename(path)
        m = pat.search(base)
        if m:
            out_name = f"{m.group('target')}_{m.group('year')}.nc"
        else:
            out_name = os.path.splitext(base)[0] + ".nc"
        parquet_to_netcdf(path, os.path.join(args.output_dir, out_name))


if __name__ == "__main__":
    main()
