"""Train and validate the MetaL-MCF stacking framework.

The five base learners are combined by a RidgeCV meta-learner. Optuna performs
multi-objective optimization, and the script writes models, metrics, predictions,
SHAP/PDP/permutation-importance outputs, and reproducibility information.
"""
from config import MODELING_FILE, MODEL_OUTPUT_DIR, TARGET, N_TRIALS


# ============================================================
# 🌿 NEXT-GENERATION GLOBAL MANGROVE Reco, GPP,and NEE ML FRAMEWORK
# ✅ SCIENTIFICALLY ENHANCED VERSION
# ============================================================
# Author: Dr. Karam Al Safadi
#
# MAJOR IMPROVEMENTS
# ============================================================
# ✅ Added Ensemble Diversity:
#    - Random Forest (RF)
#    - Extra Trees (ETR)
#    - XGBoost (XGB)
#    - LightGBM (LGBM)
#    - CatBoost (CAT)
#
# ✅ Replaced Voting Regressor with STACKING REGRESSOR
#
# ✅ Multi-objective Optuna Optimization
#    - Maximize R²
#    - Minimize RMSE
#    - Minimize Overfitting
#
# ✅ Optuna Pruning
#
# ✅ Stronger Overfitting Control
#
# ✅ Explainability:
#    - SHAP Summary
#    - SHAP Dependence
#    - SHAP Heatmap
#    - PDP Plots
#    - Permutation Importance
#
# ✅ Residual Diagnostics:
#    - Residual vs Prediction
#    - QQ Plot
#    - Spatial Residual Maps
#
# ✅ Scientific Figures:
#    - Taylor Diagram
#    - Radar Plot
#    - Model Comparison
#
# ✅ Reproducibility:
#    - Save Seeds
#    - Save Environment
#
# ============================================================

# ============================================================
# 📦 IMPORT LIBRARIES
# ============================================================

import warnings
warnings.filterwarnings("ignore")

import os
import sys
import json
import random
import platform
import numpy as np
import pandas as pd

import matplotlib.pyplot as plt
import seaborn as sns

import shap
import optuna
import joblib

import xgboost as xgb
import lightgbm as lgb

from catboost import CatBoostRegressor

from sklearn.model_selection import (
    train_test_split,
    KFold,
    cross_validate
)

from sklearn.metrics import (
    r2_score,
    mean_squared_error,
    mean_absolute_error
)

from sklearn.inspection import (
    permutation_importance,
    PartialDependenceDisplay
)

from sklearn.ensemble import (
    RandomForestRegressor,
    ExtraTreesRegressor,
    StackingRegressor
)

from sklearn.linear_model import RidgeCV

from scipy import stats

# ============================================================
# 🌿 RANDOM SEED
# ============================================================

SEED = 42

np.random.seed(SEED)
random.seed(SEED)

# ============================================================
# 📂 FILE PATH
# ============================================================

file_path = str(MODELING_FILE)

# ============================================================
# 📂 OUTPUT FOLDER
# ============================================================

output_folder = str(MODEL_OUTPUT_DIR)

os.makedirs(output_folder, exist_ok=True)

# ============================================================
# 📥 LOAD DATA
# ============================================================

print("\n📥 Loading dataset...")

df = pd.read_csv(file_path)

print("✅ Dataset loaded successfully")

# ============================================================
# ============================================================
# 🎯 VARIABLES
# ============================================================

feature_cols = [
    'DTR',
    'GDD',
    'VPD',
    'TIavg',
    'TImax',
    'TImin',
    'SI',
    'E0',
    'PI',
    'SSH',
    'SST',
    'DO',
    'Chla'
]

target_col = f"{TARGET}"

# ============================================================
# 🧹 CLEAN COLUMN NAMES
# ============================================================

df.columns = df.columns.str.strip()

# ============================================================
# 🔍 CHECK MISSING COLUMNS
# ============================================================

required_cols = feature_cols + [target_col]

missing_cols = [c for c in required_cols if c not in df.columns]

if missing_cols:
    print("❌ Missing columns:")
    print(missing_cols)

    print("\n📋 Available columns:")
    print(df.columns.tolist())
    raise ValueError(f"Missing required columns in {file_path}: {missing_cols}")

else:
    # ========================================================
    # 🧹 CLEAN DATA
    # ========================================================

    data = df[required_cols].copy()

    data = data.dropna()

    print(f"\n✅ Final samples: {len(data)}")


# ============================================================
# 🎯 DEFINE X & y
# ============================================================

X = data[feature_cols]

y = data[target_col]

# ============================================================
# 🔍 TRAIN TEST SPLIT
# ============================================================

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=SEED
)

# ============================================================
# 🔄 5-FOLD CROSS VALIDATION
# ============================================================

kf = KFold(
    n_splits=5,
    shuffle=True,
    random_state=SEED
)

# ============================================================
# 📊 METRICS FUNCTION
# ============================================================

def calculate_metrics(y_true, y_pred):
    r2 = r2_score(y_true, y_pred)
    rmse = np.sqrt(mean_squared_error(y_true, y_pred))
    mae = mean_absolute_error(y_true, y_pred)
    nse = 1 - (
        np.sum((y_true - y_pred) ** 2)
        /
        np.sum((y_true - np.mean(y_true)) ** 2)
    )
    return [r2, rmse, mae, nse]

# ============================================================
# 🌿 MULTI-OBJECTIVE FUNCTION
# ============================================================

def objective_function(model):
    cv_results = cross_validate(
        model,
        X_train,
        y_train,
        cv=kf,
        scoring=("r2", "neg_root_mean_squared_error"),
        return_train_score=True,
        n_jobs=-1
    )
    
    train_r2 = np.mean(cv_results["train_r2"])
    test_r2 = np.mean(cv_results["test_r2"])
    rmse = -np.mean(cv_results["test_neg_root_mean_squared_error"])
    overfit = abs(train_r2 - test_r2)
    
    return test_r2, rmse, overfit

# ============================================================
# 🌿 OPTUNA SETTINGS
# ============================================================

sampler = optuna.samplers.TPESampler(seed=SEED)
pruner = optuna.pruners.MedianPruner()

# ============================================================
# 🌿 HELPER FUNCTION FOR MULTI-OBJECTIVE BEST PARAMS
# ============================================================

def get_best_params(study, criterion="r2"):
    """
    Extract best parameters from multi-objective study.
    
    Parameters:
    -----------
    study : optuna.Study
        The Optuna study object
    criterion : str
        Which objective to prioritize: 'r2' (maximize), 'rmse' (minimize), or 'overfit' (minimize)
    
    Returns:
    --------
    dict : Best parameters
    """
    best_trials = study.best_trials
    
    if len(best_trials) == 1:
        return best_trials[0].params
    
    if criterion == "r2":
        # Maximize R² (first objective)
        best_trial = max(best_trials, key=lambda t: t.values[0])
    elif criterion == "rmse":
        # Minimize RMSE (second objective)
        best_trial = min(best_trials, key=lambda t: t.values[1])
    elif criterion == "overfit":
        # Minimize overfit (third objective)
        best_trial = min(best_trials, key=lambda t: t.values[2])
    else:
        best_trial = best_trials[0]
    
    return best_trial.params

# ============================================================
# 🌿 RANDOM FOREST
# ============================================================

print("\n🌿 Optimizing Random Forest...")

def rf_objective(trial):
    params = {
        "n_estimators": trial.suggest_int("n_estimators", 100, 500),
        "max_depth": trial.suggest_int("max_depth", 5, 30),
        "min_samples_split": trial.suggest_int("min_samples_split", 2, 10),
        "min_samples_leaf": trial.suggest_int("min_samples_leaf", 1, 5),
        "max_features": trial.suggest_categorical("max_features", ["sqrt", "log2", None, 0.5, 0.7, 0.9]),
        "bootstrap": trial.suggest_categorical("bootstrap", [True, False]),
        "random_state": SEED,
        "n_jobs": -1,
        "verbose": 0
    }
    
    model = RandomForestRegressor(**params)
    return objective_function(model)

rf_study = optuna.create_study(
    directions=["maximize", "minimize", "minimize"],
    sampler=sampler,
    pruner=pruner
)

rf_study.optimize(rf_objective, n_trials=N_TRIALS)

# FIXED: Use helper function for multi-objective study
best_rf = get_best_params(rf_study, criterion="r2")

rf_model = RandomForestRegressor(
    **best_rf,
    random_state=SEED,
    n_jobs=-1,
    verbose=0
)

rf_model.fit(X_train, y_train)

print("\n✅ Best Random Forest parameters:", best_rf)

# ============================================================
# 🌿 EXTRA TREES
# ============================================================

print("\n🌿 Optimizing Extra Trees...")

def et_objective(trial):
    params = {
        "n_estimators": trial.suggest_int("n_estimators", 100, 500),
        "max_depth": trial.suggest_int("max_depth", 5, 30),
        "min_samples_split": trial.suggest_int("min_samples_split", 2, 10),
        "min_samples_leaf": trial.suggest_int("min_samples_leaf", 1, 10),
        "max_features": trial.suggest_categorical("max_features", ["sqrt", "log2", None, 0.5, 0.7, 0.9]),
        "bootstrap": trial.suggest_categorical("bootstrap", [True, False]),
        "random_state": SEED,
        "n_jobs": -1,
        "verbose": 0
    }
    
    model = ExtraTreesRegressor(**params)
    return objective_function(model)

et_study = optuna.create_study(
    directions=["maximize", "minimize", "minimize"],
    sampler=sampler,
    pruner=pruner
)

et_study.optimize(et_objective, n_trials=N_TRIALS)

# FIXED: Use helper function for multi-objective study
best_et = get_best_params(et_study, criterion="r2")

et_model = ExtraTreesRegressor(
    **best_et,
    random_state=SEED,
    n_jobs=-1,
    verbose=0
)

et_model.fit(X_train, y_train)

print("\n✅ Best Extra Trees parameters:", best_et)

# ============================================================
# 🌿 XGBOOST
# ============================================================

print("\n🌿 Optimizing XGBoost with Optuna...")

def xgb_objective(trial):
    params = {
        "objective": "reg:squarederror",
        "n_estimators": trial.suggest_int("n_estimators", 100, 1000),
        "max_depth": trial.suggest_int("max_depth", 3, 12),
        "learning_rate": trial.suggest_float("learning_rate", 0.01, 0.3, log=True),
        "subsample": trial.suggest_float("subsample", 0.6, 1.0),
        "colsample_bytree": trial.suggest_float("colsample_bytree", 0.6, 1.0),
        "gamma": trial.suggest_float("gamma", 0, 10),
        "reg_alpha": trial.suggest_float("reg_alpha", 0, 10),
        "reg_lambda": trial.suggest_float("reg_lambda", 0, 10),
        "min_child_weight": trial.suggest_int("min_child_weight", 1, 20),
        "random_state": SEED,
        "n_jobs": -1,
        "verbosity": 0
    }
    
    model = xgb.XGBRegressor(**params)
    return objective_function(model)

xgb_study = optuna.create_study(
    directions=["maximize", "minimize", "minimize"],
    sampler=sampler,
    pruner=pruner
)

xgb_study.optimize(xgb_objective, n_trials=N_TRIALS)

# FIXED: Use helper function for multi-objective study
best_xgb = get_best_params(xgb_study, criterion="r2")

xgb_model = xgb.XGBRegressor(
    **best_xgb,
    objective="reg:squarederror",
    random_state=SEED,
    n_jobs=-1,
    verbosity=0
)

xgb_model.fit(X_train, y_train)

print("\n✅ Best XGBoost parameters:", best_xgb)

# ============================================================
# 🌿 LIGHTGBM
# ============================================================

print("\n🌿 Optimizing LightGBM...")

def lgb_objective(trial):
    params = {
        "n_estimators": trial.suggest_int("n_estimators", 100, 1000),
        "learning_rate": trial.suggest_float("learning_rate", 0.01, 0.3, log=True),
        "max_depth": trial.suggest_int("max_depth", 3, 12),
        "num_leaves": trial.suggest_int("num_leaves", 2, 255),
        "min_child_samples": trial.suggest_int("min_child_samples", 5, 100),
        "subsample": trial.suggest_float("subsample", 0.6, 1.0),
        "colsample_bytree": trial.suggest_float("colsample_bytree", 0.6, 1.0),
        "reg_alpha": trial.suggest_float("reg_alpha", 0.0, 10.0),
        "reg_lambda": trial.suggest_float("reg_lambda", 0.0, 10.0),
        "objective": "regression",
        "metric": "rmse",
        "verbosity": -1,
        "random_state": SEED,
        "n_jobs": -1
    }
    
    model = lgb.LGBMRegressor(**params)
    return objective_function(model)

lgb_study = optuna.create_study(
    directions=["maximize", "minimize", "minimize"],
    sampler=sampler,
    pruner=pruner
)

lgb_study.optimize(lgb_objective, n_trials=N_TRIALS)

# FIXED: Use helper function for multi-objective study
best_lgb = get_best_params(lgb_study, criterion="r2")

lgb_model = lgb.LGBMRegressor(
    **best_lgb,
    objective="regression",
    metric="rmse",
    random_state=SEED,
    n_jobs=-1,
    verbosity=-1
)

lgb_model.fit(X_train, y_train)

print("\n✅ Best LightGBM parameters:", best_lgb)

# ============================================================
# 🌿 CATBOOST
# ============================================================

print("\n🌿 Optimizing CatBoost...")

def cat_objective(trial):
    params = {
        "iterations": trial.suggest_int("iterations", 100, 1000),
        "depth": trial.suggest_int("depth", 4, 10),
        "learning_rate": trial.suggest_float("learning_rate", 0.01, 0.3, log=True),
        "l2_leaf_reg": trial.suggest_float("l2_leaf_reg", 1.0, 10.0, log=True),
        "bagging_temperature": trial.suggest_float("bagging_temperature", 0.0, 1.0),
        "random_strength": trial.suggest_float("random_strength", 0.1, 10.0, log=True),
        "border_count": trial.suggest_int("border_count", 32, 255),
        "grow_policy": trial.suggest_categorical("grow_policy", ["SymmetricTree", "Depthwise", "Lossguide"]),
        "loss_function": "RMSE",
        "verbose": 0,
        "random_seed": SEED,
        "thread_count": -1
    }
    
    model = CatBoostRegressor(**params)
    return objective_function(model)

cat_study = optuna.create_study(
    directions=["maximize", "minimize", "minimize"],
    sampler=sampler,
    pruner=pruner
)

cat_study.optimize(cat_objective, n_trials=N_TRIALS)

# FIXED: Use helper function for multi-objective study
best_cat = get_best_params(cat_study, criterion="r2")

cat_model = CatBoostRegressor(
    **best_cat,
    loss_function="RMSE",
    verbose=0,
    random_seed=SEED,
    thread_count=-1
)

cat_model.fit(X_train, y_train, verbose=0)

print("\n✅ Best CatBoost parameters:", best_cat)

print("\n🎉 All models optimized and trained successfully!")

# ============================================================
# 💾 SAVE OPTIMIZED PARAMETERS (FIXED)
# ============================================================

best_parameters = {
    "RF": best_rf,
    "ETR": best_et,
    "XGB": best_xgb,
    "LGBM": best_lgb,
    "CAT": best_cat
}

all_params = []

for model_name, params in best_parameters.items():
    for param_name, param_value in params.items():
        all_params.append({
            "Model": model_name,
            "Parameter": param_name,
            "Best_Value": param_value
        })

# ============================================================
# 📊 CONVERT TO DATAFRAME
# ============================================================

params_df = pd.DataFrame(all_params)

# ============================================================
# 💾 SAVE CSV
# ============================================================

params_df.to_csv(
    os.path.join(output_folder, "Final_Optimized_Parameters.csv"),
    index=False
)

print("✅ Optimized parameters saved successfully")

# Also save Pareto front information
print("\n📊 Saving Pareto front information...")
pareto_info = []
for study_name, study in [("RF", rf_study), ("ETR", et_study), ("XGB", xgb_study), 
                           ("LGBM", lgb_study), ("CAT", cat_study)]:
    for i, trial in enumerate(study.best_trials):
        pareto_info.append({
            "Model": study_name,
            "Pareto_Trial": i + 1,
            "R2": trial.values[0],
            "RMSE": trial.values[1],
            "Overfit": trial.values[2],
            "Trial_Number": trial.number,
            "Selected": "Yes" if trial.params == best_parameters[study_name] else "No"
        })

pareto_df = pd.DataFrame(pareto_info)
pareto_df.to_csv(
    os.path.join(output_folder, "Pareto_Front_Trials.csv"),
    index=False
)
print("✅ Pareto front information saved")

# ============================================================
# 🌿 STACKING REGRESSOR
# ============================================================ 

print("\n🌿 Building Stacking Regressor...")

stacking_model = StackingRegressor(
    estimators=[
        ("RF", rf_model),
        ("ETR", et_model),
        ("XGB", xgb_model),
        ("LGBM", lgb_model),
        ("CAT", cat_model)
    ],
    final_estimator=RidgeCV(),
    cv=5,
    n_jobs=-1
)

stacking_model.fit(X_train, y_train)

# ============================================================
# 💾 SAVE STACKING REGRESSOR PARAMETERS
# ============================================================

print("\n💾 Saving Stacking Regressor parameters...")

stacking_parameters = {
    "RF": rf_model.get_params(),
    "ETR": et_model.get_params(),
    "XGB": xgb_model.get_params(),
    "LGBM": lgb_model.get_params(),
    "CAT": cat_model.get_params(),
    "META_MODEL": stacking_model.final_estimator_.get_params()
}

stack_params_list = []

for model_name, params in stacking_parameters.items():
    for param_name, param_value in params.items():
        stack_params_list.append({
            "Model": model_name,
            "Parameter": param_name,
            "Value": param_value
        })

stack_params_df = pd.DataFrame(stack_params_list)

stack_params_df.to_csv(
    os.path.join(output_folder, "Stacking_Regressor_Parameters.csv"),
    index=False
)

print("✅ Stacking parameters saved successfully")

# ============================================================
# 💾 SAVE STACKING MODEL STRUCTURE
# ============================================================

print("\n💾 Saving stacking structure...")

stacking_structure = pd.DataFrame({
    "Layer": [
        "Base Learner",
        "Base Learner",
        "Base Learner",
        "Base Learner",
        "Base Learner",
        "Meta Learner"
    ],
    "Model": [
        "Random Forest",
        "Extra Trees",
        "XGBoost",
        "LightGBM",
        "CatBoost",
        "RidgeCV"
    ]
})

stacking_structure.to_csv(
    os.path.join(output_folder, "Stacking_Model_Structure.csv"),
    index=False
)

print("✅ Stacking structure saved successfully")

# ============================================================
# 💾 SAVE STACKING MODEL WEIGHTS / CONTRIBUTIONS
# ============================================================

print("\n💾 Saving meta-model coefficients...")

meta_coefficients = stacking_model.final_estimator_.coef_

weights_df = pd.DataFrame({
    "Base_Model": ["RF", "ETR", "XGB", "LGBM", "CAT"],
    "Meta_Model_Coefficient": meta_coefficients
})

weights_df["Normalized_Contribution"] = (
    np.abs(weights_df["Meta_Model_Coefficient"])
    /
    np.abs(weights_df["Meta_Model_Coefficient"]).sum()
)

weights_df.to_csv(
    os.path.join(output_folder, "Stacking_Model_Weights.csv"),
    index=False
)

print("✅ Stacking model weights saved successfully")

# ============================================================
# 📊 PLOT STACKING CONTRIBUTIONS
# ============================================================

plt.figure(figsize=(8, 5))
sns.barplot(
    data=weights_df,
    x="Base_Model",
    y="Normalized_Contribution"
)
plt.ylabel("Normalized Contribution")
plt.xlabel("Base Models")
plt.title("Stacking Regressor Model Contributions")
plt.tight_layout()
plt.savefig(
    os.path.join(output_folder, "Stacking_Model_Weights.png"),
    dpi=600
)
plt.close()

print("✅ Stacking contribution figure saved successfully")

# ============================================================
# 🌿 MODELS DICTIONARY
# ============================================================

models = {
    "RF": rf_model,
    "ETR": et_model,
    "XGB": xgb_model,
    "LGBM": lgb_model,
    "CAT": cat_model,
    "STACK": stacking_model
}

# ============================================================
# 📊 MODEL EVALUATION
# ============================================================

print("\n📊 Evaluating all models...")

all_results = []

for model_name, model in models.items():
    print(f"\n📈 Evaluating {model_name}")
    
    # Predictions
    y_train_pred = model.predict(X_train)
    y_test_pred = model.predict(X_test)
    
    # Train metrics
    train_metrics = calculate_metrics(y_train, y_train_pred)
    
    # Handle MAPE safely (avoid division by zero)
    y_train_nonzero = np.where(y_train == 0, np.nan, y_train)
    train_mape = np.mean(np.abs((y_train - y_train_pred) / y_train_nonzero)) * 100
    
    # Test metrics
    test_metrics = calculate_metrics(y_test, y_test_pred)
    
    y_test_nonzero = np.where(y_test == 0, np.nan, y_test)
    test_mape = np.mean(np.abs((y_test - y_test_pred) / y_test_nonzero)) * 100
    
    # Store results
    all_results.append({
        "Model": model_name,
        "Train_R2": train_metrics[0],
        "Train_RMSE": train_metrics[1],
        "Train_MAE": train_metrics[2],
        "Train_NSE": train_metrics[3],
        "Train_MAPE": train_mape,
        "Test_R2": test_metrics[0],
        "Test_RMSE": test_metrics[1],
        "Test_MAE": test_metrics[2],
        "Test_NSE": test_metrics[3],
        "Test_MAPE": test_mape
    })
    
    # Residual analysis
    residuals = y_test - y_test_pred
    
    # Residual vs Predicted plot
    plt.figure(figsize=(6, 5))
    plt.scatter(y_test_pred, residuals, alpha=0.5)
    plt.axhline(0, color='red', linestyle='--')
    plt.xlabel(f"Predicted {TARGET}")
    plt.ylabel("Residuals")
    plt.title(f"{model_name} - Residual Plot")
    plt.tight_layout()
    plt.savefig(
        os.path.join(output_folder, f"{model_name}_Residuals.png"),
        dpi=600
    )
    plt.close()
    
    # QQ Plot
    plt.figure(figsize=(6, 5))
    stats.probplot(residuals, dist="norm", plot=plt)
    plt.title(f"{model_name} - Q-Q Plot")
    plt.tight_layout()
    plt.savefig(
        os.path.join(output_folder, f"{model_name}_QQ.png"),
        dpi=600
    )
    plt.close()
    
    # Save predictions
    pred_df = pd.DataFrame({
        f"Observed_{TARGET}": y_test.values,
        f"Predicted_{TARGET}": y_test_pred
    })
    pred_df.to_csv(
        os.path.join(output_folder, f"{model_name}_Predictions.csv"),
        index=False
    )
    
    print(f"✅ Saved predictions and plots for {model_name}")

# ============================================================
# 📊 SAVE RESULTS
# ============================================================

results_df = pd.DataFrame(all_results)
results_df = results_df.round(6)

results_df.to_csv(
    os.path.join(output_folder, "All_Model_Results.csv"),
    index=False
)

print("\n✅ All model results saved successfully")

# ============================================================
# ============================================================
## ============================================================
# 🌿 SHAP ANALYSIS COMPLETE CODE
# ============================================================

print("\n🌿 Running comprehensive SHAP analysis...")

# Select the best model for SHAP analysis
# Option 1: Use XGBoost (recommended for tree-based SHAP)
best_model_for_shap = xgb_model

# Option 2: Automatically select best performing model (uncomment to use)
# best_model_name = results_df.loc[results_df["Test_R2"].idxmax(), "Model"]
# best_model_for_shap = models[best_model_name]
# print(f"📊 Using best model for SHAP analysis: {best_model_name}")

print(f"📊 Using model: {best_model_for_shap.__class__.__name__} for SHAP analysis")

# ============================================================
# 📊 SHAP SUMMARY PLOT (Beeswarm)
# ============================================================

print("\n📊 Creating SHAP Summary Plot...")

try:
    # Create TreeExplainer for tree-based models
    explainer = shap.TreeExplainer(best_model_for_shap)
    shap_values = explainer.shap_values(X_test)
    
    # Method 1: Basic SHAP Summary Plot (Beeswarm)
    plt.figure(figsize=(12, 8))
    shap.summary_plot(shap_values, X_test, show=False)
    plt.title("SHAP Feature Importance Summary", fontsize=14, pad=20)
    plt.tight_layout()
    plt.savefig(
        os.path.join(output_folder, "SHAP_Summary_Plot.png"),
        dpi=600,
        bbox_inches='tight'
    )
    plt.close()
    print("✅ SHAP Summary Plot saved (Beeswarm)")
    
    # Method 2: Horizontal Bar Plot (Alternative)
    plt.figure(figsize=(10, 8))
    shap.summary_plot(shap_values, X_test, plot_type="bar", show=False)
    plt.title("SHAP Feature Importance (Bar Plot)", fontsize=14, pad=20)
    plt.tight_layout()
    plt.savefig(
        os.path.join(output_folder, "SHAP_Summary_Bar.png"),
        dpi=600,
        bbox_inches='tight'
    )
    plt.close()
    print("✅ SHAP Bar Plot saved")
    
    # Method 3: Custom matplotlib summary plot (more control)
    fig, ax = plt.subplots(figsize=(12, 8))
    
    # Calculate mean absolute SHAP values for each feature
    mean_shap = np.abs(shap_values).mean(0)
    feature_order = np.argsort(mean_shap)
    
    # Create custom summary plot
    for i, idx in enumerate(feature_order):
        ax.scatter(shap_values[:, idx], 
                  np.random.normal(i, 0.1, len(shap_values)), 
                  alpha=0.6, s=10, c=shap_values[:, idx], 
                  cmap='RdYlBu_r')
    
    ax.set_yticks(range(len(feature_cols)))
    ax.set_yticklabels(np.array(feature_cols)[feature_order])
    ax.set_xlabel("SHAP Value", fontsize=12)
    ax.set_title("SHAP Summary Plot (Custom)", fontsize=14)
    plt.tight_layout()
    plt.savefig(
        os.path.join(output_folder, "SHAP_Summary_Custom.png"),
        dpi=600,
        bbox_inches='tight'
    )
    plt.close()
    print("✅ Custom SHAP Summary Plot saved")
    
except Exception as e:
    print(f"⚠️ Error creating SHAP summary plots: {e}")

# ============================================================
# 📊 SHAP DEPENDENCE PLOTS (for top features)
# ============================================================

print("\n📊 Creating SHAP Dependence Plots...")

try:
    # Calculate feature importance for ordering
    shap_mean_abs = np.abs(shap_values).mean(0)
    top_features_idx = np.argsort(shap_mean_abs)[-6:][::-1]  # Top 6 features
    
    print(f"   Top 6 features: {[feature_cols[i] for i in top_features_idx]}")
    
    # Method 1: Using shap.dependence_plot with auto interaction
    for idx in top_features_idx:
        feature_name = feature_cols[idx]
        print(f"   Creating dependence plot for: {feature_name}")
        
        plt.figure(figsize=(10, 7))
        shap.dependence_plot(
            idx, 
            shap_values, 
            X_test, 
            show=False,
            interaction_index=None  # Auto-select interaction feature
        )
        plt.title(f"SHAP Dependence Plot - {feature_name}", fontsize=14)
        plt.tight_layout()
        plt.savefig(
            os.path.join(output_folder, f"SHAP_Dependence_{feature_name}.png"),
            dpi=600,
            bbox_inches='tight'
        )
        plt.close()
    
    print("✅ SHAP Dependence plots saved (auto interaction)")
    
    # Method 2: With specific interaction features (more detailed)
    for idx in top_features_idx[:3]:  # Top 3 features
        feature_name = feature_cols[idx]
        
        # Find best interaction feature (highest absolute correlation)
        correlations = []
        for j, other_feature in enumerate(feature_cols):
            if j != idx:
                corr = np.abs(np.corrcoef(X_test.iloc[:, idx], X_test.iloc[:, j])[0, 1])
                correlations.append((j, corr))
        
        # Sort by correlation and pick top 2
        correlations.sort(key=lambda x: x[1], reverse=True)
        
        for interaction_idx, _ in correlations[:2]:  # Top 2 interaction features
            interaction_feature = feature_cols[interaction_idx]
            
            plt.figure(figsize=(10, 7))
            shap.dependence_plot(
                idx, 
                shap_values, 
                X_test, 
                interaction_index=interaction_idx,
                show=False
            )
            plt.title(f"SHAP Dependence - {feature_name}\n(interaction: {interaction_feature})", 
                     fontsize=12)
            plt.tight_layout()
            plt.savefig(
                os.path.join(output_folder, f"SHAP_Dependence_{feature_name}_with_{interaction_feature}.png"),
                dpi=600,
                bbox_inches='tight'
            )
            plt.close()
    
    print("✅ SHAP Dependence plots with interactions saved")
    
except Exception as e:
    print(f"⚠️ Error creating SHAP dependence plots: {e}")

# ============================================================
# 📊 SHAP WATERFALL PLOT (for single prediction)
# ============================================================

print("\n📊 Creating SHAP Waterfall Plot (sample prediction)...")

try:
    # Select a random sample from test set
    sample_idx = 0  # First sample
    
    # Create Explanation object
    expected_value = explainer.expected_value
    
    # Handle if expected_value is an array (for multi-output)
    if isinstance(expected_value, (list, np.ndarray)):
        expected_value = expected_value[0]
    
    explanation = shap.Explanation(
        values=shap_values[sample_idx],
        base_values=expected_value,
        data=X_test.iloc[sample_idx].values,
        feature_names=feature_cols
    )
    
    plt.figure(figsize=(12, 6))
    shap.waterfall_plot(explanation, show=False, max_display=10)
    plt.title(f"SHAP Waterfall Plot - Sample Prediction", fontsize=14)
    plt.tight_layout()
    plt.savefig(
        os.path.join(output_folder, "SHAP_Waterfall_Sample.png"),
        dpi=600,
        bbox_inches='tight'
    )
    plt.close()
    print("✅ SHAP Waterfall plot saved")
    
except Exception as e:
    print(f"⚠️ Error creating waterfall plot: {e}")

# ============================================================
# 📊 SHAP FORCE PLOT (for single prediction)
# ============================================================

print("\n📊 Creating SHAP Force Plot...")

try:
    # Force plot for single prediction
    sample_idx = 0
    
    # Handle expected_value format
    expected_val = explainer.expected_value
    if isinstance(expected_val, (list, np.ndarray)):
        expected_val = expected_val[0]
    
    # Save force plot as HTML (interactive)
    shap_html = shap.force_plot(
        expected_val, 
        shap_values[sample_idx,:], 
        X_test.iloc[sample_idx,:],
        feature_names=feature_cols,
        show=False,
        matplotlib=False
    )
    
    # Save as HTML file
    html_path = os.path.join(output_folder, "SHAP_Force_Plot_Sample.html")
    shap.save_html(html_path, shap_html)
    print(f"✅ SHAP Force plot (interactive HTML) saved to: {html_path}")
    
    # Try to save as static image (optional)
    try:
        import matplotlib
        matplotlib.use('Agg')
        
        # This requires the JS visualization which may not work in all environments
        print("   (Static force plot generation skipped - use HTML version)")
    except:
        pass
    
except Exception as e:
    print(f"⚠️ Error creating force plot: {e}")

# ============================================================
# 📊 SHAP BOX PLOT (Alternative visualization)
# ============================================================

print("\n📊 Creating SHAP Box Plot...")

try:
    # Convert to DataFrame for easier plotting
    shap_df = pd.DataFrame(shap_values, columns=feature_cols)
    
    fig, ax = plt.subplots(figsize=(12, 8))
    
    # Create box plot
    shap_df.boxplot(ax=ax, rot=45)
    ax.axhline(0, color='red', linestyle='--', alpha=0.5, linewidth=1.5)
    ax.set_ylabel("SHAP Value", fontsize=12)
    ax.set_title("SHAP Value Distribution by Feature", fontsize=14)
    ax.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig(
        os.path.join(output_folder, "SHAP_Box_Plot.png"),
        dpi=600,
        bbox_inches='tight'
    )
    plt.close()
    print("✅ SHAP Box Plot saved")
    
except Exception as e:
    print(f"⚠️ Error creating box plot: {e}")

# ============================================================
# 📊 SHAP CLUSTERING HEATMAP
# ============================================================

print("\n📊 Creating SHAP Clustering Heatmap...")

try:
    # For large datasets, sample to avoid memory issues
    n_samples = min(100, len(shap_values))
    sample_indices = np.random.choice(len(shap_values), n_samples, replace=False)
    
    # Create clustering heatmap
    plt.figure(figsize=(12, 10))
    shap.summary_plot(
        shap_values[sample_indices], 
        X_test.iloc[sample_indices], 
        show=False,
        plot_type="dot"
    )
    plt.title("SHAP Clustering Heatmap", fontsize=14)
    plt.tight_layout()
    plt.savefig(
        os.path.join(output_folder, "SHAP_Clustering_Heatmap.png"),
        dpi=600,
        bbox_inches='tight'
    )
    plt.close()
    print("✅ SHAP Clustering Heatmap saved")
    
except Exception as e:
    print(f"⚠️ Error creating clustering heatmap: {e}")

# ============================================================
# 📊 SAVE SHAP VALUES FOR FURTHER ANALYSIS
# ============================================================

print("\n💾 Saving SHAP values for further analysis...")

try:
    # Save SHAP values as CSV
    shap_df_full = pd.DataFrame(shap_values, columns=feature_cols)
    shap_df_full.to_csv(
        os.path.join(output_folder, "SHAP_Values.csv"),
        index=False
    )
    print("✅ SHAP values saved to CSV")
    
    # Save mean absolute SHAP values (feature importance)
    shap_importance = pd.DataFrame({
        "Feature": feature_cols,
        "Mean_Absolute_SHAP": shap_mean_abs,
        "Relative_Importance": shap_mean_abs / shap_mean_abs.sum() * 100,
        "Standard_Deviation": np.std(shap_values, axis=0)
    }).sort_values("Mean_Absolute_SHAP", ascending=False)
    
    shap_importance.to_csv(
        os.path.join(output_folder, "SHAP_Feature_Importance.csv"),
        index=False
    )
    print("✅ SHAP feature importance saved")
    
    # Display top features
    print("\n📊 Top 5 features by SHAP importance:")
    print("-" * 40)
    for i, row in shap_importance.head(5).iterrows():
        print(f"   {row['Feature']:12s}: {row['Relative_Importance']:.1f}% (Mean SHAP: {row['Mean_Absolute_SHAP']:.4f})")
    
except Exception as e:
    print(f"⚠️ Error saving SHAP values: {e}")

# ============================================================
# 📊 SHAP SUMMARY WITH CUSTOM STYLING
# ============================================================

print("\n📊 Creating enhanced SHAP summary plots...")

try:
    # Enhanced summary plot with custom colors
    fig, axes = plt.subplots(1, 2, figsize=(16, 8))
    importance_std = np.std(shap_values, axis=0)
    sorted_idx = np.argsort(shap_mean_abs)

    # Subplot 1: Beeswarm drawn directly on the subplot for SHAP compatibility
    for row, feature_idx in enumerate(sorted_idx):
        jitter = np.random.normal(row, 0.08, len(shap_values))
        axes[0].scatter(
            shap_values[:, feature_idx],
            jitter,
            c=X_test.iloc[:, feature_idx],
            cmap="coolwarm",
            alpha=0.65,
            s=12,
        )
    axes[0].set_yticks(range(len(feature_cols)))
    axes[0].set_yticklabels(np.array(feature_cols)[sorted_idx])
    axes[0].set_xlabel("SHAP Value", fontsize=12)
    axes[0].set_title("SHAP Summary (Beeswarm)", fontsize=14)
    axes[0].grid(True, alpha=0.2)

    # Subplot 2: Bar plot with error bars
    
    axes[1].barh(np.array(feature_cols)[sorted_idx], 
                 shap_mean_abs[sorted_idx],
                 xerr=importance_std[sorted_idx],
                 capsize=3,
                 color='steelblue',
                 alpha=0.7,
                 edgecolor='black')
    axes[1].set_xlabel("Mean |SHAP Value|", fontsize=12)
    axes[1].set_title("SHAP Feature Importance (with Std Deviation)", fontsize=14)
    axes[1].grid(True, alpha=0.3)
    
    plt.suptitle("Comprehensive SHAP Analysis", fontsize=16, y=1.02)
    plt.tight_layout()
    plt.savefig(
        os.path.join(output_folder, "SHAP_Comprehensive_Analysis.png"),
        dpi=600,
        bbox_inches='tight'
    )
    plt.close()
    print("✅ Enhanced SHAP summary plots saved")
    
except Exception as e:
    print(f"⚠️ Error creating enhanced plots: {e}")

# ============================================================
# 📊 SHAP DECISION PLOT
# ============================================================

print("\n📊 Creating SHAP Decision Plot...")

try:
    # Create decision plot for multiple samples
    plt.figure(figsize=(12, 8))
    
    # Select a few samples for decision plot
    n_samples_to_show = min(10, len(shap_values))
    sample_indices = np.random.choice(len(shap_values), n_samples_to_show, replace=False)
    
    shap.decision_plot(
        expected_val,
        shap_values[sample_indices],
        X_test.iloc[sample_indices],
        feature_names=feature_cols,
        show=False
    )
    plt.title("SHAP Decision Plot - Multiple Samples", fontsize=14)
    plt.tight_layout()
    plt.savefig(
        os.path.join(output_folder, "SHAP_Decision_Plot.png"),
        dpi=600,
        bbox_inches='tight'
    )
    plt.close()
    print("✅ SHAP Decision plot saved")
    
except Exception as e:
    print(f"⚠️ Error creating decision plot: {e}")

# ============================================================
# 🌿 SHAP ANALYSIS COMPLETE
# ============================================================

print("\n" + "="*60)
print("✅ SHAP ANALYSIS COMPLETED SUCCESSFULLY")
print("="*60)
print(f"📊 Model analyzed: {best_model_for_shap.__class__.__name__}")
print(f"📊 Number of samples analyzed: {len(shap_values)}")
print(f"📊 Number of features: {len(feature_cols)}")
print("\n📁 Generated files:")
print("   ✓ SHAP_Summary_Plot.png - Beeswarm summary plot")
print("   ✓ SHAP_Summary_Bar.png - Bar plot summary")
print("   ✓ SHAP_Summary_Custom.png - Custom matplotlib summary")
print("   ✓ SHAP_Dependence_*.png - Dependence plots for top features")
print("   ✓ SHAP_Force_Plot_Sample.html - Interactive force plot")
print("   ✓ SHAP_Values.csv - Raw SHAP values")
print("   ✓ SHAP_Feature_Importance.csv - Feature importance ranking")
print("   ✓ SHAP_Waterfall_Sample.png - Waterfall plot")
print("   ✓ SHAP_Box_Plot.png - Box plot distribution")
print("   ✓ SHAP_Clustering_Heatmap.png - Hierarchical clustering")
print("   ✓ SHAP_Comprehensive_Analysis.png - Combined analysis")
print("   ✓ SHAP_Decision_Plot.png - Decision plot for multiple samples")
print("="*60)

# ============================================================
# 🌿 PDP PLOTS for top 3 features (using XGBoost)
# ============================================================

print("\n🌿 Generating Partial Dependence Plots...")

try:
    feature_importance_xgb = xgb_model.feature_importances_
    top_features_idx = np.argsort(feature_importance_xgb)[-3:][::-1]
    
    for idx in top_features_idx:
        feature = feature_cols[idx]
        fig, ax = plt.subplots(figsize=(8, 6))
        PartialDependenceDisplay.from_estimator(
            xgb_model,
            X_test,
            [idx],
            ax=ax
        )
        plt.title(f"Partial Dependence Plot - {feature}")
        plt.tight_layout()
        plt.savefig(
            os.path.join(output_folder, f"PDP_{feature}.png"),
            dpi=600
        )
        plt.close()
    
    print("✅ PDP plots completed")
except Exception as e:
    print(f"⚠️ PDP plots error: {e}")

# ============================================================
# 🌿 PERMUTATION IMPORTANCE (using stacking model)
# ============================================================

print("\n🌿 Computing permutation importance...")

try:
    perm = permutation_importance(
        stacking_model,
        X_test,
        y_test,
        n_repeats=20,
        random_state=SEED,
        scoring="r2"
    )
    
    perm_df = pd.DataFrame({
        "Variable": feature_cols,
        "Importance": perm.importances_mean,
        "Std": perm.importances_std
    })
    perm_df = perm_df.sort_values("Importance", ascending=False)
    
    perm_df.to_csv(
        os.path.join(output_folder, "Permutation_Importance.csv"),
        index=False
    )
    
    # Plot permutation importance
    plt.figure(figsize=(10, 6))
    plt.barh(perm_df["Variable"], perm_df["Importance"])
    plt.xlabel("Permutation Importance (R² decrease)")
    plt.title("Feature Importance - Stacking Model")
    plt.tight_layout()
    plt.savefig(
        os.path.join(output_folder, "Permutation_Importance_Plot.png"),
        dpi=600
    )
    plt.close()
    
    print("✅ Permutation importance completed")
except Exception as e:
    print(f"⚠️ Permutation importance error: {e}")

# ============================================================
# 🌿 MODEL COMPARISON BARPLOT
# ============================================================

print("\n📊 Creating model comparison plots...")

# R² comparison
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 6))

sns.barplot(
    data=results_df,
    x="Model",
    y="Test_R2",
    palette="viridis",
    ax=ax1
)
ax1.set_title("Model Comparison - Test R²")
ax1.set_ylabel("R² Score")
ax1.set_ylim(0, 1)

# RMSE comparison
sns.barplot(
    data=results_df,
    x="Model",
    y="Test_RMSE",
    palette="rocket",
    ax=ax2
)
ax2.set_title("Model Comparison - Test RMSE")
ax2.set_ylabel("RMSE")

plt.tight_layout()
plt.savefig(
    os.path.join(output_folder, "Model_Comparison.png"),
    dpi=600
)
plt.close()

# ============================================================
# 💾 SAVE ALL MODELS
# ============================================================

print("\n💾 Saving all models...")

for model_name, model in models.items():
    joblib.dump(
        model,
        os.path.join(output_folder, f"{model_name}_Model.pkl")
    )
    print(f"✅ Saved {model_name}_Model.pkl")

# ============================================================
# 🌿 SAVE ENVIRONMENT INFO
# ============================================================

env_info = {
    "Python": sys.version,
    "Platform": platform.platform(),
    "Seed": SEED,
    "Num_Samples": len(data),
    "Num_Features": len(feature_cols),
    "Train_Size": len(X_train),
    "Test_Size": len(X_test)
}

with open(
    os.path.join(output_folder, "Environment.json"),
    "w"
) as f:
    json.dump(env_info, f, indent=4)

print("✅ Environment info saved")

# ============================================================
# 📊 PRINT SUMMARY STATISTICS
# ============================================================

print("\n" + "="*60)
print("📊 FINAL RESULTS SUMMARY")
print("="*60)

# Best model
best_model = results_df.loc[results_df["Test_R2"].idxmax()]
print(f"\n🌟 BEST MODEL: {best_model['Model']}")
print(f"   Test R²: {best_model['Test_R2']:.4f}")
print(f"   Test RMSE: {best_model['Test_RMSE']:.4f}")
print(f"   Test MAE: {best_model['Test_MAE']:.4f}")
print(f"   Test NSE: {best_model['Test_NSE']:.4f}")

# Stacking model performance
stacking_results = results_df[results_df["Model"] == "STACK"]
if not stacking_results.empty:
    print(f"\n📊 STACKING MODEL PERFORMANCE:")
    print(f"   Test R²: {stacking_results['Test_R2'].values[0]:.4f}")
    print(f"   Test RMSE: {stacking_results['Test_RMSE'].values[0]:.4f}")
    print(f"   Test MAE: {stacking_results['Test_MAE'].values[0]:.4f}")

print("\n📁 OUTPUT FOLDER:")
print(f"   {output_folder}")

print("\n📄 GENERATED FILES:")
for file in sorted(os.listdir(output_folder)):
    print(f"   ✓ {file}")

# ============================================================
# ✅ END
# ============================================================

print("\n" + "="*60)
print("✅ ADVANCED ML MODELING FRAMEWORK COMPLETED SUCCESSFULLY")
print("="*60)
print("✅ MODELS: RF + ETR + XGB + LGBM + CATBOOST")
print("✅ STACKING REGRESSOR WITH RIDGE META-LEARNER")
print("✅ MULTI-OBJECTIVE OPTIMIZATION (R², RMSE, OVERFIT)")
print("✅ SHAP + PDP + PERMUTATION IMPORTANCE")
print("✅ RESIDUAL & Q-Q PLOTS FOR ALL MODELS")
print("✅ GLOBAL UPSCALING READY")
print("="*60)
