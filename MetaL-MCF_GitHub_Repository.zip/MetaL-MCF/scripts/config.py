"""Central configuration for the MetaL-MCF workflow.

Edit the fallback paths below, or set the corresponding environment variables.
All scripts resolve these paths relative to the repository by default.
"""
from pathlib import Path
import os

PROJECT_ROOT = Path(__file__).resolve().parents[1]

# Windows example: Path(r"D:\MetaL-MCF\data")
DATA_DIR = Path(os.environ.get("METAL_MCF_DATA_DIR", PROJECT_ROOT / "data")).expanduser()
# Windows example: Path(r"D:\MetaL-MCF\results")
RESULTS_DIR = Path(os.environ.get("METAL_MCF_RESULTS_DIR", PROJECT_ROOT / "results")).expanduser()

# Use one consistent carbon-flux target throughout training and upscaling.
# The uploaded training code and labels were originally configured for Reco.
# Change to "GPP" or "NEE" only when the input CSV and labels use that target.
TARGET = os.environ.get("METAL_MCF_TARGET", "Reco")

START_YEAR = 2000
END_YEAR = 2020
GRID_RESOLUTION = 0.25
SEED = 42

# Reduce this for a quick test; the original analysis used 100 trials per model.
N_TRIALS = int(os.environ.get("METAL_MCF_N_TRIALS", "100"))
CHUNK_SIZE = 1000
PREDICT_BATCH_SIZE = 50000

COORDINATES_FILE = DATA_DIR / "coordinates" / "coor_world.csv"
MODELING_FILE = DATA_DIR / "modeling" / f"All_{TARGET}.csv"
UPSCALING_DIR = DATA_DIR / "upscaling_data"
MODEL_OUTPUT_DIR = RESULTS_DIR / f"Advanced_ML_Framework_All_{TARGET}"
STACK_MODEL_PATH = MODEL_OUTPUT_DIR / "STACK_Model.pkl"
PREDICTIONS_DIR = RESULTS_DIR / f"{TARGET}_Results"

FEATURES = [
    "DTR", "GDD", "VPD", "TIavg", "TImax", "TImin", "SI",
    "E0", "PI", "SSH", "SST", "DO", "Chla",
]
